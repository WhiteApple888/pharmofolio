"""File-system document storage that keeps source bytes out of LangGraph state."""
from __future__ import annotations

import base64
import hashlib
from pathlib import Path
from uuid import uuid4

from core.config import Settings
from schemas.api import FileInput


class LocalDocumentStore:
    """Stores evidence under tenant/user paths; replace with object storage in production."""

    def __init__(self, settings: Settings) -> None:
        self.root = settings.document_storage_path

    def save(self, tenant_id: str, user_id: str, item: FileInput) -> tuple[str, str]:
        """Persist raw source content and return URI plus a small state-safe summary."""
        target_dir = self.root / tenant_id / user_id
        target_dir.mkdir(parents=True, exist_ok=True)
        safe_name = Path(item.name).name or "evidence"
        target = target_dir / f"{uuid4()}-{safe_name}"
        if item.text is not None:
            target.write_text(item.text, encoding="utf-8")
            summary = item.text[:300].replace("\n", " ")
        elif item.dataUrl and "," in item.dataUrl:
            header, encoded = item.dataUrl.split(",", 1)
            target.write_bytes(base64.b64decode(encoded))
            summary = f"Binary upload ({header.split(';')[0]})"
        else:
            target.write_text("", encoding="utf-8")
            summary = "Empty upload"
        return str(target), summary

    def save_bytes(self, user_id: str, filename: str, content: bytes) -> tuple[str, str]:
        """Store validated upload bytes below an opaque name and return path plus SHA-256."""
        target_dir = self.root / "pharmpath" / user_id
        target_dir.mkdir(parents=True, exist_ok=True)
        safe_name = Path(filename).name.strip() or "upload"
        target = target_dir / f"{uuid4()}-{safe_name}"
        target.write_bytes(content)
        return str(target.resolve()), hashlib.sha256(content).hexdigest()

    def delete_bytes(self, user_id: str, storage_path: str) -> None:
        """Delete a user-owned upload only when it remains inside that user's storage root."""
        path = Path(storage_path).resolve()
        user_root = (self.root / "pharmpath" / user_id).resolve()
        if user_root not in path.parents:
            raise ValueError("The saved file is outside the authorised storage location.")
        path.unlink(missing_ok=True)

    @staticmethod
    def read_for_model(storage_uri: str, max_chars: int = 30_000) -> str:
        """Load bounded text content; binary payloads are represented by a safe note."""
        path = Path(storage_uri)
        try:
            return path.read_text(encoding="utf-8", errors="replace")[:max_chars]
        except OSError:
            return "[The source is a binary document retained in document storage.]"
