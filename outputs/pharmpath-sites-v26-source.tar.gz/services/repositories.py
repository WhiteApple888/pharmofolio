"""Canonical persistence operations with tenant/user ownership enforced at the boundary."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import desc, select
from sqlalchemy.orm import Session

from core.errors import AuthorizationError
from db.models import (
    AssessmentItem,
    AssessmentRecord,
    AuditRecord,
    Claim,
    CoachingConversation,
    CoachingMessage,
    CompetencyAssessment,
    DashboardMetric,
    DevelopmentPlan,
    Evidence,
    Person,
    PharmacistProfile,
    ReportingLine,
    SavedContent,
    Section,
    UploadedFile,
    User,
    UserSession,
    utc_now,
)
from schemas.llm import ExtractedClaim, ProposedMapping


class PharmfolioRepository:
    """Repository facade for tenant-scoped canonical application records."""

    def __init__(self, session: Session) -> None:
        self.session = session

    def add_evidence(self, tenant_id: str, user_id: str, filename: str, uri: str, summary: str) -> Evidence:
        evidence = Evidence(tenant_id=tenant_id, user_id=user_id, filename=filename, storage_uri=uri, summary=summary)
        self.session.add(evidence)
        self.session.flush()
        return evidence

    def evidence_for(self, tenant_id: str, user_id: str, evidence_ids: list[str]) -> list[Evidence]:
        rows = list(self.session.scalars(select(Evidence).where(Evidence.id.in_(evidence_ids))))
        if len(rows) != len(evidence_ids) or any(row.tenant_id != tenant_id or row.user_id != user_id for row in rows):
            raise AuthorizationError("Evidence is not available to the current actor.")
        return rows

    def save_claims(self, tenant_id: str, user_id: str, claims: list[ExtractedClaim]) -> None:
        self.session.add_all([Claim(tenant_id=tenant_id, user_id=user_id, evidence_id=claim.source_document_id, statement=claim.statement, excerpt=claim.excerpt, activity_title=claim.activity_title, metadata_json=claim.model_dump(exclude={"statement", "excerpt", "activity_title", "source_document_id"})) for claim in claims])

    def save_assessments(self, tenant_id: str, user_id: str, workflow_id: str, mappings: list[ProposedMapping], status: str) -> None:
        self.session.add_all([CompetencyAssessment(tenant_id=tenant_id, user_id=user_id, workflow_id=workflow_id, standard_id=mapping.standard_id, proposed_level=mapping.suggested_level, confidence_score=mapping.confidence_score, status=status, rationale=mapping.rationale, provenance_json={"evidence_id": mapping.source_document_id, "reference": mapping.source_reference, "excerpt": mapping.evidence_excerpt}, sensitivity_flags=mapping.sensitivity_flags) for mapping in mappings])

    def save_confirmed_plan(self, tenant_id: str, user_id: str, workflow_id: str, actions: list[dict]) -> DevelopmentPlan:
        plan = DevelopmentPlan(tenant_id=tenant_id, user_id=user_id, workflow_id=workflow_id, actions_json=actions)
        self.session.add(plan)
        return plan

    def audit(self, tenant_id: str, user_id: str, workflow_id: str, event_type: str, details: dict) -> None:
        self.session.add(AuditRecord(tenant_id=tenant_id, user_id=user_id, workflow_id=workflow_id, event_type=event_type, details_json=details))

    def workflow_owner(self, tenant_id: str, workflow_id: str) -> str | None:
        """Look up the owner from the canonical audit trail without crossing tenants."""
        return self.session.scalar(select(AuditRecord.user_id).where(AuditRecord.tenant_id == tenant_id, AuditRecord.workflow_id == workflow_id).order_by(AuditRecord.created_at.asc()))

    def emit_dashboard(self, tenant_id: str, user_id: str, workflow_id: str, metric: dict) -> None:
        current = self.session.scalar(select(DashboardMetric).where(DashboardMetric.tenant_id == tenant_id, DashboardMetric.user_id == user_id, DashboardMetric.workflow_id == workflow_id))
        if current:
            current.metric_json = metric
        else:
            self.session.add(DashboardMetric(tenant_id=tenant_id, user_id=user_id, workflow_id=workflow_id, metric_json=metric))

    def user_by_username(self, username: str) -> User | None:
        return self.session.scalar(select(User).where(User.username == username.strip()))

    def user_by_id(self, user_id: str) -> User | None:
        return self.session.get(User, user_id)

    def create_session(self, user_id: str, token_hash: str, expires_at: datetime) -> UserSession:
        session = UserSession(user_id=user_id, token_hash=token_hash, expires_at=expires_at)
        self.session.add(session)
        return session

    def session_user(self, token_hash: str, now: datetime) -> User | None:
        row = self.session.get(UserSession, token_hash)
        if row is None or row.expires_at.replace(tzinfo=timezone.utc) <= now or not row.user_id:
            if row is not None:
                self.session.delete(row)
            return None
        user = self.session.get(User, row.user_id)
        if user is None or not user.is_active:
            self.session.delete(row)
            return None
        row.last_seen_at = utc_now()
        return user

    def delete_session(self, token_hash: str) -> None:
        row = self.session.get(UserSession, token_hash)
        if row is not None:
            self.session.delete(row)

    def user_payload(self, user: User) -> dict:
        from sqlalchemy.orm import aliased

        supervisor = aliased(Person)
        row = self.session.execute(
            select(User, Person, PharmacistProfile, Section, supervisor.full_name)
            .join(PharmacistProfile, User.profile_id == PharmacistProfile.person_id)
            .join(Person, Person.id == PharmacistProfile.person_id)
            .join(Section, Section.id == PharmacistProfile.section_id)
            .outerjoin(ReportingLine, ReportingLine.pharmacist_person_id == Person.id)
            .outerjoin(supervisor, supervisor.id == ReportingLine.supervisor_person_id)
            .where(User.id == user.id)
        ).one()
        _, person, profile, section, supervisor_name = row
        has_reportees = self.has_direct_reportees(user)
        team_access = bool(user.team_view and has_reportees)
        return {
            "id": user.id,
            "username": user.username,
            "name": person.full_name,
            "role": user.role,
            "profile": {"grade": profile.job_grade, "track": profile.career_track, "section": section.name, "reporting_officer": supervisor_name, "years_in_job_grade": profile.years_in_job_grade},
            "capabilities": {
                "team_dashboard": team_access,
                "reportee_assessment": team_access or bool(user.division_view),
                "division_dashboard": bool(user.division_view),
            },
        }

    def profiles_for(self, user: User) -> list[dict]:
        """Return only the signed-in user's profile for personal product surfaces."""
        return self._profile_rows(select(Person.id).where(Person.id == user.profile_id))

    def reportee_profiles_for(self, user: User) -> list[dict]:
        """Return only direct reportees established by the relational reporting line."""
        return self._profile_rows(
            select(ReportingLine.pharmacist_person_id).where(ReportingLine.supervisor_person_id == user.profile_id)
        )

    def division_profiles_for(self) -> list[dict]:
        """Return the complete pharmacist directory for an already-authorised division query."""
        return self._profile_rows(select(PharmacistProfile.person_id))

    def _profile_rows(self, permitted_people) -> list[dict]:
        # Use aliases for the optional supervisor name.
        from sqlalchemy.orm import aliased

        supervisor = aliased(Person)
        query = (
            select(Person, PharmacistProfile, Section, supervisor.full_name, User.id)
            .join(PharmacistProfile, Person.id == PharmacistProfile.person_id)
            .join(Section, Section.id == PharmacistProfile.section_id)
            .outerjoin(ReportingLine, ReportingLine.pharmacist_person_id == Person.id)
            .outerjoin(supervisor, supervisor.id == ReportingLine.supervisor_person_id)
            .outerjoin(User, User.profile_id == Person.id)
            .where(Person.id.in_(permitted_people))
            .order_by(Person.full_name)
        )
        return [
            {"person_id": person.id, "user_id": profile_user_id, "name": person.full_name, "grade": profile.job_grade, "track": profile.career_track, "section": section.name, "reporting_officer": supervisor_name, "years_in_job_grade": profile.years_in_job_grade}
            for person, profile, section, supervisor_name, profile_user_id in self.session.execute(query).all()
        ]

    def has_direct_reportees(self, user: User) -> bool:
        return self.session.scalar(
            select(ReportingLine.pharmacist_person_id).where(ReportingLine.supervisor_person_id == user.profile_id).limit(1)
        ) is not None

    def is_direct_supervisor(self, supervisor_user: User, reportee_user_id: str) -> bool:
        return self.session.scalar(
            select(ReportingLine.pharmacist_person_id)
            .join(User, User.profile_id == ReportingLine.pharmacist_person_id)
            .where(ReportingLine.supervisor_person_id == supervisor_user.profile_id, User.id == reportee_user_id)
            .limit(1)
        ) is not None

    def create_assessment_record(self, user_id: str, workflow_id: str, ai_result: dict) -> AssessmentRecord:
        """Persist the immutable AI result and initialise separate human-edit rows."""
        current = self.session.scalar(select(AssessmentRecord).where(AssessmentRecord.workflow_id == workflow_id))
        if current is not None:
            return current
        record = AssessmentRecord(user_id=user_id, workflow_id=workflow_id, ai_result_json=ai_result, status="draft")
        self.session.add(record)
        self.session.flush()
        for index, mapping in enumerate(ai_result.get("mappings", [])):
            self.session.add(AssessmentItem(
                assessment_id=record.id,
                item_key=f"{mapping.get('standard_id', 'unknown')}:{index}",
                standard_id=mapping["standard_id"],
            ))
        self.session.flush()
        return record

    def latest_assessment_for(self, user_id: str, *, submitted_only: bool = False) -> AssessmentRecord | None:
        query = select(AssessmentRecord).where(AssessmentRecord.user_id == user_id)
        if submitted_only:
            query = query.where(AssessmentRecord.status == "submitted")
        return self.session.scalar(query.order_by(desc(AssessmentRecord.created_at), desc(AssessmentRecord.id)).limit(1))

    def assessment_items(self, assessment_id: str) -> list[AssessmentItem]:
        return list(self.session.scalars(select(AssessmentItem).where(AssessmentItem.assessment_id == assessment_id).order_by(AssessmentItem.item_key)))

    def owned_assessment_item(self, owner_user_id: str, item_id: str) -> tuple[AssessmentRecord, AssessmentItem] | None:
        row = self.session.execute(
            select(AssessmentRecord, AssessmentItem)
            .join(AssessmentItem, AssessmentItem.assessment_id == AssessmentRecord.id)
            .where(AssessmentRecord.user_id == owner_user_id, AssessmentItem.id == item_id)
        ).one_or_none()
        return row

    def update_owner_assessment_item(self, owner_user_id: str, item_id: str, score: float, justification: str) -> AssessmentRecord:
        row = self.owned_assessment_item(owner_user_id, item_id)
        if row is None:
            raise AuthorizationError("Assessment item is not available to the current actor.")
        record, item = row
        item.owner_confidence_score = score
        item.owner_justification = justification
        item.owner_saved_at = utc_now()
        record.updated_at = utc_now()
        self.session.flush()
        return record

    def submit_latest_assessment(self, owner_user_id: str) -> AssessmentRecord | None:
        record = self.latest_assessment_for(owner_user_id)
        if record is None:
            return None
        record.status = "submitted"
        record.submitted_at = utc_now()
        record.updated_at = utc_now()
        self.session.flush()
        return record

    def update_officer_assessment_item(self, reviewer: User, reportee_user_id: str, item_id: str, score: float, justification: str) -> AssessmentRecord:
        if not self.is_direct_supervisor(reviewer, reportee_user_id):
            raise AuthorizationError("Reportee assessment is not available to the current actor.")
        row = self.owned_assessment_item(reportee_user_id, item_id)
        if row is None or row[0].status != "submitted":
            raise AuthorizationError("A submitted reportee assessment is required before review.")
        record, item = row
        item.reviewer_user_id = reviewer.id
        item.officer_confidence_score = score
        item.officer_justification = justification
        item.officer_saved_at = utc_now()
        record.updated_at = utc_now()
        self.session.flush()
        return record

    def add_uploaded_file(self, user_id: str, context: str, filename: str, mime_type: str, size_bytes: int, storage_path: str, sha256: str) -> UploadedFile:
        row = UploadedFile(user_id=user_id, context=context, original_filename=filename, mime_type=mime_type, size_bytes=size_bytes, storage_path=storage_path, sha256=sha256)
        self.session.add(row)
        self.session.flush()
        return row

    def uploaded_files_for(self, user_id: str, context: str) -> list[UploadedFile]:
        return list(self.session.scalars(select(UploadedFile).where(UploadedFile.user_id == user_id, UploadedFile.context == context).order_by(desc(UploadedFile.uploaded_at))))

    def owned_uploaded_file(self, user_id: str, upload_id: str) -> UploadedFile | None:
        return self.session.scalar(select(UploadedFile).where(UploadedFile.id == upload_id, UploadedFile.user_id == user_id))

    def delete_uploaded_file(self, item: UploadedFile) -> None:
        self.session.delete(item)
        self.session.flush()

    def save_content(self, user_id: str, context: str, content_type: str, title: str, body: str, metadata: dict | None = None, source_conversation_id: str | None = None) -> SavedContent:
        row = SavedContent(user_id=user_id, context=context, content_type=content_type, title=title, body=body, metadata_json=metadata or {}, source_conversation_id=source_conversation_id, is_ai_generated=True)
        self.session.add(row)
        self.session.flush()
        return row

    def saved_content_for(self, user_id: str, context: str) -> list[SavedContent]:
        return list(self.session.scalars(select(SavedContent).where(SavedContent.user_id == user_id, SavedContent.context == context).order_by(desc(SavedContent.created_at))))

    def create_conversation(self, user_id: str, title: str = "New coaching conversation") -> CoachingConversation:
        row = CoachingConversation(user_id=user_id, title=title[:200])
        self.session.add(row)
        self.session.flush()
        return row

    def conversations_for(self, user_id: str) -> list[CoachingConversation]:
        return list(self.session.scalars(select(CoachingConversation).where(CoachingConversation.user_id == user_id).order_by(desc(CoachingConversation.updated_at))))

    def owned_conversation(self, user_id: str, conversation_id: str) -> CoachingConversation | None:
        return self.session.scalar(select(CoachingConversation).where(CoachingConversation.id == conversation_id, CoachingConversation.user_id == user_id))

    def add_message(self, conversation: CoachingConversation, author_role: str, content: str, *, message_type: str = "chat", generated: bool = False, metadata: dict | None = None) -> CoachingMessage:
        row = CoachingMessage(conversation_id=conversation.id, author_role=author_role, message_type=message_type, content=content, is_ai_generated=generated, metadata_json=metadata or {})
        self.session.add(row)
        conversation.updated_at = utc_now()
        if author_role == "user" and conversation.title == "New coaching conversation":
            conversation.title = content.strip().replace("\n", " ")[:80] or conversation.title
        self.session.flush()
        return row

    def messages_for(self, conversation_id: str) -> list[CoachingMessage]:
        return list(self.session.scalars(select(CoachingMessage).where(CoachingMessage.conversation_id == conversation_id).order_by(CoachingMessage.created_at, CoachingMessage.id)))

    def message_in_conversation(self, conversation_id: str, message_id: str) -> CoachingMessage | None:
        return self.session.scalar(select(CoachingMessage).where(CoachingMessage.id == message_id, CoachingMessage.conversation_id == conversation_id))

    def dashboard_metrics_by_user(self) -> dict[str, dict]:
        rows = self.session.execute(select(DashboardMetric).order_by(DashboardMetric.user_id, desc(DashboardMetric.updated_at))).scalars()
        latest: dict[str, dict] = {}
        for row in rows:
            latest.setdefault(row.user_id, row.metric_json)
        return latest
