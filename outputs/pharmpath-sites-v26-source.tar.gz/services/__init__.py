"""Deterministic domain services and persistence boundaries."""
