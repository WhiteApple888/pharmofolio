"""Controlled DFP reference data and deterministic assessment rules."""
from __future__ import annotations

from schemas.api import GapResponse
from schemas.llm import ProposedMapping

DFP_STANDARDS: tuple[tuple[str, str, str], ...] = (
    ("1.1", "Expert Professional Practice", "Demonstrates expert skills and knowledge"),
    ("1.2", "Expert Professional Practice", "Manages patient care responsibilities / delivery of professional activities"),
    ("1.3", "Expert Professional Practice", "Exhibits reasoning and judgement"),
    ("1.4", "Expert Professional Practice", "Uses professional autonomy"),
    ("2.1", "Building Working Relationships", "Ability to communicate effectively"),
    ("2.2", "Building Working Relationships", "Collaborates with members of the health care team and offer consultations"),
    ("3.1", "Leadership", "Visioning"), ("3.2", "Leadership", "Strategic planning"),
    ("3.3", "Leadership", "Innovation"), ("3.4", "Leadership", "Motivates individual"),
    ("4.1", "Management", "Implementing organisational priorities"),
    ("4.2", "Management", "Managing resource utilisation"),
    ("4.3", "Management", "Establishing standards of practice"),
    ("4.4", "Management", "Managing risk"), ("4.5", "Management", "Managing performance"),
    ("4.6", "Management", "Managing change"),
    ("5.1", "Education, Training and Development", "Developing self and others"),
    ("5.2", "Education, Training and Development", "Conducting education and training"),
    ("6.1", "Research and Evaluation", "Evaluating literature/data critically and identifying evidence/practice gaps"),
    ("6.2", "Research and Evaluation", "Developing and evaluating protocols"),
    ("6.3", "Research and Evaluation", "Disseminating evidence"),
    ("6.4", "Research and Evaluation", "Guiding others undertaking research/project"),
    ("6.5", "Research and Evaluation", "Establishing partnerships"),
    ("7.1", "Professionalism", "Professionalism and Code of Ethics"),
    ("7.2", "Professionalism", "Compliance to Legal Frameworks and Requirements"),
    ("7.3", "Professionalism", "Ethical Practice"),
)

GRADE_EXPECTATIONS = {"P12": "Foundation", "P13": "Intermediate", "P14": "Intermediate", "P15": "Advanced", "P16": "Advanced", "P17": "Expert", "P18": "Expert"}


def standard_catalog() -> str:
    """Render the controlled standard list for an LLM interpretation boundary."""
    return "\n".join(f"{code} — {domain} — {name}" for code, domain, name in DFP_STANDARDS)


def expected_level(grade: str) -> str:
    """Return an expected level from controlled grade rules, not an LLM decision."""
    return GRADE_EXPECTATIONS.get(grade, "Track-dependent")


def confidence_label(score: float) -> str:
    """Apply a stable confidence band to an LLM's bounded numerical confidence."""
    return "high" if score >= 0.85 else "medium" if score >= 0.65 else "low"


def derive_gaps(mappings: list[ProposedMapping], grade: str) -> list[GapResponse]:
    """Derive evidence gaps deterministically without treating them as final ratings."""
    expected = expected_level(grade)
    gaps: list[GapResponse] = []
    for mapping in mappings:
        insufficient = mapping.suggested_level == "Not enough evidence" or confidence_label(mapping.confidence_score) == "low"
        if insufficient:
            gaps.append(GapResponse(
                standard_id=mapping.standard_id,
                gap=f"More evidence is needed to demonstrate {expected} practice for {mapping.standard_name}.",
                evidence_needed="A workplace observation, outcome measure, or supervisor-validated example.",
                priority="high" if mapping.sensitivity_flags else "medium",
            ))
    seen: set[str] = set()
    return [gap for gap in gaps if not (gap.standard_id in seen or seen.add(gap.standard_id))]
