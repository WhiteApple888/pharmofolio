"""Authenticated PharmPath API, SQLite persistence, and static application delivery."""
from __future__ import annotations

import base64
import binascii
import json
import mimetypes
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from langgraph.types import Command
from pydantic import BaseModel

from core.config import Settings, get_settings
from core.errors import AuthorizationError, PharmfolioError
from core.logging import configure_logging
from db.models import AssessmentRecord, CoachingMessage, SavedContent, UploadedFile, User, utc_now
from db.session import build_session_factory, session_scope
from schemas.api import (
    AssessmentItemUpdate,
    CoachingMessageInput,
    ConversationCreate,
    LegacyMapRequest,
    LegacyMapResponse,
    LoginRequest,
    PastedEvidenceInput,
    PlanConfirmation,
    SavedContentInput,
    UploadSaveInput,
)
from services.document_store import LocalDocumentStore
from services.dfp_rules import DFP_STANDARDS
from services.repositories import PharmfolioRepository
from services.security import hash_password, issue_session_token, session_token_hash, verify_password
from workflows.graph import build_checkpointer, build_workflow
from workflows.llm import PharmfolioLlm
from workflows.nodes.workflow_nodes import WorkflowDependencies, to_legacy_result

ROOT = Path(__file__).resolve().parents[1]
SESSION_COOKIE = "pharmpath_session"
ALLOWED_UPLOAD_EXTENSIONS = {".pdf", ".jpg", ".jpeg", ".png", ".doc", ".docx", ".xlsx", ".msg", ".eml", ".txt"}
DUMMY_PASSWORD_HASH = hash_password("not-the-password", salt=b"pharmpath-dummy!")


class Actor(BaseModel):
    """Server-resolved identity and capabilities; no client identity headers are trusted."""

    tenant_id: str = "pharmpath"
    user_id: str
    profile_id: int
    username: str
    name: str
    role: str
    team_view: bool
    division_view: bool
    profile: dict[str, Any]


def create_app(settings: Settings | None = None) -> FastAPI:
    """Create the application with one central database/session and storage boundary."""
    configure_logging()
    settings = settings or get_settings()
    settings.document_storage_path.mkdir(parents=True, exist_ok=True)
    factory = build_session_factory(settings)
    checkpointer = build_checkpointer(settings.checkpoint_database_path)
    store = LocalDocumentStore(settings)
    app = FastAPI(title="PharmPath workflow API")
    if settings.allowed_frontend_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.allowed_frontend_origins,
            allow_credentials=True,
            allow_methods=["GET", "POST", "PUT", "OPTIONS"],
            allow_headers=["Content-Type", "X-Requested-With"],
        )

    @app.middleware("http")
    async def enforce_body_limit(request: Request, call_next):
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > settings.max_body_bytes:
            return JSONResponse({"error": "Request exceeds the configured size limit."}, status_code=413)
        return await call_next(request)

    def current_actor(request: Request) -> Actor:
        token = request.cookies.get(SESSION_COOKIE)
        if not token:
            raise HTTPException(401, "Sign in is required.")
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            user = repository.session_user(session_token_hash(token), datetime.now(timezone.utc))
            if user is None:
                raise HTTPException(401, "Your session is invalid or has expired.")
            payload = repository.user_payload(user)
            profile_id = user.profile_id
        return Actor(
            user_id=payload["id"],
            profile_id=profile_id,
            username=payload["username"],
            name=payload["name"],
            role=payload["role"],
            team_view=payload["capabilities"]["team_dashboard"],
            division_view=payload["capabilities"]["division_dashboard"],
            profile=payload["profile"],
        )

    def require_team(actor: Actor = Depends(current_actor)) -> Actor:
        if not actor.team_view:
            raise HTTPException(403, "You do not have access to the Team Dashboard.")
        return actor

    def require_division(actor: Actor = Depends(current_actor)) -> Actor:
        if not actor.division_view:
            raise HTTPException(403, "You do not have access to the Division Dashboard.")
        return actor

    def require_dashboard(actor: Actor = Depends(current_actor)) -> Actor:
        if not actor.team_view and not actor.division_view:
            raise HTTPException(403, "You do not have access to the Team Dashboard.")
        return actor

    def graph_for(session):
        deps = WorkflowDependencies(repository=PharmfolioRepository(session), documents=store, llm=PharmfolioLlm(settings), confidence_threshold=settings.confidence_review_threshold)
        return build_workflow(deps, checkpointer)

    @app.exception_handler(PharmfolioError)
    async def known_error(_: Request, exc: PharmfolioError) -> JSONResponse:
        return JSONResponse(status_code=500, content={"error": str(exc)})

    @app.exception_handler(AuthorizationError)
    async def authorization_error(_: Request, exc: AuthorizationError) -> JSONResponse:
        return JSONResponse(status_code=403, content={"error": str(exc)})

    @app.get("/health")
    def health() -> dict:
        return {"ok": True}

    @app.post("/api/auth/login")
    def login(payload: LoginRequest) -> JSONResponse:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            user = repository.user_by_username(payload.username)
            valid = verify_password(payload.password, user.password_hash if user else DUMMY_PASSWORD_HASH)
            if user is None or not valid or not user.is_active:
                raise HTTPException(401, "The username or password is incorrect.")
            token, token_hash = issue_session_token()
            expires_at = utc_now() + timedelta(hours=settings.session_ttl_hours)
            repository.create_session(user.id, token_hash, expires_at)
            response = JSONResponse({"user": repository.user_payload(user)})
        response.set_cookie(
            SESSION_COOKIE,
            token,
            max_age=settings.session_ttl_hours * 3600,
            httponly=True,
            secure=settings.session_cookie_secure,
            samesite=settings.session_cookie_samesite,
            path="/",
        )
        return response

    @app.post("/api/auth/logout")
    def logout(request: Request) -> JSONResponse:
        token = request.cookies.get(SESSION_COOKIE)
        if token:
            with session_scope(factory) as session:
                PharmfolioRepository(session).delete_session(session_token_hash(token))
        response = JSONResponse({"ok": True})
        response.delete_cookie(SESSION_COOKIE, path="/", httponly=True, samesite=settings.session_cookie_samesite)
        return response

    @app.get("/api/auth/me")
    def me(actor: Actor = Depends(current_actor)) -> dict:
        return {"user": _actor_payload(actor)}

    @app.get("/api/profiles")
    def profiles(actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            user = session.get(User, actor.user_id)
            return {"profiles": PharmfolioRepository(session).profiles_for(user)}

    @app.get("/api/assessment")
    def own_assessment(actor: Actor = Depends(current_actor)) -> dict:
        """Return only the signed-in user's latest assessment; no client owner ID is accepted."""
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            record = repository.latest_assessment_for(actor.user_id)
            return {"assessment": _assessment_payload(repository, record, include_owner_draft=True) if record else None}

    @app.put("/api/assessment/items/{item_id}")
    def update_own_assessment_item(item_id: str, payload: AssessmentItemUpdate, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            record = repository.update_owner_assessment_item(actor.user_id, item_id, payload.confidence_score, payload.justification.strip())
            return {"assessment": _assessment_payload(repository, record, include_owner_draft=True)}

    @app.post("/api/assessment/submit")
    def submit_own_assessment(actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            record = repository.latest_assessment_for(actor.user_id)
            if record is None:
                raise HTTPException(409, "Run an evidence analysis before submitting an assessment.")
            incomplete = [item for item in repository.assessment_items(record.id) if item.owner_confidence_score is None or not (item.owner_justification or "").strip()]
            if incomplete:
                raise HTTPException(422, "Save a confidence score and final response for every assessment item before submitting.")
            record = repository.submit_latest_assessment(actor.user_id)
            return {"assessment": _assessment_payload(repository, record, include_owner_draft=True)}

    @app.get("/api/reportees")
    def reportees(actor: Actor = Depends(require_dashboard)) -> dict:
        with session_scope(factory) as session:
            user = session.get(User, actor.user_id)
            repository = PharmfolioRepository(session)
            return {"reportees": repository.division_profiles_for() if actor.division_view else repository.reportee_profiles_for(user)}

    @app.get("/api/reportee-assessments/{reportee_user_id}")
    def reportee_assessment(reportee_user_id: str, actor: Actor = Depends(require_dashboard)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            reviewer = session.get(User, actor.user_id)
            if not actor.division_view and not repository.is_direct_supervisor(reviewer, reportee_user_id):
                raise HTTPException(403, "You may view only your authorised staff profiles.")
            record = repository.latest_assessment_for(reportee_user_id, submitted_only=True)
            return {"assessment": _assessment_payload(repository, record) if record else None, "status": "submitted" if record else "not_submitted"}

    @app.get("/api/reportees/{reportee_user_id}/evidence")
    def reportee_evidence(reportee_user_id: str, actor: Actor = Depends(require_dashboard)) -> dict:
        """Read-only evidence metadata for a direct reportee or any division profile."""
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            reviewer = session.get(User, actor.user_id)
            if not actor.division_view and not repository.is_direct_supervisor(reviewer, reportee_user_id):
                raise HTTPException(403, "You may view only your authorised staff profiles.")
            items = repository.uploaded_files_for(reportee_user_id, "evidence")
            return {"reportee_user_id": reportee_user_id, "items": [_reportee_evidence_payload(item) for item in items]}

    @app.get("/api/reportees/{reportee_user_id}/evidence/{upload_id}/download")
    def download_reportee_evidence(reportee_user_id: str, upload_id: str, actor: Actor = Depends(require_dashboard)):
        """Download evidence only when the viewer is a direct RO or has division access."""
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            reviewer = session.get(User, actor.user_id)
            if not actor.division_view and not repository.is_direct_supervisor(reviewer, reportee_user_id):
                raise HTTPException(403, "You may view only your authorised staff profiles.")
            row = repository.owned_uploaded_file(reportee_user_id, upload_id)
            if row is None or row.context != "evidence":
                raise HTTPException(404, "Saved evidence not found.")
            path = Path(row.storage_path).resolve()
            root = settings.document_storage_path.resolve()
            if root not in path.parents or not path.is_file():
                raise HTTPException(404, "Saved evidence is unavailable.")
            return FileResponse(path, media_type=row.mime_type, filename=row.original_filename)

    @app.put("/api/reportee-assessments/{reportee_user_id}/items/{item_id}")
    def update_reportee_assessment_item(reportee_user_id: str, item_id: str, payload: AssessmentItemUpdate, actor: Actor = Depends(require_team)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            reviewer = session.get(User, actor.user_id)
            record = repository.update_officer_assessment_item(reviewer, reportee_user_id, item_id, payload.confidence_score, payload.justification.strip())
            return {"assessment": _assessment_payload(repository, record)}

    @app.get("/api/team-dashboard")
    def team_dashboard(actor: Actor = Depends(require_team)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            user = session.get(User, actor.user_id)
            metrics = repository.dashboard_metrics_by_user()
            rows = repository.reportee_profiles_for(user)
            for row in rows:
                reportee_user_id = row["user_id"]
                row["analysis"] = metrics.get(reportee_user_id)
                record = repository.latest_assessment_for(reportee_user_id)
                row["assessment"] = _assessment_summary(repository, record) if record else None
                row["target_percentage"] = _grade_target(row["grade"])
            return {"source": "Authorised direct-report profiles and persisted assessments", "profiles": rows}

    @app.get("/api/division-dashboard")
    def division_dashboard(actor: Actor = Depends(require_division)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            metrics = repository.dashboard_metrics_by_user()
            rows = repository.division_profiles_for()
            for row in rows:
                profile_user_id = row["user_id"]
                row["analysis"] = metrics.get(profile_user_id)
                record = repository.latest_assessment_for(profile_user_id) if profile_user_id else None
                row["assessment"] = _assessment_summary(repository, record) if record else None
                row["target_percentage"] = _grade_target(row["grade"])
            return {"source": "Entire division from the relational pharmacist directory", "profiles": rows}

    @app.post("/api/uploads")
    def save_upload(payload: UploadSaveInput, actor: Actor = Depends(current_actor)) -> dict:
        filename = Path(payload.name).name
        extension = Path(filename).suffix.casefold()
        if extension not in ALLOWED_UPLOAD_EXTENSIONS:
            raise HTTPException(415, "This file type is not supported.")
        if "," not in payload.dataUrl:
            raise HTTPException(422, "The upload payload is invalid.")
        header, encoded = payload.dataUrl.split(",", 1)
        try:
            content = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error):
            raise HTTPException(422, "The upload payload is invalid.")
        if len(content) > settings.max_upload_bytes:
            raise HTTPException(413, f"Files must be no larger than {settings.max_upload_bytes // (1024 * 1024)} MB.")
        if not content:
            raise HTTPException(422, "The selected file is empty.")
        declared_type = header.removeprefix("data:").split(";", 1)[0]
        mime_type = declared_type or mimetypes.guess_type(filename)[0] or "application/octet-stream"
        storage_path, digest = store.save_bytes(actor.user_id, filename, content)
        with session_scope(factory) as session:
            row = PharmfolioRepository(session).add_uploaded_file(actor.user_id, payload.context, filename, mime_type, len(content), storage_path, digest)
            return {"item": _upload_payload(row)}

    @app.post("/api/uploads/text")
    def save_pasted_evidence(payload: PastedEvidenceInput, actor: Actor = Depends(current_actor)) -> dict:
        content = payload.text.encode("utf-8")
        if len(content) > settings.max_upload_bytes:
            raise HTTPException(413, "Pasted evidence is too large.")
        filename = Path(payload.filename).name or "Pasted evidence.txt"
        storage_path, digest = store.save_bytes(actor.user_id, filename, content)
        with session_scope(factory) as session:
            row = PharmfolioRepository(session).add_uploaded_file(actor.user_id, "evidence", filename, "text/plain; charset=utf-8", len(content), storage_path, digest)
            return {"item": _upload_payload(row)}

    @app.get("/api/uploads")
    def saved_uploads(context: str = "evidence", actor: Actor = Depends(current_actor)) -> dict:
        if context not in {"evidence", "assessment", "coaching", "development_plan"}:
            raise HTTPException(422, "Unsupported save context.")
        with session_scope(factory) as session:
            return {"items": [_upload_payload(item) for item in PharmfolioRepository(session).uploaded_files_for(actor.user_id, context)]}

    @app.get("/api/uploads/{upload_id}/download")
    def download_upload(upload_id: str, actor: Actor = Depends(current_actor)):
        with session_scope(factory) as session:
            row = PharmfolioRepository(session).owned_uploaded_file(actor.user_id, upload_id)
            if row is None:
                raise HTTPException(404, "Saved file not found.")
            path = Path(row.storage_path).resolve()
            root = settings.document_storage_path.resolve()
            if root not in path.parents or not path.is_file():
                raise HTTPException(404, "Saved file is unavailable.")
            return FileResponse(path, media_type=row.mime_type, filename=row.original_filename)

    @app.delete("/api/evidence/{upload_id}")
    def delete_evidence(upload_id: str, actor: Actor = Depends(current_actor)) -> dict:
        """Delete evidence only for its owning reportee; reporting officers cannot act on it."""
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            row = repository.owned_uploaded_file(actor.user_id, upload_id)
            if row is None or row.context != "evidence":
                # Do not reveal whether another user's evidence exists.
                raise HTTPException(404, "Saved evidence not found.")
            try:
                store.delete_bytes(actor.user_id, row.storage_path)
            except ValueError:
                raise HTTPException(404, "Saved evidence is unavailable.") from None
            repository.delete_uploaded_file(row)
        return {"deleted": True, "id": upload_id}

    @app.post("/api/saved-content")
    def save_content(payload: SavedContentInput, actor: Actor = Depends(current_actor)) -> dict:
        expected_type = {"assessment": "assessment_snapshot", "development_plan": "development_plan"}[payload.context]
        if payload.content_type != expected_type:
            raise HTTPException(422, "Content type does not match its save context.")
        with session_scope(factory) as session:
            row = PharmfolioRepository(session).save_content(actor.user_id, payload.context, payload.content_type, payload.title, payload.body, payload.metadata)
            return {"item": _saved_payload(row)}

    @app.get("/api/saved-content")
    def saved_content(context: str, actor: Actor = Depends(current_actor)) -> dict:
        if context not in {"assessment", "coaching", "development_plan"}:
            raise HTTPException(422, "Unsupported save context.")
        with session_scope(factory) as session:
            return {"items": [_saved_payload(item) for item in PharmfolioRepository(session).saved_content_for(actor.user_id, context)]}

    @app.post("/api/coaching/conversations")
    def create_conversation(payload: ConversationCreate, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            row = PharmfolioRepository(session).create_conversation(actor.user_id, payload.title)
            return {"conversation": _conversation_payload(row)}

    @app.get("/api/coaching/conversations")
    def conversations(actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            return {"conversations": [_conversation_payload(row) for row in PharmfolioRepository(session).conversations_for(actor.user_id)]}

    @app.get("/api/coaching/conversations/{conversation_id}")
    def conversation(conversation_id: str, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            row = repository.owned_conversation(actor.user_id, conversation_id)
            if row is None:
                raise HTTPException(404, "Conversation not found.")
            return {"conversation": _conversation_payload(row), "messages": [_message_payload(item) for item in repository.messages_for(row.id)]}

    @app.post("/api/coaching/conversations/{conversation_id}/messages")
    def send_coaching_message(conversation_id: str, payload: CoachingMessageInput, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            row = repository.owned_conversation(actor.user_id, conversation_id)
            if row is None:
                raise HTTPException(404, "Conversation not found.")
            repository.add_message(row, "user", payload.content.strip())
            history = [{"role": message.author_role, "content": message.content} for message in repository.messages_for(row.id) if message.message_type == "chat"]
            assessment = repository.latest_assessment_for(actor.user_id)
            coaching_profile = {"name": actor.name, **actor.profile, "assessment": _coaching_assessment_context(repository, assessment)}
            reply = PharmfolioLlm(settings).coaching_message(history, coaching_profile)
            assistant = repository.add_message(row, "assistant", reply, generated=True)
            return {"conversation": _conversation_payload(row), "message": _message_payload(assistant)}

    @app.post("/api/coaching/conversations/{conversation_id}/summary")
    def summarize_conversation(conversation_id: str, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            row = repository.owned_conversation(actor.user_id, conversation_id)
            if row is None:
                raise HTTPException(404, "Conversation not found.")
            history = [{"role": message.author_role, "content": message.content} for message in repository.messages_for(row.id) if message.message_type == "chat"]
            if not history:
                raise HTTPException(409, "Start the conversation before requesting a summary.")
            summary = PharmfolioLlm(settings).summarize_coaching(history)
            message = repository.add_message(row, "assistant", summary.summary, message_type="summary", generated=True, metadata={"action_items": summary.action_items})
            return {"summary": _message_payload(message)}

    @app.post("/api/coaching/conversations/{conversation_id}/summaries/{message_id}/save")
    def save_conversation_summary(conversation_id: str, message_id: str, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            conversation = repository.owned_conversation(actor.user_id, conversation_id)
            if conversation is None:
                raise HTTPException(404, "Conversation not found.")
            message = repository.message_in_conversation(conversation_id, message_id)
            if message is None or message.author_role != "assistant" or message.message_type != "summary":
                raise HTTPException(404, "Generated summary not found.")
            body = json.dumps({"summary": message.content, "action_items": message.metadata_json.get("action_items", [])}, ensure_ascii=False)
            saved = repository.save_content(actor.user_id, "coaching", "coaching_summary", f"Coaching summary · {conversation.title}", body, {"summary_message_id": message.id}, conversation.id)
            return {"item": _saved_payload(saved)}

    @app.post("/api/map", response_model=LegacyMapResponse)
    def map_evidence(payload: LegacyMapRequest, actor: Actor = Depends(current_actor)) -> LegacyMapResponse:
        if not payload.files:
            return JSONResponse(status_code=400, content={"error": "Add at least one approved file or email thread."})
        # The Assessment tab is always the actor's own assessment. Client-supplied
        # identity fields are display hints only and can never select another owner.
        payload.profile.name = actor.name
        payload.profile.grade = actor.profile["grade"]
        payload.profile.track = actor.profile["track"]
        workflow_id = str(uuid4())
        with session_scope(factory) as session:
            repository = PharmfolioRepository(session)
            refs: list[dict[str, str]] = []
            for item in payload.files:
                uri, summary = store.save(actor.tenant_id, actor.user_id, item)
                evidence = repository.add_evidence(actor.tenant_id, actor.user_id, item.name, uri, summary)
                refs.append({"id": evidence.id, "filename": evidence.filename, "summary": evidence.summary})
            repository.audit(actor.tenant_id, actor.user_id, workflow_id, "workflow_started", {"evidence_count": len(refs)})
            graph = graph_for(session)
            config = {"configurable": {"thread_id": _thread_id(actor, workflow_id)}}
            graph.invoke({"tenant_id": actor.tenant_id, "user_id": actor.user_id, "actor_role": "pharmacist", "workflow_id": workflow_id, "profile": payload.profile.model_dump(), "evidence_refs": refs}, config=config)
            state = graph.get_state(config).values
            result = to_legacy_result(state)
            repository.create_assessment_record(actor.user_id, workflow_id, result)
            return LegacyMapResponse(model=settings.openai_model, response_id=state.get("response_id"), result=result)

    @app.post("/api/workflows/{workflow_id}/review")
    def review_assessment(workflow_id: str, decision: str, actor: Actor = Depends(current_actor)) -> dict:
        if actor.role not in {"team_lead", "admin"}:
            raise HTTPException(403, "Only a team lead or administrator can resolve an assessment review.")
        if decision not in {"approved", "rejected"}:
            raise HTTPException(422, "decision must be approved or rejected")
        with session_scope(factory) as session:
            graph = graph_for(session)
            owner_id = PharmfolioRepository(session).workflow_owner(actor.tenant_id, workflow_id)
            if owner_id is None:
                raise HTTPException(404, "Workflow was not found.")
            reviewer = session.get(User, actor.user_id)
            if not PharmfolioRepository(session).is_direct_supervisor(reviewer, owner_id):
                raise HTTPException(403, "You may review only workflows belonging to a direct reportee.")
            owner = actor.model_copy(update={"user_id": owner_id})
            config = {"configurable": {"thread_id": _thread_id(owner, workflow_id)}}
            if not graph.get_state(config).values:
                raise HTTPException(404, "Workflow was not found.")
            graph.invoke(Command(resume=decision), config=config)
            state = graph.get_state(config).values
            return {"workflow_id": workflow_id, "status": state.get("workflow_status"), "dashboard": state.get("dashboard_update")}

    @app.post("/api/plans/confirm")
    def confirm_plan(payload: PlanConfirmation, actor: Actor = Depends(current_actor)) -> dict:
        with session_scope(factory) as session:
            graph = graph_for(session)
            config = {"configurable": {"thread_id": _thread_id(actor, payload.workflow_id)}}
            state = graph.get_state(config).values
            if state.get("workflow_status") != "awaiting_plan_confirmation":
                raise HTTPException(409, "This workflow does not have a plan awaiting confirmation.")
            actions = [action for action in state.get("plan_draft", []) if action["id"] in payload.accepted_action_ids]
            repository = PharmfolioRepository(session)
            plan = repository.save_confirmed_plan(actor.tenant_id, actor.user_id, payload.workflow_id, actions)
            repository.audit(actor.tenant_id, actor.user_id, payload.workflow_id, "plan_confirmed", {"plan_id": plan.id, "action_count": len(actions)})
            return {"plan_id": plan.id, "status": plan.status, "actions": actions}

    @app.get("/app", include_in_schema=False)
    def protected_app(_: Actor = Depends(current_actor)):
        return FileResponse(ROOT / "index.html")

    @app.get("/team-dashboard", include_in_schema=False)
    def team_dashboard_page(_: Actor = Depends(require_dashboard)):
        return FileResponse(ROOT / "index.html")

    @app.get("/reportee-assessment", include_in_schema=False)
    def reportee_assessment_page(_: Actor = Depends(require_dashboard)):
        return FileResponse(ROOT / "index.html")

    @app.get("/division-dashboard", include_in_schema=False)
    def division_dashboard_page(_: Actor = Depends(require_division)):
        return FileResponse(ROOT / "index.html")

    @app.get("/{file_path:path}", include_in_schema=False)
    def static_file(file_path: str = ""):
        relative = "index.html" if not file_path or file_path == "login" else file_path.lstrip("/")
        target = (ROOT / relative).resolve()
        if ROOT not in target.parents or not target.is_file() or target.suffix.lower() not in {".html", ".js", ".css"}:
            raise HTTPException(404, "Not found")
        return FileResponse(target)

    return app


def _actor_payload(actor: Actor) -> dict:
    return {
        "id": actor.user_id,
        "username": actor.username,
        "name": actor.name,
        "role": actor.role,
        "profile": actor.profile,
        "capabilities": {"team_dashboard": actor.team_view, "reportee_assessment": actor.team_view, "division_dashboard": actor.division_view},
    }


def _grade_target(grade: str) -> int:
    return {"P12": 80, "P13": 50, "P14": 85, "P15": 70, "P16": 80, "P17": 40, "P18": 50}.get(grade, 80)


def _assessment_payload(repository: PharmfolioRepository, record: AssessmentRecord, *, include_owner_draft: bool = False) -> dict:
    """Build one precedence-aware assessment without merging its audit layers."""
    human_items = {item.item_key: item for item in repository.assessment_items(record.id)}
    payload_items: list[dict] = []
    owner_values_are_final = record.status == "submitted" or include_owner_draft
    for index, mapping in enumerate(record.ai_result_json.get("mappings", [])):
        item_key = f"{mapping.get('standard_id', 'unknown')}:{index}"
        item = human_items.get(item_key)
        if item is None:
            continue
        ai_score = float(mapping.get("confidence_score", 0))
        ai_justification = str(mapping.get("rationale", ""))
        owner = {
            "confidence_score": item.owner_confidence_score,
            "justification": item.owner_justification,
            "saved_at": _iso(item.owner_saved_at) if item.owner_saved_at else None,
            "submitted": record.status == "submitted",
        }
        officer = {
            "confidence_score": item.officer_confidence_score,
            "justification": item.officer_justification,
            "saved_at": _iso(item.officer_saved_at) if item.officer_saved_at else None,
        }
        if item.officer_confidence_score is not None:
            effective = {"confidence_score": item.officer_confidence_score, "justification": item.officer_justification or "", "source": "reporting_officer_final"}
        elif owner_values_are_final and item.owner_confidence_score is not None:
            effective = {"confidence_score": item.owner_confidence_score, "justification": item.owner_justification or "", "source": "reportee_submitted" if record.status == "submitted" else "reportee_draft"}
        else:
            effective = {"confidence_score": ai_score, "justification": ai_justification, "source": "ai_generated"}
        payload_items.append({
            "id": item.id,
            "item_key": item.item_key,
            "standard_id": item.standard_id,
            "ai": {"confidence_score": ai_score, "justification": ai_justification, "mapping": mapping},
            "reportee": owner,
            "reporting_officer": officer,
            "effective": effective,
        })
    return {
        "id": record.id,
        "workflow_id": record.workflow_id,
        "status": record.status,
        "submitted_at": _iso(record.submitted_at) if record.submitted_at else None,
        "ai_result": record.ai_result_json,
        "items": payload_items,
    }


def _assessment_summary(repository: PharmfolioRepository, record: AssessmentRecord) -> dict:
    payload = _assessment_payload(repository, record)
    by_standard: dict[str, float] = {}
    for item in payload["items"]:
        score = float(item["effective"]["confidence_score"])
        by_standard[item["standard_id"]] = max(score, by_standard.get(item["standard_id"], 0))
    domain_scores = []
    for domain_id in map(str, range(1, 8)):
        standards = [standard_id for standard_id, _, _ in DFP_STANDARDS if standard_id.split(".")[0] == domain_id]
        domain_scores.append(round(sum(by_standard.get(standard_id, 0) for standard_id in standards) / len(standards) * 100) if standards else 0)
    percentage_met = round(sum(score >= 0.67 for score in by_standard.values()) / len(DFP_STANDARDS) * 100) if by_standard else None
    return {
        "id": record.id,
        "status": record.status,
        "domain_scores": domain_scores,
        "percentage_met": percentage_met,
        "effective_sources": sorted({item["effective"]["source"] for item in payload["items"]}),
    }


def _coaching_assessment_context(repository: PharmfolioRepository, record: AssessmentRecord | None) -> dict:
    """Return only the signed-in owner's bounded assessment layers for coaching."""
    if record is None:
        return {"status": "not_started", "message": "The pharmacist has not completed an assessment."}
    payload = _assessment_payload(repository, record, include_owner_draft=True)
    return {
        "status": payload["status"],
        "submitted_at": payload["submitted_at"],
        "items": [
            {
                "standard_id": item["standard_id"],
                "ai_generated": item["ai"],
                "pharmacist_value": item["reportee"],
                "effective": item["effective"],
            }
            for item in payload["items"]
        ],
    }


def _iso(value: datetime) -> str:
    return value.isoformat(timespec="seconds") + ("Z" if value.tzinfo is None else "")


def _upload_payload(row: UploadedFile) -> dict:
    return {"id": row.id, "context": row.context, "filename": row.original_filename, "mime_type": row.mime_type, "size_bytes": row.size_bytes, "uploaded_at": _iso(row.uploaded_at), "can_delete": True}


def _reportee_evidence_payload(row: UploadedFile) -> dict:
    """Metadata only: Reporting Officers cannot download or mutate a reportee's files here."""
    return {"id": row.id, "filename": row.original_filename, "mime_type": row.mime_type, "size_bytes": row.size_bytes, "uploaded_at": _iso(row.uploaded_at)}


def _saved_payload(row: SavedContent) -> dict:
    return {"id": row.id, "context": row.context, "content_type": row.content_type, "title": row.title, "body": row.body, "is_ai_generated": row.is_ai_generated, "metadata": row.metadata_json, "created_at": _iso(row.created_at)}


def _conversation_payload(row) -> dict:
    return {"id": row.id, "title": row.title, "created_at": _iso(row.created_at), "updated_at": _iso(row.updated_at)}


def _message_payload(row: CoachingMessage) -> dict:
    return {"id": row.id, "role": row.author_role, "type": row.message_type, "content": row.content, "is_ai_generated": row.is_ai_generated, "metadata": row.metadata_json, "created_at": _iso(row.created_at)}


def _thread_id(actor: Actor, workflow_id: str) -> str:
    return f"{actor.tenant_id}:{actor.user_id}:{workflow_id}"


app = create_app()
