"""HTTP API for the Pharmfolio backend."""
