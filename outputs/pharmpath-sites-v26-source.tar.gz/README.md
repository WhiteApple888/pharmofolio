# PharmPath

PharmPath is a private pharmacist development workspace for collecting evidence, mapping it to the Singapore MOH Development Framework for Pharmacists, holding GROW coaching conversations, and saving assessment and development-plan snapshots.

## Run locally

From PowerShell in the project root:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
python -m scripts.seed_database
python backend.py
```

Open `http://127.0.0.1:8000`. The seed command is idempotent and can be run again after the CSV changes. Add `OPENAI_API_KEY` to `.env` to use evidence analysis and AI coaching; authentication, profile dashboards, uploads, and saved-content features work without an API key.

To run verification and build the hosted bundle:

```powershell
python -m pytest -q
npm run build
```

## Demonstration accounts

These credentials are for local demonstration only. Passwords are stored in SQLite only as salted PBKDF2-SHA256 hashes.

| Username | Password | Role | Direct reportees |
|---|---|---|---:|
| `alex` | `PharmPath-Alex!` | Pharmacist | 0 |
| `jane` | `PharmPath-Jane!` | Pharmacist | 0 |
| `ben` | `PharmPath-Ben!` | Pharmacist | 0 |
| `jack` | `PharmPath-Jack!` | Pharmacist | 0 |
| `alice` | `PharmPath-Alice!` | Pharmacist | 0 |
| `jamie` | `PharmPath-Jamie!` | Pharmacist | 0 |
| `benedict` | `PharmPath-Benedict!` | Pharmacist | 0 |
| `jeremy` | `PharmPath-Jeremy!` | Pharmacist | 0 |
| `betty` | `PharmPath-Betty!` | Division lead | 2 |
| `sarah` | `PharmPath-Sarah!` | Team lead | 3 |
| `tommy` | `PharmPath-Tommy!` | Division lead | 5 |

Team access requires both `team_view` and at least one direct report in the relational reporting table; those users see only their direct reportees. Division access requires `division_view` and returns the full pharmacist directory. Both rules are enforced by backend queries and reflected in the UI. Production deployments should replace demo credentials and explicitly provision permissions.

## Data and security

- `pharmacist_profile.csv` is the source of truth for pharmacist name, job grade, career track, reporting officer, section, and optional years in current grade.
- `data/pharmfolio.db` is the generated local SQLite database.
- Uploaded bytes are stored below `data/documents/pharmpath/<user-id>/`; only metadata and safe storage references are kept in SQLite.
- Authentication uses an HTTP-only, SameSite=Strict opaque session cookie. Only a SHA-256 session-token digest is stored.
- Sites deployments use the logical `DB` (D1) and `FILES` (R2) bindings declared in `.openai/hosting.json`, so login and persistence do not depend on a separately hosted Python URL.
- Dashboard and saved-content authorization is enforced in API and direct page routes, not only in navigation.
- AI results, pharmacist submissions, and reporting-officer final assessments are stored separately; visualizations use that order of precedence in reverse.
- Do not commit `.env`, API keys, generated databases, or uploaded documents.

The complete relational design and inspection queries are in [docs/database-schema.md](docs/database-schema.md).
