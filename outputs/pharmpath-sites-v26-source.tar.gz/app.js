const framework = [
  ['1', 'Expert Professional Practice', ['1.1 Demonstrates expert skills and knowledge', '1.2 Manages patient care responsibilities / delivery of professional activities', '1.3 Exhibits reasoning and judgement', '1.4 Uses professional autonomy']],
  ['2', 'Building Working Relationships', ['2.1 Ability to communicate effectively', '2.2 Collaborates with members of the health care team and offer consultations']],
  ['3', 'Leadership', ['3.1 Visioning', '3.2 Strategic planning', '3.3 Innovation', '3.4 Motivates individual']],
  ['4', 'Management', ['4.1 Implementing organisational priorities', '4.2 Managing resource utilisation', '4.3 Establishing standards of practice', '4.4 Managing risk', '4.5 Managing performance', '4.6 Managing change']],
  ['5', 'Education, Training and Development', ['5.1 Developing self and others', '5.2 Conducting education and training']],
  ['6', 'Research & Evaluation', ['6.1 Evaluating literature/data critically and identifying evidence/practice gaps', '6.2 Developing and evaluating protocols', '6.3 Disseminating evidence', '6.4 Guiding others undertaking research/project', '6.5 Establishing partnerships']],
  ['7', 'Professionalism', ['7.1 Professionalism and Code of Ethics', '7.2 Compliance to Legal Frameworks and Requirements', '7.3 Ethical Practice']],
];
const gradeProfiles = {
  P12: ['Foundation · supported practice', 'Able to successfully complete tasks with help from others.'],
  P13: ['Foundation · developing independence', 'Able to complete tasks independently; assistance from an expert may be required from time to time.'],
  P14: ['Intermediate · independent practice', 'Able to successfully complete tasks independently.'],
  P15: ['Advanced · trusted practice', 'Able to perform the actions associated with the skill without assistance.'],
  P16: ['Advanced · organisational influence', 'Recognised as a person to ask and able to contribute across broad organisational issues.'],
  P17: ['Expert · recognised authority', 'Recognised as an authority in an area of expertise.'],
  P18: ['Expert · strategic authority', 'Recognised as an authority who creates new applications and processes.'],
};
const allowedExtensions = new Set(['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xlsx', 'txt', 'msg', 'eml']);
const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];
const apiBaseUrl = (window.PHARMFOLIO_API_BASE_URL || (location.protocol === 'file:' ? 'http://127.0.0.1:8000' : '')).trim().replace(/\/$/, '');
const apiUrl = path => `${apiBaseUrl}${path}`;

let currentUser = null;
let pharmacistProfiles = [];
let activePharmacist = { name: '', grade: 'P13', track: '', section: '', reporting_officer: '' };
let ownAssessment = null;
let reportees = [];
let selectedReportee = null;
let reporteeAssessment = null;
let ownDevelopmentResponse = null;
let reporteeDevelopmentResponse = null;
let reporteeCoachingDevelopment = null;
let reporteeEvidence = { items: [] };
let roResponseDraft = null;
let savedUploads = [];
let savedByContext = { assessment: [], coaching: [], development_plan: [] };
let conversations = [];
let currentConversation = null;
let conversationMessages = [];
let lastSummaryMessageId = null;
let teamRows = [];
let divisionRows = [];
let roResponseRefreshTimer = null;
const pharmacistWorkspaces = new Map();

function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]);
}
function toast(message) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.add('show');
  window.setTimeout(() => element.classList.remove('show'), 2800);
}
function emptyState(title, detail) {
  return `<div class="empty-state"><div class="empty-icon">◎</div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(detail)}</p></div>`;
}
function formatDate(value) {
  if (!value) return 'Saved';
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(value));
}
function formatBytes(value) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}
function initials(name) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase();
}
function pharmacistKey(profile = activePharmacist) {
  return profile.name || '__unassigned__';
}
function workspaceFor(key = pharmacistKey()) {
  if (!pharmacistWorkspaces.has(key)) pharmacistWorkspaces.set(key, { uploadedFiles: [], emailText: '', emailId: '', emailSaved: false, result: null });
  return pharmacistWorkspaces.get(key);
}
function newDraftId() {
  return crypto.randomUUID?.() || `draft-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}
function activeResult() {
  return workspaceFor().result;
}
function apiError(data, response) {
  return data?.error || data?.detail || `The request failed (${response.status}).`;
}
async function request(path, options = {}) {
  const response = await fetch(apiUrl(path), { credentials: 'include', ...options });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('json') ? await response.json().catch(() => null) : null;
  if (!response.ok) {
    if (response.status === 401 && path !== '/api/auth/login') showLogin();
    throw new Error(apiError(data, response));
  }
  return data;
}
function jsonOptions(method, body) {
  return { method, headers: { 'content-type': 'application/json', 'x-requested-with': 'PharmPath' }, body: JSON.stringify(body) };
}
function setBusy(button, busy, busyLabel, idleLabel) {
  button.disabled = busy;
  button.textContent = busy ? busyLabel : idleLabel;
}

function showLogin() {
  currentUser = null;
  $('#auth-loading').classList.add('hidden');
  $('#app-shell').classList.add('hidden');
  $('#login-view').classList.remove('hidden');
  $('#login-password').value = '';
  $('#login-username').focus();
}
async function showApplication(user) {
  currentUser = user;
  $('#auth-loading').classList.add('hidden');
  $('#login-view').classList.add('hidden');
  $('#app-shell').classList.remove('hidden');
  $('#team-dashboard-nav').classList.toggle('hidden', !user.capabilities.team_dashboard && !user.capabilities.division_dashboard);
  $$('[data-dashboard-scope="division"]').forEach(button => button.classList.toggle('hidden', !user.capabilities.division_dashboard));
  $$('[data-dashboard-scope="team"]').forEach(button => button.classList.toggle('hidden', !user.capabilities.team_dashboard));
  $$('[data-dashboard-scope="individual"]').forEach(button => button.classList.toggle('hidden', !user.capabilities.reportee_assessment));
  $('#reportee-assessment-nav').classList.add('hidden');
  $('#user-name').textContent = user.name;
  $('#user-meta').textContent = `${user.profile.grade} · ${user.profile.track}`;
  $('#user-avatar').textContent = initials(user.name);
  $('#session-label').textContent = `Signed in as ${user.username}`;
  $('#welcome-heading').textContent = `Welcome back, ${user.name.split(/\s+/)[0]}`;
  $('#welcome-profile').textContent = `${user.profile.grade} · ${user.profile.track} · ${user.profile.section}`;
  await loadWorkspaceData();
  if (roResponseRefreshTimer) window.clearInterval(roResponseRefreshTimer);
  roResponseRefreshTimer = window.setInterval(() => {
    if (document.visibilityState === 'visible' && $('#coaching-development').classList.contains('active-view')) loadOwnDevelopmentResponse();
  }, 15000);
  const directView = ['/team-dashboard', '/division-dashboard'].includes(location.pathname) ? 'team-dashboard' : location.pathname === '/reportee-assessment' ? 'reportee-assessment' : location.hash.replace('#', '') || 'overview';
  await switchView(directView, false);
}
async function authenticate() {
  try {
    const data = await request('/api/auth/me');
    await showApplication(data.user);
  } catch {
    showLogin();
  }
}
async function login(event) {
  event.preventDefault();
  const button = $('#login-button');
  const error = $('#login-error');
  error.textContent = '';
  setBusy(button, true, 'Signing in…', 'Sign in');
  try {
    const data = await request('/api/auth/login', jsonOptions('POST', { username: $('#login-username').value.trim(), password: $('#login-password').value }));
    await showApplication(data.user);
    history.replaceState(null, '', '/#overview');
  } catch (problem) {
    error.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Signing in…', 'Sign in');
  }
}
async function logout() {
  try {
    await request('/api/auth/logout', jsonOptions('POST', {}));
  } finally {
    if (roResponseRefreshTimer) { window.clearInterval(roResponseRefreshTimer); roResponseRefreshTimer = null; }
    history.replaceState(null, '', '/');
    showLogin();
  }
}

async function switchView(view, updateLocation = true) {
  const permitted = {
    'team-dashboard': currentUser?.capabilities.team_dashboard || currentUser?.capabilities.division_dashboard,
    'division-dashboard': currentUser?.capabilities.division_dashboard,
    'reportee-assessment': currentUser?.capabilities.reportee_assessment,
  };
  if (view in permitted && !permitted[view]) {
    toast('You do not have access to that dashboard.');
    view = 'overview';
  }
  if (!document.getElementById(view)?.classList.contains('view')) view = 'overview';
  $$('.view').forEach(section => section.classList.toggle('active-view', section.id === view));
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === view));
  $('#crumb-label').textContent = ({
    mappings: 'Assessment',
    'coaching-development': 'Coaching & development plan',
    evidence: 'Evidence inbox',
    'team-dashboard': 'Team Dashboard',
    'division-dashboard': 'Division Dashboard',
    'reportee-assessment': 'Reportee assessment',
    overview: 'Overview',
  })[view] || 'Overview';
  if (updateLocation) history.replaceState(null, '', `/#${view}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (view === 'team-dashboard') await switchDashboardScope(currentUser?.capabilities.team_dashboard ? 'team' : 'division');
  if (view === 'division-dashboard') await loadDivisionDashboard();
  if (view === 'reportee-assessment') await switchDashboardScope('individual');
  if (view === 'coaching-development') { await loadConversations(); await loadOwnDevelopmentResponse(); }
}

async function loadWorkspaceData() {
  const [profileData, uploadData, assessmentData, coachingData, planData, currentAssessmentData] = await Promise.all([
    request('/api/profiles'),
    request('/api/uploads?context=evidence'),
    request('/api/saved-content?context=assessment'),
    request('/api/saved-content?context=coaching'),
    request('/api/saved-content?context=development_plan'),
    request('/api/assessment'),
  ]);
  pharmacistProfiles = profileData.profiles;
  savedUploads = uploadData.items;
  savedByContext = { assessment: assessmentData.items, coaching: coachingData.items, development_plan: planData.items };
  ownAssessment = currentAssessmentData.assessment;
  activePharmacist = pharmacistProfiles.find(profile => profile.user_id === currentUser.id) || pharmacistProfiles[0] || {
    name: currentUser.name, grade: currentUser.profile.grade, track: currentUser.profile.track, section: currentUser.profile.section,
  };
  if (ownAssessment?.ai_result) workspaceFor(pharmacistKey()).result = ownAssessment.ai_result;
  renderAll();
  renderSavedItems();
}

function fileIcon(filename) {
  const extension = filename.split('.').pop().toUpperCase();
  return ({ PDF: 'PDF', XLSX: 'XLS', DOCX: 'DOC', DOC: 'DOC', JPG: 'IMG', JPEG: 'IMG', PNG: 'IMG', EML: 'EML', MSG: 'MSG', TXT: 'TXT' })[extension] || 'FILE';
}
function evidenceRows() {
  const pending = workspaceFor().uploadedFiles.filter(item => !item.saved).map(item => ({
    id: item.id, kind: 'file', filename: item.file.name, activity: item.file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '), date: 'Not saved', status: 'Ready to submit', url: URL.createObjectURL(item.file), pending: true, canDelete: true,
  }));
  if (workspaceFor().emailText && !workspaceFor().emailSaved) pending.unshift({ id: workspaceFor().emailId, kind: 'email', filename: 'Pasted Outlook thread.eml', activity: 'Outlook thread', date: 'Not saved', status: 'Ready to submit', url: '', pending: true, canDelete: true });
  const persisted = savedUploads.map(item => ({
    id: item.id, kind: 'persisted', filename: item.filename, activity: item.mime_type.startsWith('text/') ? 'Saved text evidence' : 'Saved file evidence', date: formatDate(item.uploaded_at), status: 'Submitted', url: apiUrl(`/api/uploads/${item.id}/download`), size: item.size_bytes, canDelete: Boolean(currentUser && item.can_delete),
  }));
  return [...pending, ...persisted];
}
function evidenceActions(row) {
  const submit = row.pending
    ? `<button class="primary-btn evidence-submit" type="button" data-evidence-submit="${escapeHtml(row.id)}">Submit to RO</button>`
    : '<button class="secondary-btn evidence-submitted" type="button" disabled>Submitted</button>';
  const remove = row.canDelete
    ? `<button class="icon-btn evidence-delete" type="button" data-evidence-delete="${escapeHtml(row.id)}" data-evidence-kind="${escapeHtml(row.kind)}" aria-label="Delete ${escapeHtml(row.filename)}" title="Delete evidence">🗑</button>`
    : '';
  return `<div class="evidence-actions">${submit}${remove}</div>`;
}
function renderEvidence() {
  const rows = evidenceRows();
  $('#recent-list').innerHTML = rows.slice(0, 3).map(item => `<div class="evidence-row"><div class="file-icon">${fileIcon(item.filename)}</div><div><strong>${escapeHtml(item.activity)}</strong><small>${escapeHtml(item.filename)} · ${escapeHtml(item.date)}</small></div><span class="status">${escapeHtml(item.status)}</span></div>`).join('') || emptyState('No evidence yet', 'Upload approved work documents to begin building your portfolio.');
  $('#evidence-table').innerHTML = rows.map(item => `<div class="table-row"><div class="file-icon">${fileIcon(item.filename)}</div><div><strong>${escapeHtml(item.filename)}</strong><small>${escapeHtml(item.date)}${item.size ? ` · ${formatBytes(item.size)}` : ''}</small></div><div><strong>${escapeHtml(item.activity)}</strong><small>${escapeHtml(item.status)}</small></div>${item.url ? `<a class="download-link" href="${item.url}" download>Download</a>` : '<span class="pending-label">Pending</span>'}${evidenceActions(item)}</div>`).join('') || emptyState('Your inbox is empty', 'Choose files or paste an Outlook thread. Submitted items will remain available when you return.');
  $('#file-count-large').textContent = rows.length;
  $('#evidence-count').textContent = rows.length;
  $('#overview-evidence-count').textContent = savedUploads.length;
}
function addFiles(files) {
  const workspace = workspaceFor();
  let added = 0;
  [...files].forEach(file => {
    const extension = file.name.split('.').pop().toLowerCase();
    if (!allowedExtensions.has(extension)) {
      toast(`${file.name} is not a supported file type.`);
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      toast(`${file.name} is larger than 25 MB.`);
      return;
    }
    workspace.uploadedFiles.push({ id: newDraftId(), file, saved: false });
    added += 1;
  });
  renderEvidence();
  if (added) toast(`${added} file${added === 1 ? '' : 's'} added to the inbox`);
}
function addEmailEvidence() {
  const text = $('#email-text').value.trim();
  if (!text) {
    toast('Paste some email content first.');
    return;
  }
  const workspace = workspaceFor();
  workspace.emailText = text;
  workspace.emailSaved = false;
  workspace.emailId = newDraftId();
  $('#paste-panel').classList.add('hidden');
  $('#email-text').value = '';
  renderEvidence();
  toast('Outlook thread added to the inbox.');
}
function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve({ name: file.name, dataUrl: reader.result });
    reader.onerror = () => reject(new Error(`Could not read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}
async function submitEvidence(id) {
  const status = $('#evidence-save-status');
  const workspace = workspaceFor();
  const file = workspace.uploadedFiles.find(item => item.id === id && !item.saved);
  const isEmail = id === workspace.emailId && workspace.emailText && !workspace.emailSaved;
  if (!file && !isEmail) {
    status.textContent = 'This evidence item is no longer available to submit.';
    return;
  }
  const button = document.querySelector(`[data-evidence-submit="${CSS.escape(id)}"]`);
  setBusy(button, true, 'Submitting…', 'Submit to RO');
  status.textContent = 'Submitting evidence to your private workspace…';
  try {
    if (file) {
      const encoded = await fileToDataUrl(file.file);
      await request('/api/uploads', jsonOptions('POST', { context: 'evidence', ...encoded }));
      file.saved = true;
    } else {
      await request('/api/uploads/text', jsonOptions('POST', { text: workspace.emailText, filename: 'Pasted Outlook thread.eml' }));
      workspace.emailSaved = true;
    }
    savedUploads = (await request('/api/uploads?context=evidence')).items;
    status.textContent = 'Evidence submitted.';
    renderEvidence();
    toast('Evidence submitted.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    if (button?.isConnected) setBusy(button, false, 'Submitting…', 'Submit to RO');
  }
}
async function deleteEvidence(id, kind) {
  const status = $('#evidence-save-status');
  const workspace = workspaceFor();
  if (kind === 'file') {
    workspace.uploadedFiles = workspace.uploadedFiles.filter(item => item.id !== id);
    renderEvidence();
    toast('Draft evidence removed.');
    return;
  }
  if (kind === 'email') {
    workspace.emailText = '';
    workspace.emailSaved = false;
    workspace.emailId = '';
    renderEvidence();
    toast('Draft evidence removed.');
    return;
  }
  const row = savedUploads.find(item => item.id === id);
  if (!row?.can_delete || !currentUser) {
    status.textContent = 'You do not have permission to delete this evidence.';
    return;
  }
  const button = document.querySelector(`[data-evidence-delete="${CSS.escape(id)}"]`);
  setBusy(button, true, 'Deleting…', '🗑');
  try {
    await request(`/api/evidence/${encodeURIComponent(id)}`, jsonOptions('DELETE', {}));
    savedUploads = savedUploads.filter(item => item.id !== id);
    renderEvidence();
    status.textContent = 'Evidence deleted.';
    toast('Evidence deleted.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    if (button?.isConnected) setBusy(button, false, 'Deleting…', '🗑');
  }
}

function mapResult(result) {
  return (result?.mappings || []).map(mapping => ({
    standardId: mapping.standard_id,
    standard: `${mapping.standard_id} ${mapping.standard_name}`,
    activity: mapping.activity_title,
    confidence: mapping.confidence,
    confidenceScore: Number(mapping.confidence_score),
    excerpt: mapping.evidence_excerpt,
    rationale: mapping.rationale,
    source: mapping.source_reference || 'Uploaded evidence',
    currentLevel: mapping.current_level,
    expectedLevel: mapping.expected_level,
    gap: mapping.gap,
  }));
}
function confidenceLabel(score) {
  if (score >= .8) return 'high';
  if (score >= .5) return 'medium';
  return 'low';
}
function assessmentMappings(assessment) {
  if (!assessment) return mapResult(activeResult());
  return assessment.items.map(item => {
    const mapping = item.ai.mapping;
    return {
      standardId: mapping.standard_id,
      standard: `${mapping.standard_id} ${mapping.standard_name}`,
      activity: mapping.activity_title,
      confidence: confidenceLabel(Number(item.effective.confidence_score)),
      confidenceScore: Number(item.effective.confidence_score),
      excerpt: mapping.evidence_excerpt,
      rationale: item.effective.justification,
      source: mapping.source_reference || 'Uploaded evidence',
      currentLevel: mapping.current_level,
      expectedLevel: mapping.expected_level,
      gap: mapping.gap,
      assessmentItem: item,
    };
  });
}
function domainId(mapping) {
  return String(mapping.standardId || '').split('.')[0];
}
function averageConfidenceFor(domain, sourceMappings) {
  const scores = domain[2].map(standard => sourceMappings.filter(mapping => mapping.standardId === standard.split(' ')[0]).map(mapping => Number.isFinite(mapping.confidenceScore) ? mapping.confidenceScore : ({ high: 1, medium: .67, low: .33 })[mapping.confidence] || 0)).filter(values => values.length).map(values => Math.max(...values));
  return scores.length ? Math.round(scores.reduce((sum, score) => sum + score, 0) / domain[2].length * 100) : 0;
}
function mappedCoverage(domain, mappings) {
  return Math.round(new Set(mappings.filter(mapping => domainId(mapping) === domain[0]).map(mapping => mapping.standardId)).size / domain[2].length * 100);
}
function renderCoverage() {
  const mappings = mapResult(activeResult());
  $('#coverage-list').innerHTML = framework.map(domain => {
    const value = mappedCoverage(domain, mappings);
    return `<div class="coverage-item"><label>${escapeHtml(domain[1])}</label><span>${value}% covered</span><div class="coverage-bar"><i style="width:${value}%"></i></div></div>`;
  }).join('');
}
function radarPoint(index, value, radius = 105) {
  const angle = -Math.PI / 2 + Math.PI * 2 * index / framework.length;
  const distance = radius * value / 100;
  return [180 + Math.cos(angle) * distance, 150 + Math.sin(angle) * distance];
}
function renderRadarChart(mappings, target = '#radar-chart') {
  const values = framework.map(domain => averageConfidenceFor(domain, mappings));
  const points = values.map((value, index) => radarPoint(index, value).join(',')).join(' ');
  const rings = [25, 50, 75, 100].map(value => `<polygon points="${framework.map((_, index) => radarPoint(index, value).join(',')).join(' ')}"></polygon>`).join('');
  const axes = framework.map((_, index) => {
    const [x, y] = radarPoint(index, 100);
    return `<line x1="180" y1="150" x2="${x}" y2="${y}"></line>`;
  }).join('');
  const labels = framework.map((domain, index) => {
    const [x, y] = radarPoint(index, 124);
    const anchor = x < 140 ? 'end' : x > 220 ? 'start' : 'middle';
    return `<text x="${x}" y="${y}" text-anchor="${anchor}">${escapeHtml(domain[0] + ' · ' + domain[1].replace(' & ', ' / '))}</text>`;
  }).join('');
  $(target).innerHTML = `<svg viewBox="0 0 360 300" role="img" aria-label="Radar chart showing average confidence across seven DFP domains"><title>Seven-domain average confidence</title><g class="radar-grid">${rings}${axes}</g><polygon class="radar-fill" points="${points}"></polygon><g class="radar-points">${values.map((value, index) => { const [x, y] = radarPoint(index, value); return `<circle cx="${x}" cy="${y}" r="4"><title>${escapeHtml(framework[index][1] + ': ' + value + '% average confidence')}</title></circle>`; }).join('')}</g><g class="radar-labels">${labels}</g></svg>`;
}
function confidenceScore(mapping) {
  return Number.isFinite(mapping.confidenceScore) ? Math.round(mapping.confidenceScore * 100) : ({ high: 100, medium: 67, low: 33 })[String(mapping.confidence || '').toLowerCase()] || 0;
}
function renderDomainChart(mappings) {
  const domain = framework.find(item => item[0] === $('#domain-select').value) || framework[0];
  const values = domain[2].map(standard => {
    const matches = mappings.filter(mapping => mapping.standardId === standard.split(' ')[0]);
    return { standard, value: Math.max(0, ...matches.map(confidenceScore)) };
  });
  $('#domain-chart').innerHTML = `<div class="domain-chart-scale"><span>100%</span><span>50%</span><span>0%</span></div><div class="bar-chart">${values.map(item => `<div class="bar-item"><div class="bar-track"><i style="height:${item.value}%" title="${item.value}% evidence strength"></i></div><strong>${item.value}%</strong><span>${escapeHtml(item.standard)}</span></div>`).join('')}</div><p class="chart-note">Evidence strength reflects the highest numeric LLM confidence for each standard. Empty bars mean no mapped evidence in this session.</p>`;
}
function confidenceOptions(value) {
  const options = [[0, '0% · No confidence'], [.25, '25% · Low'], [.5, '50% · Developing'], [.75, '75% · Strong'], [1, '100% · High']];
  return `<option value="">Select confidence</option>${options.map(([score, label]) => `<option value="${score}" ${value !== null && Math.abs(Number(value) - score) < .001 ? 'selected' : ''}>${label}</option>`).join('')}`;
}
function renderFindings(mappings) {
  $('#assessment-table').innerHTML = mappings.length ? mappings.map(mapping => {
    const item = mapping.assessmentItem;
    const owner = item?.reportee || {};
    const ai = item?.ai || { confidence_score: mapping.confidenceScore, justification: mapping.rationale };
    const officer = item?.reporting_officer || {};
    return `<article class="assessment-finding editable-finding" data-owner-item="${escapeHtml(item?.id || '')}"><div class="finding-heading"><div><strong>${escapeHtml(mapping.standard)}</strong><small>${escapeHtml(mapping.activity)}</small></div><span class="source-badge effective-source">Using ${escapeHtml((item?.effective.source || 'ai_generated').replaceAll('_', ' '))}</span></div><div class="assessment-layers"><section class="assessment-layer ai-assessment-layer"><span class="source-badge ai-source">✦ AI-generated · non-final</span><strong>${Math.round(Number(ai.confidence_score) * 100)}% confidence</strong><p>${escapeHtml(ai.justification)}</p></section><section class="assessment-layer owner-assessment-layer"><span class="source-badge owner-source">Your response${ownAssessment?.status === 'submitted' ? ' · submitted' : ' · draft'}</span><label>Final confidence<select class="owner-confidence" required>${confidenceOptions(owner.confidence_score)}</select></label><label>Final response<textarea class="owner-justification" rows="4" maxlength="5000" placeholder="Explain your final assessment using the evidence shown." required>${escapeHtml(owner.justification || '')}</textarea></label><div class="item-save-row"><button class="secondary-btn save-owner-item" type="button">Save item</button><span class="item-save-status">${owner.saved_at ? `Saved ${escapeHtml(formatDate(owner.saved_at))}` : 'Not saved'}</span></div></section>${officer.confidence_score !== null && officer.confidence_score !== undefined ? `<section class="assessment-layer officer-final-layer"><span class="source-badge officer-source">Reporting-officer final · authoritative</span><strong>${Math.round(Number(officer.confidence_score) * 100)}% confidence</strong><p>${escapeHtml(officer.justification || '')}</p></section>` : ''}</div><ul><li>Evidence excerpt: ${escapeHtml(mapping.excerpt)}</li><li>Current evidence level: ${escapeHtml(mapping.currentLevel || 'Not enough evidence')}</li><li>Expected level: ${escapeHtml(mapping.expectedLevel || 'Not assessed')}</li>${mapping.gap ? `<li>Development consideration: ${escapeHtml(mapping.gap)}</li>` : ''}</ul><p class="source-citation"><b>Document consulted:</b> ${escapeHtml(mapping.source)}</p></article>`;
  }).join('') : emptyState('No assessment yet', 'Run an analysis of your evidence to create an assessment.');
}
function renderAssessment() {
  const mappings = assessmentMappings(ownAssessment);
  $('#assessment-total').textContent = `${new Set(mappings.map(mapping => mapping.standardId)).size} / 26 mapped`;
  $('#assessment-status-label').textContent = ownAssessment?.status === 'submitted' ? `Submitted ${formatDate(ownAssessment.submitted_at)}` : ownAssessment ? 'Draft · not submitted' : 'Not started';
  $('#mapping-count').textContent = mappings.length;
  $('#overview-standards-count').textContent = new Set(mappings.map(mapping => mapping.standardId)).size;
  renderRadarChart(mappings);
  renderDomainChart(mappings);
  renderFindings(mappings);
}
async function analyzeWithOpenAI() {
  const button = $('#analyze-ai');
  const status = $('#ai-status');
  const profileAtSubmit = { ...activePharmacist };
  const workspace = workspaceFor(pharmacistKey(profileAtSubmit));
  if (!$('#analysis-approved').checked) {
    status.textContent = 'Confirm that the files are approved before running analysis.';
    return;
  }
  const files = await Promise.all(workspace.uploadedFiles.map(item => fileToDataUrl(item.file)));
  if (workspace.emailText.trim()) files.push({ name: 'Pasted Outlook thread.eml', text: workspace.emailText });
  if (!files.length) {
    status.textContent = 'Upload a file or paste an Outlook thread first.';
    return;
  }
  setBusy(button, true, 'Running LLM analysis…', 'Run LLM analysis →');
  status.textContent = 'Sending approved evidence to the secure server…';
  try {
    const data = await request('/api/map', jsonOptions('POST', { profile: { name: profileAtSubmit.name, grade: profileAtSubmit.grade, track: profileAtSubmit.track }, files }));
    workspace.result = data.result;
    ownAssessment = (await request('/api/assessment')).assessment;
    if (pharmacistKey() === pharmacistKey(profileAtSubmit)) renderAll();
    status.textContent = `Analysis complete · ${data.model}`;
    toast('LLM analysis complete.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Running LLM analysis…', activeResult() ? 'Run LLM analysis again →' : 'Run LLM analysis →');
  }
}
async function saveAssessment() {
  const status = $('#assessment-save-status');
  if (!ownAssessment) {
    status.textContent = 'Run an evidence analysis before submitting an assessment.';
    return;
  }
  const button = $('#save-assessment');
  setBusy(button, true, 'Submitting…', 'Submit assessment');
  try {
    const rows = $$('[data-owner-item]');
    for (const row of rows) await saveOwnerItem(row.dataset.ownerItem, false);
    ownAssessment = (await request('/api/assessment/submit', jsonOptions('POST', {}))).assessment;
    renderAssessment();
    $('#assessment-save-status').textContent = 'Assessment submitted to your reporting officer.';
    toast('Assessment submitted.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Submitting…', 'Submit assessment');
  }
}

async function saveOwnerItem(itemId, rerender = true) {
  const row = document.querySelector(`[data-owner-item="${CSS.escape(itemId)}"]`);
  if (!row) throw new Error('Assessment item is unavailable.');
  const rawScore = row.querySelector('.owner-confidence').value;
  const justification = row.querySelector('.owner-justification').value.trim();
  if (rawScore === '' || !justification) {
    row.querySelector('.item-save-status').textContent = 'Choose a score and enter a final response.';
    throw new Error('Complete every confidence score and final response before saving.');
  }
  const button = row.querySelector('.save-owner-item');
  setBusy(button, true, 'Saving…', 'Save item');
  try {
    ownAssessment = (await request(`/api/assessment/items/${encodeURIComponent(itemId)}`, jsonOptions('PUT', { confidence_score: Number(rawScore), justification }))).assessment;
    if (rerender) {
      renderAssessment();
      $('#assessment-save-status').textContent = 'Saved. The radar chart now reflects your latest value.';
    }
  } finally {
    if (button.isConnected) setBusy(button, false, 'Saving…', 'Save item');
  }
}

function renderPlan() {
  const result = activeResult();
  const gaps = result?.gaps || [];
  const activities = result?.activities || [];
  $('#gap-list').innerHTML = result ? gaps.length ? gaps.map(gap => `<div class="gap-card"><div><h3>${escapeHtml(gap.standard_id)}</h3><p>${escapeHtml(gap.gap)}</p></div><span class="gap-tag">${escapeHtml(gap.priority)} priority</span><div class="gap-actions"><span>${escapeHtml(gap.evidence_needed)}</span><button type="button" data-coach-gap="${escapeHtml(gap.gap)}">Discuss in coaching →</button></div></div>`).join('') : emptyState('No competency gaps identified', 'The analysis did not identify a competency gap from the supplied evidence.') : emptyState('No competency gaps yet', 'Run analysis for this pharmacist to identify relevant competency gaps.');
  $('#activity-cards').innerHTML = activities.length ? activities.map(activity => `<article class="panel activity-card"><span class="eyebrow">EVIDENCE ACTIVITY</span><h3>${escapeHtml(activity.title)}</h3><p>${escapeHtml(activity.summary)}</p><small>${escapeHtml(activity.source_reference)} · ${escapeHtml(activity.date_or_period)}</small></article>`).join('') : emptyState('No mapped activities', 'Run analysis to create an activity view.');
  $('#gap-tab-count').textContent = gaps.length;
  $('#plan-standard-count').textContent = new Set(mapResult(result).map(mapping => mapping.standardId)).size;
  $('#plan-gap-count').textContent = gaps.length;
  $('#plan-activity-count').textContent = activities.length;
}
function renderReadOnlyDevelopmentResponse(response) {
  const items = response?.action_items || [];
  $('#reportee-action-items').innerHTML = items.length ? items.map(item => `<tr><td>${escapeHtml(item.action_item)}</td><td>${escapeHtml(item.target_date || '—')}</td><td>${escapeHtml(item.support_needed || '—')}</td></tr>`).join('') : '<tr><td colspan="3" class="read-only-empty">Awaiting your Reporting Officer\'s response.</td></tr>';
  $('#reportee-ro-notes').textContent = response?.discussion_notes || 'Awaiting your Reporting Officer\'s response.';
}
async function loadOwnDevelopmentResponse() {
  try {
    ownDevelopmentResponse = (await request('/api/development-plan-response')).response;
    renderReadOnlyDevelopmentResponse(ownDevelopmentResponse);
  } catch (problem) {
    $('#reportee-ro-notes').textContent = problem.message;
  }
}
async function savePlan() {
  const result = activeResult();
  const status = $('#plan-save-status');
  if (!result) {
    status.textContent = 'Run an evidence analysis before saving a development plan.';
    return;
  }
  const button = $('#save-plan');
  setBusy(button, true, 'Saving…', 'Save plan');
  try {
    await request('/api/saved-content', jsonOptions('POST', {
      context: 'development_plan', content_type: 'development_plan',
      title: `Development plan · ${activePharmacist.name} · ${new Date().toLocaleDateString()}`,
      body: JSON.stringify({ gaps: result.gaps, coaching: result.coaching, activities: result.activities }),
      metadata: { profile: activePharmacist },
    }));
    savedByContext.development_plan = (await request('/api/saved-content?context=development_plan')).items;
    renderSavedItems();
    status.textContent = 'Development plan saved to your account.';
    toast('Development plan saved.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Saving…', 'Save plan');
  }
}
function renderSavedList(target, items, emptyTitle) {
  $(target).innerHTML = items.length ? `<div class="saved-items">${items.map(item => `<article class="saved-item"><div><span class="generated-badge">✦ AI-generated</span><h4>${escapeHtml(item.title)}</h4><p>${escapeHtml(formatDate(item.created_at))}</p></div><span class="saved-check">Saved</span></article>`).join('')}</div>` : emptyState(emptyTitle, 'Saved items will appear here and remain linked to your account.');
}
function renderSavedItems() {
  renderSavedList('#saved-assessments', savedByContext.assessment, 'No saved assessments');
  renderSavedList('#saved-coaching', savedByContext.coaching, 'No saved coaching summaries');
  renderSavedList('#saved-plans', savedByContext.development_plan, 'No saved development plans');
}

function renderCoachStarters() {
  const recommendations = activeResult()?.coaching || [];
  $('#coach-context').textContent = activePharmacist.name ? `FOR ${activePharmacist.name.toUpperCase()} · ${activePharmacist.grade} · ${activePharmacist.track.toUpperCase()}` : 'PRIVATE COACHING';
  $('#coach-starters').innerHTML = recommendations.length ? `<span>Evidence-informed starters</span>${recommendations.slice(0, 3).map(item => `<button type="button" data-starter="${escapeHtml(item.gap)}">${escapeHtml(item.gap)}</button>`).join('')}` : '';
}
async function loadConversations(force = false) {
  if (conversations.length && !force) {
    renderConversationList();
    return;
  }
  try {
    conversations = (await request('/api/coaching/conversations')).conversations;
    renderConversationList();
    if (!currentConversation && conversations.length) await openConversation(conversations[0].id);
    else renderChat();
  } catch (problem) {
    $('#coaching-status').textContent = problem.message;
  }
}
function renderConversationList() {
  $('#conversation-list').innerHTML = conversations.length ? conversations.map(item => `<button type="button" class="conversation-item ${currentConversation?.id === item.id ? 'active' : ''}" data-conversation-id="${item.id}"><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(formatDate(item.updated_at))}</span></button>`).join('') : emptyState('No conversations yet', 'Start a new coaching conversation when you are ready.');
}
async function createConversation() {
  const data = await request('/api/coaching/conversations', jsonOptions('POST', { title: 'New coaching conversation' }));
  conversations.unshift(data.conversation);
  currentConversation = data.conversation;
  conversationMessages = [];
  lastSummaryMessageId = null;
  renderConversationList();
  renderChat();
  $('#chat-input').focus();
  return data.conversation;
}
async function openConversation(id) {
  $('#coaching-status').textContent = 'Opening conversation…';
  try {
    const data = await request(`/api/coaching/conversations/${id}`);
    currentConversation = data.conversation;
    conversationMessages = data.messages;
    lastSummaryMessageId = [...conversationMessages].reverse().find(message => message.type === 'summary')?.id || null;
    renderConversationList();
    renderChat();
    $('#coaching-status').textContent = '';
  } catch (problem) {
    $('#coaching-status').textContent = problem.message;
  }
}
function renderChat() {
  renderCoachStarters();
  $('#conversation-title').textContent = currentConversation?.title || 'Start a conversation';
  $('#chat-messages').innerHTML = conversationMessages.length ? conversationMessages.map(message => {
    const actions = message.metadata?.action_items || [];
    return `<article class="chat-message ${message.role} ${message.type === 'summary' ? 'summary' : ''}"><div class="message-meta"><strong>${message.role === 'user' ? 'You' : message.type === 'summary' ? 'AI-generated summary' : 'PharmPath coach'}</strong>${message.is_ai_generated ? '<span class="generated-badge">✦ AI-generated</span>' : ''}</div><p>${escapeHtml(message.content)}</p>${actions.length ? `<h4>Actionable next steps</h4><ul>${actions.map(action => `<li>${escapeHtml(action)}</li>`).join('')}</ul>` : ''}</article>`;
  }).join('') : emptyState('A quiet place to think', 'Start with a goal, a challenge, or one of the evidence-informed prompts above.');
  $('#summarize-conversation').disabled = !conversationMessages.some(message => message.type === 'chat');
  $('#save-summary').disabled = !lastSummaryMessageId;
  $('#chat-messages').scrollTop = $('#chat-messages').scrollHeight;
}
async function sendMessage(event) {
  event.preventDefault();
  const input = $('#chat-input');
  const content = input.value.trim();
  if (!content) return;
  const button = $('#send-message');
  const status = $('#coaching-status');
  try {
    if (!currentConversation) await createConversation();
    input.value = '';
    conversationMessages.push({ id: `local-${Date.now()}`, role: 'user', type: 'chat', content, is_ai_generated: false, metadata: {} });
    renderChat();
    setBusy(button, true, 'Thinking…', 'Send');
    status.textContent = 'Your coach is thinking…';
    await request(`/api/coaching/conversations/${currentConversation.id}/messages`, jsonOptions('POST', { content }));
    await openConversation(currentConversation.id);
    conversations = (await request('/api/coaching/conversations')).conversations;
    currentConversation = conversations.find(item => item.id === currentConversation.id) || currentConversation;
    renderConversationList();
    status.textContent = '';
  } catch (problem) {
    status.textContent = problem.message;
    if (currentConversation) await openConversation(currentConversation.id);
  } finally {
    setBusy(button, false, 'Thinking…', 'Send');
  }
}
async function summarizeConversation() {
  const button = $('#summarize-conversation');
  const status = $('#coaching-status');
  if (!currentConversation) return;
  setBusy(button, true, 'Summarising…', 'Summarise');
  status.textContent = 'Creating a concise summary and next steps…';
  try {
    const data = await request(`/api/coaching/conversations/${currentConversation.id}/summary`, jsonOptions('POST', {}));
    conversationMessages.push(data.summary);
    lastSummaryMessageId = data.summary.id;
    renderChat();
    status.textContent = 'Summary ready. Review it, then save it if useful.';
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Summarising…', 'Summarise');
    button.disabled = !conversationMessages.some(message => message.type === 'chat');
  }
}
async function saveSummary() {
  const button = $('#save-summary');
  const status = $('#coaching-status');
  if (!currentConversation || !lastSummaryMessageId) return;
  setBusy(button, true, 'Saving…', 'Save summary');
  try {
    await request(`/api/coaching/conversations/${currentConversation.id}/summaries/${lastSummaryMessageId}/save`, jsonOptions('POST', {}));
    savedByContext.coaching = (await request('/api/saved-content?context=coaching')).items;
    renderSavedItems();
    status.textContent = 'AI-generated summary and next steps saved.';
    toast('Coaching summary saved.');
  } catch (problem) {
    status.textContent = problem.message;
  } finally {
    setBusy(button, false, 'Saving…', 'Save summary');
  }
}

function scoreClass(score) {
  if (score >= 75) return 'high';
  if (score >= 50) return 'mid';
  if (score >= 25) return 'mid-low';
  return 'low';
}
function dashboardRowsFor(scope, rows) {
  const grade = $(`#${scope}-grade-filter`)?.value || '';
  const section = $(`#${scope}-section-filter`)?.value || '';
  return rows.filter(row => (!grade || row.grade === grade) && (!section || row.section === section));
}
function syncDashboardFilters(scope, rows) {
  for (const [field, values] of [['grade', [...new Set(rows.map(row => row.grade))]], ['section', [...new Set(rows.map(row => row.section))]]]) {
    const select = $(`#${scope}-${field}-filter`);
    if (!select) continue;
    const selected = select.value;
    select.innerHTML = `<option value="">All ${field === 'grade' ? 'job grades' : 'sections'}</option>${values.sort().map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('')}`;
    select.value = values.includes(selected) ? selected : '';
  }
}
async function loadTeamDashboard() {
  $('#team-score-body').innerHTML = '<tr><td colspan="10">Loading authorised team data…</td></tr>';
  try {
    const data = await request('/api/team-dashboard');
    teamRows = data.profiles;
    syncDashboardFilters('team', teamRows);
    const rows = dashboardRowsFor('team', teamRows);
    $('#team-data-note').textContent = `${data.source} · ${rows.length} staff shown`;
    $('#team-score-body').innerHTML = rows.map(profile => {
      const index = teamRows.indexOf(profile);
      const scores = profile.assessment?.domain_scores || [];
      const status = profile.assessment ? (profile.assessment.status === 'submitted' ? 'Submitted' : 'AI / draft') : 'Not assessed';
      return `<tr class="${profile.assessment ? '' : 'not-analysed'}"><td><button class="team-staff-button" data-team-profile="${index}">${escapeHtml(profile.name)}<small>Review assessment →</small></button></td><td><strong>${escapeHtml(profile.grade)} · ${escapeHtml(profile.track)}</strong><small>${escapeHtml(profile.section)} · RO: ${escapeHtml(profile.reporting_officer || 'Not listed')}</small></td>${framework.map((_, scoreIndex) => Number.isFinite(scores[scoreIndex]) ? `<td><span class="team-score ${scoreClass(scores[scoreIndex])}">${scores[scoreIndex]}</span></td>` : '<td><span class="team-score empty">—</span></td>').join('')}<td><span class="overall-score ${profile.assessment ? 'mid' : 'empty'}">${escapeHtml(status)}</span></td></tr>`;
    }).join('') || '<tr><td colspan="10">No pharmacist profiles were found.</td></tr>';
    renderCompetencyLineChart(rows, '#team-line-chart', '#team-chart-note', 'reportee');
  } catch (problem) {
    $('#team-score-body').innerHTML = `<tr><td colspan="10">${escapeHtml(problem.message)}</td></tr>`;
    $('#team-line-chart').innerHTML = emptyState('Chart unavailable', problem.message);
  }
}

async function loadDivisionDashboard() {
  $('#division-score-body').innerHTML = '<tr><td colspan="10">Loading authorised division data…</td></tr>';
  try {
    const data = await request('/api/division-dashboard');
    divisionRows = data.profiles;
    syncDashboardFilters('division', divisionRows);
    const rows = dashboardRowsFor('division', divisionRows);
    $('#division-data-note').textContent = `${data.source} · ${rows.length} staff shown`;
    $('#division-score-body').innerHTML = rows.map(profile => {
      const scores = profile.assessment?.domain_scores || [];
      const status = profile.assessment ? (profile.assessment.status === 'submitted' ? 'Submitted' : 'AI / draft') : 'Not assessed';
      return `<tr class="${profile.assessment ? '' : 'not-analysed'}"><td><strong>${escapeHtml(profile.name)}</strong></td><td><strong>${escapeHtml(profile.grade)} · ${escapeHtml(profile.track)}</strong><small>${escapeHtml(profile.section)} · RO: ${escapeHtml(profile.reporting_officer || 'Not listed')}</small></td>${framework.map((_, scoreIndex) => Number.isFinite(scores[scoreIndex]) ? `<td><span class="team-score ${scoreClass(scores[scoreIndex])}">${scores[scoreIndex]}</span></td>` : '<td><span class="team-score empty">—</span></td>').join('')}<td><span class="overall-score ${profile.assessment ? 'mid' : 'empty'}">${escapeHtml(status)}</span></td></tr>`;
    }).join('') || '<tr><td colspan="10">No pharmacist profiles were found.</td></tr>';
    renderCompetencyLineChart(rows, '#division-line-chart', '#division-chart-note', 'pharmacist');
  } catch (problem) {
    $('#division-score-body').innerHTML = `<tr><td colspan="10">${escapeHtml(problem.message)}</td></tr>`;
    $('#division-line-chart').innerHTML = emptyState('Chart unavailable', problem.message);
  }
}

async function switchDashboardScope(scope) {
  if (scope === 'division' && !currentUser?.capabilities.division_dashboard) return;
  if (scope === 'team' && !currentUser?.capabilities.team_dashboard) return;
  if (scope === 'individual' && !currentUser?.capabilities.reportee_assessment) return;
  $$('.dashboard-scope-tab').forEach(button => button.classList.toggle('active', button.dataset.dashboardScope === scope));
  $('#team-dashboard').classList.toggle('active-view', scope === 'team');
  $('#division-dashboard').classList.toggle('active-view', scope === 'division');
  $('#reportee-assessment').classList.toggle('active-view', scope === 'individual');
  $$('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.view === 'team-dashboard'));
  $('#crumb-label').textContent = 'Team Dashboard';
  if (scope === 'division') await loadDivisionDashboard();
  else if (scope === 'team') await loadTeamDashboard();
  else await loadReportees();
}

function linearTrend(rows) {
  const n = rows.length;
  const sumX = rows.reduce((sum, row) => sum + row.years_in_job_grade, 0);
  const sumY = rows.reduce((sum, row) => sum + row.assessment.percentage_met, 0);
  const sumXY = rows.reduce((sum, row) => sum + row.years_in_job_grade * row.assessment.percentage_met, 0);
  const sumXX = rows.reduce((sum, row) => sum + row.years_in_job_grade ** 2, 0);
  const denominator = n * sumXX - sumX ** 2;
  if (!denominator) return null;
  const slope = (n * sumXY - sumX * sumY) / denominator;
  return { slope, intercept: (sumY - slope * sumX) / n };
}
function renderCompetencyLineChart(rows, chartSelector, noteSelector, noun) {
  const valid = rows.map((row, index) => ({ ...row, rowIndex: index })).filter(row => Number.isFinite(row.years_in_job_grade) && Number.isFinite(row.assessment?.percentage_met));
  const omitted = rows.length - valid.length;
  $(noteSelector).textContent = omitted ? `${omitted} ${noun}${omitted === 1 ? '' : 's'} omitted for missing tenure or assessment data` : `${valid.length} ${noun}${valid.length === 1 ? '' : 's'} plotted`;
  if (!valid.length) {
    $(chartSelector).innerHTML = emptyState('No valid chart data yet', 'Add years in current job grade to the profile CSV and complete an assessment to plot a pharmacist.');
    return;
  }
  const palette = ['#009CA2', '#12458D', '#3e79bd', '#5b8fc9', '#74bec1', '#496a92'];
  const groups = [...new Set(valid.map(row => row.section || row.track))];
  const colourFor = group => palette[groups.indexOf(group) % palette.length];
  const width = 820, height = 390, left = 72, right = 28, top = 24, bottom = 64;
  const xMax = Math.max(1, Math.ceil(Math.max(...valid.map(row => row.years_in_job_grade))));
  const x = value => left + value / xMax * (width - left - right);
  const y = value => top + (100 - value) / 100 * (height - top - bottom);
  const yGrid = [0, 20, 40, 60, 80, 100].map(value => `<g class="scatter-grid"><line x1="${left}" y1="${y(value)}" x2="${width - right}" y2="${y(value)}"></line><text x="${left - 13}" y="${y(value) + 4}" text-anchor="end">${value}%</text></g>`).join('');
  const xTicks = Array.from({ length: Math.min(xMax, 8) + 1 }, (_, index) => index * xMax / Math.min(xMax, 8)).map(value => `<g class="scatter-grid"><line x1="${x(value)}" y1="${top}" x2="${x(value)}" y2="${height - bottom}"></line><text x="${x(value)}" y="${height - bottom + 24}" text-anchor="middle">${Number.isInteger(value) ? value : value.toFixed(1)}</text></g>`).join('');
  const trends = groups.map(group => {
    const groupRows = valid.filter(row => (row.section || row.track) === group);
    const trend = groupRows.length >= 2 ? linearTrend(groupRows) : null;
    if (!trend) return '';
    const minX = Math.min(...groupRows.map(row => row.years_in_job_grade));
    const maxX = Math.max(...groupRows.map(row => row.years_in_job_grade));
    const valueAt = years => Math.max(0, Math.min(100, trend.intercept + trend.slope * years));
    return `<line class="trend-line" x1="${x(minX)}" y1="${y(valueAt(minX))}" x2="${x(maxX)}" y2="${y(valueAt(maxX))}" stroke="${colourFor(group)}"></line>`;
  }).join('');
  const target = Math.round(valid.reduce((sum, row) => sum + (Number.isFinite(row.target_percentage) ? row.target_percentage : 80), 0) / valid.length);
  const points = valid.map(row => `<circle class="scatter-point" tabindex="0" role="button" aria-label="${escapeHtml(`${row.name}, ${row.assessment.percentage_met}% of standards met, ${row.years_in_job_grade} years in job grade. Activate to open Individual view.`)}" data-dashboard-row="${row.rowIndex}" cx="${x(row.years_in_job_grade)}" cy="${y(row.assessment.percentage_met)}" r="7" fill="${colourFor(row.section || row.track)}"></circle>`).join('');
  const legend = groups.map(group => `<span><i style="background:${colourFor(group)}"></i>${escapeHtml(group)}</span>`).join('');
  $(chartSelector).innerHTML = `<div class="scatter-wrap"><svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Percentage of competency standards met by years in current job grade">${yGrid}${xTicks}<line class="target-line" x1="${left}" y1="${y(target)}" x2="${width - right}" y2="${y(target)}"></line><text class="target-label" x="${width - right - 5}" y="${y(target) - 8}" text-anchor="end">${target}% average grade target</text>${trends}${points}<text class="axis-label" x="${(left + width - right) / 2}" y="${height - 10}" text-anchor="middle">Years in current job grade</text><text class="axis-label" transform="translate(18 ${(top + height - bottom) / 2}) rotate(-90)" text-anchor="middle">% standards met</text></svg><div class="chart-tooltip" role="status"></div></div><div class="scatter-legend">${legend}<span class="trend-key">Dotted lines show section trends</span></div>`;
  const tooltip = $(`${chartSelector} .chart-tooltip`);
  const showTooltip = (point, event) => {
    const row = rows[Number(point.dataset.dashboardRow)];
    tooltip.innerHTML = `<strong>${escapeHtml(row.name)}</strong><span>${row.assessment.percentage_met}% of standards met</span><span>${row.years_in_job_grade} years in job grade</span><span class="tooltip-action">Tap to open Individual view</span>`;
    const wrapRect = $(`${chartSelector} .scatter-wrap`).getBoundingClientRect();
    const pointRect = point.getBoundingClientRect();
    tooltip.style.left = `${Math.min(wrapRect.width - 230, Math.max(8, (event?.clientX || pointRect.left + pointRect.width / 2) - wrapRect.left + 12))}px`;
    tooltip.style.top = `${Math.max(8, (event?.clientY || pointRect.top) - wrapRect.top - 24)}px`;
    tooltip.classList.add('visible');
  };
  $$(`${chartSelector} .scatter-point`).forEach(point => {
    point.addEventListener('pointerenter', event => showTooltip(point, event));
    point.addEventListener('pointermove', event => showTooltip(point, event));
    point.addEventListener('focus', () => showTooltip(point));
    point.addEventListener('click', event => { showTooltip(point, event); openIndividualDashboard(rows[Number(point.dataset.dashboardRow)]); });
    point.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openIndividualDashboard(rows[Number(point.dataset.dashboardRow)]); } });
    point.addEventListener('pointerleave', () => tooltip.classList.remove('visible'));
    point.addEventListener('blur', () => tooltip.classList.remove('visible'));
  });
}

async function openIndividualDashboard(profile) {
  if (!profile?.user_id) return;
  selectedReportee = profile;
  await switchView('reportee-assessment');
}

async function loadReportees() {
  const select = $('#reportee-select');
  try {
    reportees = (await request('/api/reportees')).reportees;
    select.innerHTML = `<option value="">Select reportee</option>${reportees.map(row => `<option value="${escapeHtml(row.user_id)}">${escapeHtml(row.name)} · ${escapeHtml(row.grade)}</option>`).join('')}`;
    if (!selectedReportee && reportees.length) selectedReportee = reportees[0];
    if (selectedReportee) {
      select.value = selectedReportee.user_id;
      await loadReporteeAssessment(selectedReportee.user_id);
    } else {
      $('#reportee-content').classList.add('hidden');
      $('#reportee-empty').innerHTML = emptyState('No direct reportees', 'This tab is available only when a reporting relationship exists.');
    }
  } catch (problem) {
    $('#reportee-empty').innerHTML = emptyState('Reportee assessments unavailable', problem.message);
  }
}
async function loadReporteeAssessment(userId) {
  selectedReportee = reportees.find(row => row.user_id === userId) || null;
  if (!selectedReportee) return;
  $('#reportee-empty').innerHTML = emptyState('Loading coaching record', `Opening ${selectedReportee.name}'s coaching and development record.`);
  try {
    const [assessmentData, coachingData, evidenceData] = await Promise.all([
      request(`/api/reportee-assessments/${encodeURIComponent(userId)}`),
      request(`/api/reportees/${encodeURIComponent(userId)}/coaching-development`),
      request(`/api/reportees/${encodeURIComponent(userId)}/evidence`),
    ]);
    reporteeAssessment = assessmentData.assessment;
    reporteeCoachingDevelopment = coachingData;
    reporteeEvidence = evidenceData;
    reporteeDevelopmentResponse = { ...reporteeCoachingDevelopment.response, can_edit: Boolean(reporteeCoachingDevelopment.can_edit) };
    roResponseDraft = structuredClone(reporteeDevelopmentResponse);
    renderReporteeAssessment();
    showReporteeDetail('assessment');
  } catch (problem) {
    $('#reportee-content').classList.add('hidden');
    $('#reportee-empty').innerHTML = emptyState('Assessment unavailable', problem.message);
  }
}
function renderReporteeAssessment() {
  const record = reporteeCoachingDevelopment || { coaching_takeaways: [], development_objectives: {}, saved_development_plans: [], chat_history: [] };
  $('#reportee-empty').classList.add('hidden');
  $('#reportee-content').classList.remove('hidden');
  const grade = gradeProfiles[selectedReportee.grade] || gradeProfiles.P13;
  $('#reportee-grade-badge').textContent = selectedReportee.grade;
  $('#reportee-grade-title').textContent = `${selectedReportee.name} · ${grade[0]}`;
  $('#reportee-grade-description').textContent = `${selectedReportee.track} · ${selectedReportee.section} · ${selectedReportee.years_in_job_grade ?? 'Tenure not recorded'}${Number.isFinite(selectedReportee.years_in_job_grade) ? ' years in job grade' : ''}`;
  $('#reportee-submission-status').textContent = record.response?.updated_at ? `RO response updated ${formatDate(record.response.updated_at)}` : 'RO response not submitted';
  renderReporteeCompetency();
  $('#ro-coaching-takeaways').innerHTML = renderRoSavedItems(record.coaching_takeaways, 'No saved coaching takeaways');
  const objectives = record.development_objectives || {};
  const focus = objectives.focus_areas || [];
  const gaps = objectives.gaps || [];
  $('#ro-development-objectives').innerHTML = (focus.length || gaps.length) ? `<div class="ro-objective-list">${focus.map(item => `<article><strong>${escapeHtml(item.gap || item.recommendation_type || 'Focus area')}</strong><p>${escapeHtml(item.recommendation || '')}</p></article>`).join('')}${gaps.map(item => `<article><strong>${escapeHtml(item.standard_id || 'Development objective')}</strong><p>${escapeHtml(item.gap || item.evidence_needed || '')}</p></article>`).join('')}</div>` : emptyState('No development objectives saved', 'Objectives will appear after the reportee saves an evidence analysis.');
  $('#ro-saved-plans').innerHTML = renderRoSavedItems(record.saved_development_plans, 'No saved development plans');
  $('#ro-chat-history').innerHTML = record.chat_history?.length ? `<div class="ro-chat-history">${record.chat_history.map(chat => `<details><summary><strong>${escapeHtml(chat.title)}</strong><span>${escapeHtml(formatDate(chat.updated_at))}</span></summary><div>${chat.messages.length ? chat.messages.map(message => `<article class="ro-chat-message ${escapeHtml(message.role)}"><strong>${escapeHtml(message.role === 'assistant' ? 'AI Coaching Assistant' : 'Reportee')}</strong><p>${escapeHtml(message.content)}</p></article>`).join('') : '<p class="read-only-notes">No messages in this conversation.</p>'}</div></details>`).join('')}</div>` : emptyState('No coaching conversations', 'The reportee has not started an AI coaching conversation.');
  renderReporteeEvidence();
  renderReporteeDevelopmentEditor();
}
function renderReporteeEvidence() {
  const items = reporteeEvidence?.items || [];
  const reporteeId = selectedReportee?.user_id || '';
  $('#reportee-evidence-count').textContent = `${items.length} item${items.length === 1 ? '' : 's'}`;
  $('#reportee-evidence-list').innerHTML = items.length ? `<div class="reportee-evidence-list">${items.map(item => `<article><div class="file-icon">${fileIcon(item.filename)}</div><div><strong>${escapeHtml(item.filename)}</strong><span>${escapeHtml(item.mime_type || 'Saved evidence')} · ${escapeHtml(formatBytes(item.size_bytes || 0))}</span></div><time>${escapeHtml(formatDate(item.uploaded_at))}</time><button class="secondary-btn reportee-evidence-download" type="button" data-reportee-evidence-download="${escapeHtml(item.id)}" data-reportee-id="${escapeHtml(reporteeId)}" title="Download file" aria-label="Download ${escapeHtml(item.filename)}">Download</button></article>`).join('')}</div>` : emptyState('No submitted evidence', 'This staff member has not submitted evidence to their inbox yet.');
}
async function downloadReporteeEvidence(reporteeId, uploadId, button) {
  if (!reporteeId || !uploadId) return;
  setBusy(button, true, 'Downloading…', 'Download');
  try {
    const response = await fetch(apiUrl(`/api/reportees/${encodeURIComponent(reporteeId)}/evidence/${encodeURIComponent(uploadId)}/download`), { credentials: 'include' });
    if (!response.ok) {
      const data = await response.json().catch(() => null);
      throw new Error(apiError(data, response));
    }
    const disposition = response.headers.get('content-disposition') || '';
    const filename = disposition.match(/filename="?([^";]+)"?/i)?.[1] || 'evidence-download';
    const link = document.createElement('a');
    link.href = URL.createObjectURL(await response.blob());
    link.download = filename;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(link.href);
    toast('Download started.');
  } catch (problem) {
    toast(problem.message);
  } finally {
    if (button?.isConnected) setBusy(button, false, 'Downloading…', 'Download');
  }
}
function renderReporteeCompetency() {
  const hasAssessment = Boolean(reporteeAssessment);
  if (!hasAssessment) {
    $('#reportee-assessment-table').innerHTML = emptyState('Assessment not submitted', `${selectedReportee.name} has not submitted an assessment for reporting-officer review.`);
    $('#reportee-radar-chart').innerHTML = emptyState('No assessment data', 'No competency profile is available yet.');
    $('#reportee-assessment-total').textContent = '0 / 26 mapped';
    return;
  }
  const mappings = assessmentMappings(reporteeAssessment);
  $('#reportee-assessment-total').textContent = `${new Set(mappings.map(mapping => mapping.standardId)).size} / 26 mapped`;
  renderRadarChart(mappings, '#reportee-radar-chart');
  $('#reportee-assessment-table').innerHTML = reporteeAssessment.items.map(item => {
    const mapping = item.ai.mapping;
    return `<article class="assessment-finding editable-finding" data-officer-item="${escapeHtml(item.id)}"><div class="finding-heading"><div><strong>${escapeHtml(`${mapping.standard_id} ${mapping.standard_name}`)}</strong><small>${escapeHtml(mapping.activity_title)}</small></div><span class="source-badge effective-source">Using ${escapeHtml(item.effective.source.replaceAll('_', ' '))}</span></div><div class="assessment-layers reportee-review-layers"><section class="assessment-layer ai-assessment-layer"><span class="source-badge ai-source">✦ AI-generated · non-final</span><strong>${Math.round(item.ai.confidence_score * 100)}% confidence</strong><p>${escapeHtml(item.ai.justification)}</p></section><section class="assessment-layer submitted-layer"><span class="source-badge owner-source">Reportee-submitted · non-final after review</span><strong>${Math.round(item.reportee.confidence_score * 100)}% confidence</strong><p>${escapeHtml(item.reportee.justification || '')}</p></section><section class="assessment-layer officer-assessment-layer"><span class="source-badge officer-source">Reporting-officer final</span><label>Final confidence<select class="officer-confidence" required>${confidenceOptions(item.reporting_officer.confidence_score)}</select></label><label>Final written assessment<textarea class="officer-justification" rows="4" maxlength="5000" placeholder="Enter the authoritative final assessment." required>${escapeHtml(item.reporting_officer.justification || '')}</textarea></label><div class="item-save-row"><button class="secondary-btn save-officer-item" type="button">Save final</button><span class="item-save-status">${item.reporting_officer.saved_at ? `Saved ${escapeHtml(formatDate(item.reporting_officer.saved_at))}` : 'Not saved'}</span></div></section></div></article>`;
  }).join('');
}
function showReporteeDetail(name) {
  const coaching = name === 'coaching';
  const evidence = name === 'evidence';
  $('#reportee-assessment-pane').classList.toggle('hidden', coaching || evidence);
  $('#reportee-coaching-pane').classList.toggle('hidden', !coaching);
  $('#reportee-evidence-pane').classList.toggle('hidden', !evidence);
  $$('.reportee-detail-tab').forEach(button => {
    const active = button.dataset.reporteeDetail === name;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
}
function renderRoSavedItems(items = [], emptyTitle) {
  return items.length ? `<div class="ro-saved-list">${items.map(item => `<article><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(formatDate(item.created_at))}</span></article>`).join('')}</div>` : emptyState(emptyTitle, 'Items saved by the reportee will appear here.');
}
function renderReporteeDevelopmentEditor() {
  const response = roResponseDraft || { action_items: [], discussion_notes: '' };
  if (!reporteeDevelopmentResponse?.can_edit) {
    $('#ro-plan-editor').innerHTML = '<p class="read-only-notes">This record is read-only. Only the reportee’s direct Reporting Officer can submit an RO response.</p>';
    return;
  }
  const items = response.action_items?.length ? response.action_items : [{ action_item: '', target_date: '', support_needed: '' }];
  $('#ro-plan-editor').innerHTML = `<div id="ro-action-list">${items.map(item => `<div class="ro-action-editor"><textarea class="ro-action-item" rows="3" maxlength="1000" placeholder="Agreed action item">${escapeHtml(item.action_item)}</textarea><input class="ro-target-date" maxlength="120" placeholder="Target date" value="${escapeHtml(item.target_date)}"><textarea class="ro-support-needed" rows="3" maxlength="1000" placeholder="Support needed from RO">${escapeHtml(item.support_needed)}</textarea><button type="button" class="remove-action">Remove</button></div>`).join('')}</div><div class="ro-notes-editor"><label for="ro-discussion-notes">RO discussion notes</label><textarea id="ro-discussion-notes" maxlength="5000" placeholder="Record the discussion, feedback, and agreed follow-up.">${escapeHtml(response.discussion_notes || '')}</textarea></div><div class="ro-plan-actions"><button type="button" class="secondary-btn" id="add-ro-action">+ Add action</button><button type="button" class="secondary-btn" id="cancel-ro-plan">Cancel draft</button><button type="button" class="primary-btn" id="save-ro-plan">Submit RO response</button></div>`;
}
function captureRoResponseDraft() {
  if (!$('#ro-plan-editor')) return;
  roResponseDraft = {
    action_items: [...$$('.ro-action-editor')].map(row => ({ action_item: row.querySelector('.ro-action-item').value, target_date: row.querySelector('.ro-target-date').value, support_needed: row.querySelector('.ro-support-needed').value })),
    discussion_notes: $('#ro-discussion-notes')?.value || '',
  };
}
async function saveReporteeDevelopmentResponse() {
  captureRoResponseDraft();
  const action_items = roResponseDraft.action_items.map(item => ({ action_item: item.action_item.trim(), target_date: item.target_date.trim(), support_needed: item.support_needed.trim() })).filter(item => item.action_item || item.target_date || item.support_needed);
  const discussion_notes = roResponseDraft.discussion_notes.trim();
  const button = $('#save-ro-plan');
  setBusy(button, true, 'Saving…', 'Save response');
  try {
    reporteeDevelopmentResponse = (await request(`/api/reportees/${encodeURIComponent(selectedReportee.user_id)}/development-plan-response`, jsonOptions('PUT', { action_items, discussion_notes }))).response;
    roResponseDraft = structuredClone(reporteeDevelopmentResponse);
    reporteeCoachingDevelopment.response = reporteeDevelopmentResponse;
    renderReporteeDevelopmentEditor();
    $('#ro-plan-save-status').textContent = 'Response submitted. It is now available in the reportee’s read-only plan.';
    toast('RO response saved.');
  } catch (problem) { $('#ro-plan-save-status').textContent = problem.message; }
}
async function saveOfficerItem(itemId) {
  const row = document.querySelector(`[data-officer-item="${CSS.escape(itemId)}"]`);
  const rawScore = row.querySelector('.officer-confidence').value;
  const justification = row.querySelector('.officer-justification').value.trim();
  if (rawScore === '' || !justification) {
    row.querySelector('.item-save-status').textContent = 'Choose a score and enter a final assessment.';
    return;
  }
  const button = row.querySelector('.save-officer-item');
  setBusy(button, true, 'Saving…', 'Save final');
  try {
    reporteeAssessment = (await request(`/api/reportee-assessments/${encodeURIComponent(selectedReportee.user_id)}/items/${encodeURIComponent(itemId)}`, jsonOptions('PUT', { confidence_score: Number(rawScore), justification }))).assessment;
    renderReporteeAssessment();
    $('#reportee-save-status').textContent = 'Final assessment saved. The reportee radar chart is up to date.';
    toast('Final assessment saved.');
  } catch (problem) {
    $('#reportee-save-status').textContent = problem.message;
  } finally {
    if (button.isConnected) setBusy(button, false, 'Saving…', 'Save final');
  }
}

function renderAll() {
  renderEvidence();
  renderCoverage();
  renderAssessment();
  renderPlan();
  renderCoachStarters();
}

$('#login-form').addEventListener('submit', login);
$('#logout-button').addEventListener('click', logout);
$$('.nav-item,[data-view]').forEach(button => button.addEventListener('click', () => switchView(button.dataset.view)));
$('#browse-btn').addEventListener('click', () => $('#file-input').click());
$('#file-input').addEventListener('change', event => { addFiles(event.target.files); event.target.value = ''; });
const dropZone = $('#drop-zone');
['dragenter', 'dragover'].forEach(name => dropZone.addEventListener(name, event => { event.preventDefault(); dropZone.classList.add('dragging'); }));
['dragleave', 'drop'].forEach(name => dropZone.addEventListener(name, event => { event.preventDefault(); dropZone.classList.remove('dragging'); }));
dropZone.addEventListener('drop', event => addFiles(event.dataTransfer.files));
$('#paste-email').addEventListener('click', () => $('#paste-panel').classList.remove('hidden'));
$('#close-paste').addEventListener('click', () => $('#paste-panel').classList.add('hidden'));
$('#analyze-email').addEventListener('click', addEmailEvidence);
$('#analysis-approved').addEventListener('change', event => { $('#ai-status').textContent = event.target.checked ? 'Ready to analyze.' : 'Select the confirmation box before running analysis.'; });
$('#analyze-ai').addEventListener('click', analyzeWithOpenAI);
$('#domain-select').addEventListener('change', () => renderDomainChart(mapResult(activeResult())));
$('#save-assessment').addEventListener('click', saveAssessment);
$('#save-plan').addEventListener('click', savePlan);
$('#new-conversation').addEventListener('click', createConversation);
$('#chat-form').addEventListener('submit', sendMessage);
$('#summarize-conversation').addEventListener('click', summarizeConversation);
$('#save-summary').addEventListener('click', saveSummary);
$('#reportee-select').addEventListener('change', event => loadReporteeAssessment(event.target.value));
$('#development-objectives-toggle').addEventListener('click', () => {
  const button = $('#development-objectives-toggle');
  const expanded = button.getAttribute('aria-expanded') === 'true';
  button.setAttribute('aria-expanded', String(!expanded));
  $('#development-objectives').classList.toggle('hidden', expanded);
});
document.addEventListener('input', event => {
  if (event.target.closest('#ro-plan-editor')) captureRoResponseDraft();
  const row = event.target.closest('[data-owner-item],[data-officer-item]');
  if (!row || !event.target.matches('select,textarea')) return;
  row.classList.add('has-unsaved-changes');
  row.querySelector('.item-save-status').textContent = 'Unsaved changes';
});
document.addEventListener('click', event => {
  const reporteeEvidenceDownload = event.target.closest('[data-reportee-evidence-download]');
  if (reporteeEvidenceDownload) downloadReporteeEvidence(reporteeEvidenceDownload.dataset.reporteeId, reporteeEvidenceDownload.dataset.reporteeEvidenceDownload, reporteeEvidenceDownload);
  const submitEvidenceButton = event.target.closest('[data-evidence-submit]');
  if (submitEvidenceButton) submitEvidence(submitEvidenceButton.dataset.evidenceSubmit);
  const deleteEvidenceButton = event.target.closest('[data-evidence-delete]');
  if (deleteEvidenceButton) deleteEvidence(deleteEvidenceButton.dataset.evidenceDelete, deleteEvidenceButton.dataset.evidenceKind);
  const ownerSave = event.target.closest('.save-owner-item');
  if (ownerSave) saveOwnerItem(ownerSave.closest('[data-owner-item]').dataset.ownerItem).catch(problem => { $('#assessment-save-status').textContent = problem.message; });
  const officerSave = event.target.closest('.save-officer-item');
  if (officerSave) saveOfficerItem(officerSave.closest('[data-officer-item]').dataset.officerItem);
  if (event.target.closest('#add-ro-action')) {
    captureRoResponseDraft();
    $('#ro-action-list').insertAdjacentHTML('beforeend', '<div class="ro-action-editor"><textarea class="ro-action-item" rows="3" maxlength="1000" placeholder="Agreed action item"></textarea><input class="ro-target-date" maxlength="120" placeholder="Target date"><textarea class="ro-support-needed" rows="3" maxlength="1000" placeholder="Support needed from RO"></textarea><button type="button" class="remove-action">Remove</button></div>');
  }
  const removeAction = event.target.closest('.remove-action');
  if (removeAction) { removeAction.closest('.ro-action-editor').remove(); captureRoResponseDraft(); }
  if (event.target.closest('#cancel-ro-plan')) { roResponseDraft = structuredClone(reporteeDevelopmentResponse || { action_items: [], discussion_notes: '' }); renderReporteeDevelopmentEditor(); $('#ro-plan-save-status').textContent = 'Draft changes discarded.'; }
  if (event.target.closest('#save-ro-plan')) saveReporteeDevelopmentResponse();
  const reporteeDetail = event.target.closest('[data-reportee-detail]');
  if (reporteeDetail) showReporteeDetail(reporteeDetail.dataset.reporteeDetail);
  const conversation = event.target.closest('[data-conversation-id]');
  if (conversation) openConversation(conversation.dataset.conversationId);
  const teamProfile = event.target.closest('[data-team-profile]');
  if (teamProfile) {
    const row = teamRows[Number(teamProfile.dataset.teamProfile)];
    selectedReportee = row;
    switchDashboardScope('individual');
  }
  const starter = event.target.closest('[data-starter],[data-coach-gap]');
  if (starter) {
    $('#chat-input').value = `Help me work through this development area: ${starter.dataset.starter || starter.dataset.coachGap}`;
    switchView('coaching-development').then(() => $('#chat-input').focus());
  }
});
$$('.plan-tab').forEach(button => button.addEventListener('click', () => {
  $$('.plan-tab').forEach(item => item.classList.toggle('active', item === button));
  $('#gaps-plan').classList.toggle('hidden', button.dataset.plan !== 'gaps');
  $('#activities-plan').classList.toggle('hidden', button.dataset.plan !== 'activities');
}));
$$('.dashboard-scope-tab').forEach(button => button.addEventListener('click', () => switchDashboardScope(button.dataset.dashboardScope)));
$('#team-grade-filter').addEventListener('change', loadTeamDashboard);
$('#team-section-filter').addEventListener('change', loadTeamDashboard);
$('#division-grade-filter').addEventListener('change', loadDivisionDashboard);
$('#division-section-filter').addEventListener('change', loadDivisionDashboard);
$('#clear-team-filters').addEventListener('click', () => { $('#team-grade-filter').value = ''; $('#team-section-filter').value = ''; loadTeamDashboard(); });
$('#clear-division-filters').addEventListener('click', () => { $('#division-grade-filter').value = ''; $('#division-section-filter').value = ''; loadDivisionDashboard(); });
$('#dashboard-export').addEventListener('click', () => toast('Dashboard export preview ready.'));
$('#export-btn').addEventListener('click', () => toast('Plan export preview ready.'));
window.addEventListener('popstate', () => currentUser && switchView(location.hash.replace('#', '') || 'overview', false));

authenticate();
