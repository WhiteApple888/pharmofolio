import { STATIC_ASSETS } from './assets.js';
import { handleHostedRequest } from './hosted-backend.js';

const DFP_STANDARDS = [
  ['1.1','Expert Professional Practice','Demonstrates expert skills and knowledge'],['1.2','Expert Professional Practice','Manages patient care responsibilities / delivery of professional activities'],['1.3','Expert Professional Practice','Exhibits reasoning and judgement'],['1.4','Expert Professional Practice','Uses professional autonomy'],
  ['2.1','Building Working Relationships','Ability to communicate effectively'],['2.2','Building Working Relationships','Collaborates with members of the health care team and offer consultations'],
  ['3.1','Leadership','Visioning'],['3.2','Leadership','Strategic planning'],['3.3','Leadership','Innovation'],['3.4','Leadership','Motivates individual'],
  ['4.1','Management','Implementing organisational priorities'],['4.2','Management','Managing resource utilisation'],['4.3','Management','Establishing standards of practice'],['4.4','Management','Managing risk'],['4.5','Management','Managing performance'],['4.6','Management','Managing change'],
  ['5.1','Education, Training and Development','Developing self and others'],['5.2','Education, Training and Development','Conducting education and training'],
  ['6.1','Research and Evaluation','Evaluating literature/data critically and identifying evidence/practice gaps'],['6.2','Research and Evaluation','Developing and evaluating protocols'],['6.3','Research and Evaluation','Disseminating evidence'],['6.4','Research and Evaluation','Guiding others undertaking research/project'],['6.5','Research and Evaluation','Establishing partnerships'],
  ['7.1','Professionalism','Professionalism and Code of Ethics'],['7.2','Professionalism','Compliance to Legal Frameworks and Requirements'],['7.3','Professionalism','Ethical Practice']
];

const RESULT_SCHEMA = {type:'object',additionalProperties:false,required:['activities','mappings','gaps','coaching'],properties:{
  activities:{type:'array',items:{type:'object',additionalProperties:false,required:['title','summary','date_or_period','setting','role','stakeholders','outcomes','source_reference'],properties:{title:{type:'string'},summary:{type:'string'},date_or_period:{type:'string'},setting:{type:'string'},role:{type:'string'},stakeholders:{type:'array',items:{type:'string'}},outcomes:{type:'string'},source_reference:{type:'string'}}}},
  mappings:{type:'array',items:{type:'object',additionalProperties:false,required:['activity_title','standard_id','standard_name','evidence_excerpt','source_reference','rationale','confidence','current_level','expected_level','gap'],properties:{activity_title:{type:'string'},standard_id:{type:'string'},standard_name:{type:'string'},evidence_excerpt:{type:'string'},source_reference:{type:'string'},rationale:{type:'string'},confidence:{type:'string',enum:['high','medium','low']},current_level:{type:'string',enum:['Foundation','Intermediate','Advanced','Expert','Not enough evidence']},expected_level:{type:'string',enum:['Foundation','Intermediate','Advanced','Expert','Track-dependent']},gap:{type:'string'}}}},
  gaps:{type:'array',items:{type:'object',additionalProperties:false,required:['standard_id','gap','evidence_needed','priority'],properties:{standard_id:{type:'string'},gap:{type:'string'},evidence_needed:{type:'string'},priority:{type:'string',enum:['high','medium','low']}}}},
  coaching:{type:'array',items:{type:'object',additionalProperties:false,required:['gap','recommendation_type','recommendation','owner_type','suggested_timeframe'],properties:{gap:{type:'string'},recommendation_type:{type:'string',enum:['topic','course','project','stretch assignment','workplace assessment']},recommendation:{type:'string'},owner_type:{type:'string'},suggested_timeframe:{type:'string'}}}}
}};

function promptFor(profile) {
  const standards = DFP_STANDARDS.map(([id,domain,name]) => `${id} — ${domain} — ${name}`).join('\n');
  return `You are a pharmacist development evidence analyst supporting pharmacists across all job grades and career tracks.\n\nMap only what the uploaded evidence supports to Singapore MOH Development Framework for Pharmacists 2024 v2.0. Do not make clinical treatment decisions, infer facts not present, or claim a formal assessment. Preserve a short exact evidence excerpt and source file reference for every mapping.\n\nProposed job grade: ${profile.grade || 'P13'}\nCareer track: ${profile.track || 'Clinical / Patient Care'}\n\nGrade thresholds: P12 >=80% Foundation+; P13 >=50% Intermediate+; P14 >=85% Intermediate+; P15 >=70% Advanced+; P16 >=80% Advanced+ with 20% Expert; P17 >=40% Expert; P18 >=50% Expert. Domain 7 professionalism is monitored across all grades. Distinguish current evidence from expected level, identify missing evidence, and recommend practical development actions.\n\nDFP standards:\n${standards}\n\nReturn only the structured response requested by the schema. Keep excerpts short, avoid patient-identifiable information where possible, and use Not enough evidence when a level cannot be supported.`;
}

function contentForFile(file) {
  if (file.text) return {type:'input_text',text:`SOURCE FILE: ${file.name || 'email thread'}\n${file.text}`};
  if (!file.dataUrl || !file.name) return null;
  return /\.(jpe?g|png|webp)$/i.test(file.name) ? {type:'input_image',image_url:file.dataUrl} : {type:'input_file',filename:file.name,file_data:file.dataUrl};
}

function outputText(data) {
  if (typeof data.output_text === 'string' && data.output_text.trim()) return data.output_text;
  const text = (data.output || []).flatMap(item => item.content || []).filter(content => content.type === 'output_text' && typeof content.text === 'string').map(content => content.text).join('');
  if (text) return text;
  throw new Error('OpenAI returned no structured text output. Please try the analysis again.');
}

async function mapEvidence(payload, env) {
  if (!env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured for this Site. Add it as a secret runtime environment variable.');
  const prompt = env.DFP_MAPPING_PROMPT || promptFor(payload.profile || {});
  const contents = [{type:'input_text',text:prompt}, ...(payload.files || []).map(contentForFile).filter(Boolean)];
  const response = await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${env.OPENAI_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:env.OPENAI_MODEL || 'gpt-5.4-mini',store:false,input:[{role:'user',content:contents}],text:{format:{type:'json_schema',name:'dfp_evidence_mapping',strict:true,schema:RESULT_SCHEMA}}})});
  const raw = await response.text();
  let data;
  try {
    data = raw.trim() ? JSON.parse(raw) : null;
  } catch {
    throw new Error(`OpenAI returned invalid JSON (${response.status}): ${raw.slice(0, 500)}`);
  }
  if (!response.ok) {
    throw new Error(data?.error?.message || `OpenAI request failed with ${response.status}`);
  }
  let result;
  try {
    result = JSON.parse(outputText(data));
  } catch {
    throw new Error('OpenAI returned output that did not match the expected JSON schema.');
  }
  return {model:env.OPENAI_MODEL || 'gpt-5.4-mini',response_id:data.id,result};
}

function json(body,status=200){return new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}})}
function embeddedAsset(pathname){const asset=STATIC_ASSETS[pathname==='/'?'/index.html':pathname];if(!asset)return new Response('Not found',{status:404});const body=asset.encoding==='base64'?Uint8Array.from(atob(asset.body),byte=>byte.charCodeAt(0)):asset.body;return new Response(body,{status:200,headers:{'Content-Type':asset.contentType,'Cache-Control':'no-cache, must-revalidate'}})}
async function proxyToBackend(request,env,url){
  if(!env.PHARMFOLIO_API_BASE_URL)return json({error:'The authenticated PharmPath backend is not configured for this deployment.'},503);
  const base=env.PHARMFOLIO_API_BASE_URL.replace(/\/$/,'');
  const target=new URL(url.pathname+url.search,base);
  const headers=new Headers(request.headers);
  headers.delete('host');
  headers.set('x-forwarded-host',url.host);
  headers.set('x-forwarded-proto',url.protocol.replace(':',''));
  return fetch(target,{method:request.method,headers,body:['GET','HEAD'].includes(request.method)?undefined:request.body,redirect:'manual'});
}
export default {async fetch(request,env){
  const url=new URL(request.url);
  const protectedPage=['/app','/team-dashboard','/division-dashboard','/reportee-assessment'].includes(url.pathname);
  if((url.pathname.startsWith('/api/')||protectedPage)&&env.PHARMFOLIO_API_BASE_URL)return proxyToBackend(request,env,url);
  if(url.pathname.startsWith('/api/')||protectedPage||url.pathname==='/health'){
    try{return await handleHostedRequest(request,env,url,{mapEvidence,embeddedAsset})}catch(problem){return json({error:problem?.message||'The hosted backend could not complete the request.'},Number(problem?.status)||500)}
  }
  if(request.method==='GET'&&STATIC_ASSETS[url.pathname])return embeddedAsset(url.pathname);
  if(env.ASSETS)return env.ASSETS.fetch(request);
  return new Response('Not found',{status:404});
}};
