import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const files = [
  ['/', 'index.html', 'text/html; charset=utf-8'],
  ['/index.html', 'index.html', 'text/html; charset=utf-8'],
  ['/app.js', 'app.js', 'text/javascript; charset=utf-8'],
  ['/styles.css', 'styles.css', 'text/css; charset=utf-8'],
  ['/runtime-config.js', 'runtime-config.example.js', 'text/javascript; charset=utf-8'],
  ['/nhg_health_logo.png', 'nhg_health_logo.png', 'image/png', 'base64'],
];
const entries = [];
for (const [pathname, filename, contentType, encoding] of files) {
  const body = await readFile(resolve(root, filename), encoding === 'base64' ? undefined : 'utf8');
  const value = encoding === 'base64' ? body.toString('base64') : body;
  entries.push(`  ${JSON.stringify(pathname)}: { body: ${JSON.stringify(value)}, contentType: ${JSON.stringify(contentType)}${encoding ? `, encoding: ${JSON.stringify(encoding)}` : ''} }`);
}
await writeFile(resolve(root, 'worker/assets.js'), `export const STATIC_ASSETS = {\n${entries.join(',\n')}\n};\n`);
