"""Shared runtime configuration, errors, and logging for Pharmfolio."""
