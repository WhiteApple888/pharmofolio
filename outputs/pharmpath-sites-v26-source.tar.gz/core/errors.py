"""Application exceptions translated by the API layer into safe responses."""


class PharmfolioError(Exception):
    """Base application error safe to present to an API client."""


class AuthorizationError(PharmfolioError):
    """Raised when the current actor cannot access a tenant/user resource."""


class ConfigurationError(PharmfolioError):
    """Raised when a required runtime configuration value is absent."""


class WorkflowError(PharmfolioError):
    """Raised when a workflow cannot safely complete."""
