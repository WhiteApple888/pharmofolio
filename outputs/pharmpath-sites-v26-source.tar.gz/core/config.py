"""Environment-backed application configuration."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime settings. Secrets are intentionally supplied only through the environment."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Pharmfolio"
    host: str = "127.0.0.1"
    port: int = 8000
    openai_api_key: str | None = None
    openai_model: str = "gpt-5.4-mini"
    database_url: str = "sqlite:///./data/pharmfolio.db"
    checkpoint_database_path: Path = Path("data/langgraph_checkpoints.db")
    document_storage_path: Path = Path("data/documents")
    profile_csv_path: Path = Path("pharmacist_profile.csv")
    confidence_review_threshold: float = 0.65
    max_body_bytes: int = 50 * 1024 * 1024
    max_upload_bytes: int = 25 * 1024 * 1024
    session_ttl_hours: int = 12
    session_cookie_secure: bool = False
    session_cookie_samesite: Literal["lax", "strict", "none"] = "strict"
    frontend_origins: str = ""

    @property
    def allowed_frontend_origins(self) -> list[str]:
        """Return explicitly configured origins for a separately hosted UI."""
        return [origin.strip().rstrip("/") for origin in self.frontend_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    """Return the singleton settings instance."""
    return Settings()
