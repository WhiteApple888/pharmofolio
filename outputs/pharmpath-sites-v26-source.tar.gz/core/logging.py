"""Logging configuration without sensitive evidence or prompt payloads."""
from __future__ import annotations

import logging


def configure_logging() -> None:
    """Configure the application's concise structured-style logger once."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
