// Keep this empty for same-origin FastAPI or a Worker reverse proxy.
// For a separately hosted frontend without a proxy, replace it with the public FastAPI URL.
window.PHARMFOLIO_API_BASE_URL = '';
