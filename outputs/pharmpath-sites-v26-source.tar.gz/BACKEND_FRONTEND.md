# Frontend and backend connection

## Local development

Run `python backend.py`, then open `http://127.0.0.1:8000`. FastAPI serves the browser application and the `/api/map` endpoint from the same origin, so no frontend setting is needed.

## Separate deployments

The preferred production shape is a same-origin reverse proxy: deploy FastAPI to a Python-capable host, then configure the frontend Worker/runtime with `PHARMFOLIO_API_BASE_URL` so `/api/*` and protected routes are proxied without exposing the backend origin to browser code.

For a direct cross-origin frontend, set `FRONTEND_ORIGINS` to the exact frontend URL, set `SESSION_COOKIE_SECURE=true` and `SESSION_COOKIE_SAMESITE=none`, and set `PHARMFOLIO_API_BASE_URL` in `runtime-config.js` to the public backend URL. Multiple allowed origins are comma-separated. Same-origin deployment is simpler and retains the stricter default cookie policy.

`runtime-config.js` is intentionally ignored by Git: it is deployment configuration, not a secret-bearing source file. The API key must remain only in the backend environment; it must never be added to browser JavaScript or frontend hosting settings.
