"""Typed request, response, and LLM boundary models."""
