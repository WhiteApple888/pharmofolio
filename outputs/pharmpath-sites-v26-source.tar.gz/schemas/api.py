"""Public API schemas, including the preserved legacy mapping contract."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class ProfileInput(BaseModel):
    """Profile fields accepted by the existing mapping endpoint."""

    name: str = ""
    grade: str = "P13"
    track: str = "Clinical / Patient Care"


class FileInput(BaseModel):
    """A browser-uploaded document or pasted evidence thread."""

    name: str = "uploaded evidence"
    text: str | None = None
    dataUrl: str | None = None


class LegacyMapRequest(BaseModel):
    """Unchanged request body accepted by POST /api/map."""

    profile: ProfileInput = Field(default_factory=ProfileInput)
    files: list[FileInput] = Field(default_factory=list)


class ActivityResponse(BaseModel):
    title: str
    summary: str
    date_or_period: str
    setting: str
    role: str
    stakeholders: list[str]
    outcomes: str
    source_reference: str


class MappingResponse(BaseModel):
    activity_title: str
    standard_id: str
    standard_name: str
    evidence_excerpt: str
    source_reference: str
    rationale: str
    confidence: Literal["high", "medium", "low"]
    confidence_score: float = Field(ge=0, le=1)
    current_level: Literal["Foundation", "Intermediate", "Advanced", "Expert", "Not enough evidence"]
    expected_level: Literal["Foundation", "Intermediate", "Advanced", "Expert", "Track-dependent"]
    gap: str


class GapResponse(BaseModel):
    standard_id: str
    gap: str
    evidence_needed: str
    priority: Literal["high", "medium", "low"]


class CoachingResponse(BaseModel):
    gap: str
    recommendation_type: Literal["topic", "course", "project", "stretch assignment", "workplace assessment"]
    recommendation: str
    owner_type: str
    suggested_timeframe: str


class LegacyMapResult(BaseModel):
    activities: list[ActivityResponse]
    mappings: list[MappingResponse]
    gaps: list[GapResponse]
    coaching: list[CoachingResponse]


class LegacyMapResponse(BaseModel):
    """Unchanged response envelope consumed by the shipped frontend."""

    model: str
    response_id: str | None = None
    result: LegacyMapResult


class PlanConfirmation(BaseModel):
    """The user's explicit confirmation of a development plan."""

    workflow_id: str
    accepted_action_ids: list[str]


class LoginRequest(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=1, max_length=256)


class SavedContentInput(BaseModel):
    context: Literal["assessment", "development_plan"]
    content_type: Literal["assessment_snapshot", "development_plan"]
    title: str = Field(min_length=1, max_length=250)
    body: str = Field(min_length=1, max_length=500_000)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ConversationCreate(BaseModel):
    title: str = Field(default="New coaching conversation", min_length=1, max_length=200)


class CoachingMessageInput(BaseModel):
    content: str = Field(min_length=1, max_length=10_000)


class PastedEvidenceInput(BaseModel):
    text: str = Field(min_length=1, max_length=500_000)
    filename: str = Field(default="Pasted Outlook thread.eml", min_length=1, max_length=500)


class UploadSaveInput(BaseModel):
    context: Literal["evidence", "assessment", "coaching", "development_plan"]
    name: str = Field(min_length=1, max_length=500)
    dataUrl: str = Field(min_length=1)


class AssessmentItemUpdate(BaseModel):
    """Validated human decision for a single assessment item."""

    confidence_score: float = Field(ge=0, le=1)
    justification: str = Field(min_length=1, max_length=5_000)
