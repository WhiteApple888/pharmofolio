"""Structured, non-decisional LLM output models."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ExtractedClaim(BaseModel):
    """An evidence-supported claim with document provenance."""

    statement: str
    source_document_id: str
    source_reference: str
    excerpt: str = Field(max_length=600)
    activity_title: str
    date_or_period: str = "Not stated"
    setting: str = "Not stated"
    role: str = "Not stated"
    stakeholders: list[str] = Field(default_factory=list)
    outcomes: str = "Not stated"


class ClaimExtraction(BaseModel):
    claims: list[ExtractedClaim]


class ProposedMapping(BaseModel):
    """A proposed mapping only; it is not a final competency rating."""

    activity_title: str
    standard_id: str
    standard_name: str
    source_document_id: str
    source_reference: str
    evidence_excerpt: str
    rationale: str
    suggested_level: Literal["Foundation", "Intermediate", "Advanced", "Expert", "Not enough evidence"]
    confidence_score: float = Field(ge=0, le=1)
    sensitivity_flags: list[Literal["promotion", "performance", "disciplinary", "patient_safety"]] = Field(default_factory=list)


class MappingProposalSet(BaseModel):
    mappings: list[ProposedMapping]


class GrowCoachingTurn(BaseModel):
    """GROW-oriented coaching suggestions constrained to validated gaps."""

    goal: str
    reality: str
    options: list[str]
    will: str
    recommendation_type: Literal["topic", "course", "project", "stretch assignment", "workplace assessment"]
    owner_type: str
    suggested_timeframe: str


class CoachingProposalSet(BaseModel):
    suggestions: list[GrowCoachingTurn]


class CoachingSummaryOutput(BaseModel):
    """Structured end-of-conversation summary and concrete follow-through."""

    summary: str
    action_items: list[str]
