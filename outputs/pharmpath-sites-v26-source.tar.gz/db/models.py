"""Tenant-scoped canonical database records; graph state is never the system of record."""
from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from sqlalchemy import Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, JSON, String, Text, UniqueConstraint, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def new_id() -> str:
    """Create an opaque identifier safe for client-facing references."""
    return str(uuid4())


def utc_now() -> datetime:
    """Return a naive UTC value for SQLite while avoiding deprecated utcnow()."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    """Base class for all canonical models."""


class Section(Base):
    """A source-controlled organisational section."""

    __tablename__ = "sections"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200, collation="NOCASE"), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Person(Base):
    """A named person from either the pharmacist or reporting-officer CSV columns."""

    __tablename__ = "people"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(200, collation="NOCASE"), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class PharmacistProfile(Base):
    """Pharmacist-specific source fields, separated from the reusable person identity."""

    __tablename__ = "pharmacist_profiles"
    __table_args__ = (
        CheckConstraint("job_grade GLOB 'P[0-9][0-9]'", name="ck_profile_job_grade"),
        CheckConstraint("source_row_number > 1", name="ck_profile_source_row"),
    )
    person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="CASCADE"), primary_key=True)
    job_grade: Mapped[str] = mapped_column(String(3))
    career_track: Mapped[str] = mapped_column(String(100))
    years_in_job_grade: Mapped[float | None] = mapped_column(Float, nullable=True)
    section_id: Mapped[int] = mapped_column(ForeignKey("sections.id", ondelete="RESTRICT"), index=True)
    source_row_number: Mapped[int] = mapped_column(Integer, unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=utc_now)


class ReportingLine(Base):
    """A pharmacist's reporting officer, including officers not otherwise profiled."""

    __tablename__ = "reporting_lines"
    __table_args__ = (CheckConstraint("pharmacist_person_id != supervisor_person_id", name="ck_reporting_not_self"),)
    pharmacist_person_id: Mapped[int] = mapped_column(ForeignKey("pharmacist_profiles.person_id", ondelete="CASCADE"), primary_key=True)
    supervisor_person_id: Mapped[int] = mapped_column(ForeignKey("people.id", ondelete="RESTRICT"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class User(Base):
    """Application account with a password verifier and server-authoritative permissions."""

    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("length(username) BETWEEN 3 AND 80", name="ck_user_username_length"),
        CheckConstraint("role IN ('pharmacist', 'team_lead', 'division_lead', 'admin')", name="ck_user_role"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    profile_id: Mapped[int] = mapped_column(ForeignKey("pharmacist_profiles.person_id", ondelete="RESTRICT"), unique=True, index=True)
    username: Mapped[str] = mapped_column(String(80, collation="NOCASE"), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="pharmacist")
    team_view: Mapped[bool] = mapped_column(Boolean, default=False)
    division_view: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=utc_now)


class UserSession(Base):
    """Opaque browser session; only a SHA-256 token digest is stored."""

    __tablename__ = "user_sessions"
    token_hash: Mapped[str] = mapped_column(String(64), primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class UploadedFile(Base):
    """User-owned upload metadata; bytes remain in document/object storage."""

    __tablename__ = "uploaded_files"
    __table_args__ = (
        CheckConstraint("context IN ('evidence', 'assessment', 'coaching', 'development_plan')", name="ck_upload_context"),
        CheckConstraint("size_bytes >= 0", name="ck_upload_size"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    context: Mapped[str] = mapped_column(String(30), index=True)
    original_filename: Mapped[str] = mapped_column(String(500))
    mime_type: Mapped[str] = mapped_column(String(150))
    size_bytes: Mapped[int] = mapped_column(Integer)
    storage_path: Mapped[str] = mapped_column(String(1200), unique=True)
    sha256: Mapped[str] = mapped_column(String(64))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)


class CoachingConversation(Base):
    """A user-owned conversational coaching thread."""

    __tablename__ = "coaching_conversations"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="New coaching conversation")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=utc_now, index=True)


class CoachingMessage(Base):
    """One authored or AI-generated item in a coaching conversation."""

    __tablename__ = "coaching_messages"
    __table_args__ = (
        CheckConstraint("author_role IN ('user', 'assistant')", name="ck_message_author_role"),
        CheckConstraint("message_type IN ('chat', 'summary')", name="ck_message_type"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    conversation_id: Mapped[str] = mapped_column(ForeignKey("coaching_conversations.id", ondelete="CASCADE"), index=True)
    author_role: Mapped[str] = mapped_column(String(20))
    message_type: Mapped[str] = mapped_column(String(20), default="chat")
    content: Mapped[str] = mapped_column(Text)
    is_ai_generated: Mapped[bool] = mapped_column(Boolean, default=False)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, index=True)


class SavedContent(Base):
    """Explicit user saves from the assessment, coaching, and planning surfaces."""

    __tablename__ = "saved_content"
    __table_args__ = (
        CheckConstraint("context IN ('assessment', 'coaching', 'development_plan')", name="ck_saved_context"),
        CheckConstraint("content_type IN ('assessment_snapshot', 'coaching_summary', 'development_plan')", name="ck_saved_content_type"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    context: Mapped[str] = mapped_column(String(30), index=True)
    content_type: Mapped[str] = mapped_column(String(40))
    title: Mapped[str] = mapped_column(String(250))
    body: Mapped[str] = mapped_column(Text)
    is_ai_generated: Mapped[bool] = mapped_column(Boolean, default=True)
    source_conversation_id: Mapped[str | None] = mapped_column(ForeignKey("coaching_conversations.id", ondelete="SET NULL"), nullable=True, index=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=utc_now)


class AssessmentRecord(Base):
    """One assessment cycle, with the immutable AI result kept separately from human edits."""

    __tablename__ = "assessment_records"
    __table_args__ = (
        CheckConstraint("status IN ('draft', 'submitted')", name="ck_assessment_record_status"),
        UniqueConstraint("workflow_id", name="uq_assessment_record_workflow"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    workflow_id: Mapped[str] = mapped_column(String(100), index=True)
    status: Mapped[str] = mapped_column(String(20), default="draft", index=True)
    ai_result_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now, index=True)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class AssessmentItem(Base):
    """Human decisions for one AI assessment item, preserving each provenance layer."""

    __tablename__ = "assessment_items"
    __table_args__ = (
        UniqueConstraint("assessment_id", "item_key", name="uq_assessment_item_key"),
        CheckConstraint("owner_confidence_score IS NULL OR (owner_confidence_score >= 0 AND owner_confidence_score <= 1)", name="ck_owner_confidence_range"),
        CheckConstraint("officer_confidence_score IS NULL OR (officer_confidence_score >= 0 AND officer_confidence_score <= 1)", name="ck_officer_confidence_range"),
    )
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    assessment_id: Mapped[str] = mapped_column(ForeignKey("assessment_records.id", ondelete="CASCADE"), index=True)
    item_key: Mapped[str] = mapped_column(String(120))
    standard_id: Mapped[str] = mapped_column(ForeignKey("dfp_standards.id", ondelete="RESTRICT"), index=True)
    owner_confidence_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    owner_justification: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_saved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    reviewer_user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    officer_confidence_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    officer_justification: Mapped[str | None] = mapped_column(Text, nullable=True)
    officer_saved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class TenantScoped:
    """Mixin requiring tenant and user ownership on every personal resource."""

    tenant_id: Mapped[str] = mapped_column(String(100), index=True)
    user_id: Mapped[str] = mapped_column(String(100), index=True)


class Evidence(TenantScoped, Base):
    """Metadata and durable location for a source document, not document bytes."""

    __tablename__ = "evidence"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    filename: Mapped[str] = mapped_column(String(500))
    storage_uri: Mapped[str] = mapped_column(String(1200))
    media_type: Mapped[str] = mapped_column(String(100), default="application/octet-stream")
    summary: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Claim(TenantScoped, Base):
    """An extracted claim with precise provenance back to canonical evidence."""

    __tablename__ = "claims"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    evidence_id: Mapped[str] = mapped_column(ForeignKey("evidence.id"), index=True)
    statement: Mapped[str] = mapped_column(Text)
    excerpt: Mapped[str] = mapped_column(Text)
    activity_title: Mapped[str] = mapped_column(String(500))
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class CompetencyAssessment(TenantScoped, Base):
    """A provisional, reviewable assessment; never an automatic final rating."""

    __tablename__ = "competency_assessments"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workflow_id: Mapped[str] = mapped_column(String(100), index=True)
    standard_id: Mapped[str] = mapped_column(ForeignKey("dfp_standards.id", ondelete="RESTRICT"), index=True)
    proposed_level: Mapped[str] = mapped_column(String(40))
    confidence_score: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(40), default="provisional")
    rationale: Mapped[str] = mapped_column(Text)
    provenance_json: Mapped[dict] = mapped_column(JSON, default=dict)
    sensitivity_flags: Mapped[list] = mapped_column(JSON, default=list)


class DevelopmentPlan(TenantScoped, Base):
    """A user-owned plan persisted only after explicit confirmation."""

    __tablename__ = "development_plans"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workflow_id: Mapped[str] = mapped_column(String(100), index=True)
    status: Mapped[str] = mapped_column(String(30), default="confirmed")
    actions_json: Mapped[list] = mapped_column(JSON, default=list)
    confirmed_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now)


class DfpStandard(Base):
    """Controlled DFP reference data."""

    __tablename__ = "dfp_standards"
    id: Mapped[str] = mapped_column(String(20), primary_key=True)
    domain: Mapped[str] = mapped_column(String(200))
    name: Mapped[str] = mapped_column(String(500))
    training_tracks_json: Mapped[list] = mapped_column(JSON, default=list)


class AuditRecord(TenantScoped, Base):
    """Append-only audit event for workflow and approval actions."""

    __tablename__ = "audit_records"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    event_type: Mapped[str] = mapped_column(String(100), index=True)
    workflow_id: Mapped[str] = mapped_column(String(100), index=True)
    details_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class DashboardMetric(TenantScoped, Base):
    """Materialised dashboard-ready progress emitted by the workflow."""

    __tablename__ = "dashboard_metrics"
    __table_args__ = (UniqueConstraint("tenant_id", "user_id", "workflow_id", name="uq_dashboard_workflow"),)
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    workflow_id: Mapped[str] = mapped_column(String(100), index=True)
    metric_json: Mapped[dict] = mapped_column(JSON, default=dict)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utc_now, onupdate=utc_now)
