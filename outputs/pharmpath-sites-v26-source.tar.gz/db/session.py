"""SQLAlchemy engine and session lifecycle."""
from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager

from sqlalchemy import create_engine, event, inspect, text
from sqlalchemy.orm import Session, sessionmaker

from core.config import Settings, get_settings


def build_session_factory(settings: Settings | None = None) -> sessionmaker[Session]:
    """Build a local-safe session factory. Production may use any SQLAlchemy URL."""
    settings = settings or get_settings()
    connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
    engine = create_engine(settings.database_url, connect_args=connect_args)
    if settings.database_url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def _enable_sqlite_integrity(dbapi_connection, _connection_record) -> None:
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    from db.models import Base

    Base.metadata.create_all(engine)
    _apply_compatible_migrations(engine)
    _seed_dfp_standards(engine)
    from db.seed import seed_profiles_and_users

    seed_profiles_and_users(engine, settings.profile_csv_path)
    return sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


def _apply_compatible_migrations(engine) -> None:
    """Apply additive compatibility changes for databases created before migrations existed."""
    columns = {column["name"] for column in inspect(engine).get_columns("pharmacist_profiles")}
    if "years_in_job_grade" not in columns:
        with engine.begin() as connection:
            connection.execute(text("ALTER TABLE pharmacist_profiles ADD COLUMN years_in_job_grade FLOAT"))


def _seed_dfp_standards(engine) -> None:
    """Seed controlled reference standards in the canonical database idempotently."""
    from sqlalchemy.orm import Session

    from db.models import DfpStandard
    from services.dfp_rules import DFP_STANDARDS

    with Session(engine) as session:
        for standard_id, domain, name in DFP_STANDARDS:
            if session.get(DfpStandard, standard_id) is None:
                session.add(DfpStandard(id=standard_id, domain=domain, name=name, training_tracks_json=[]))
        session.commit()


@contextmanager
def session_scope(factory: sessionmaker[Session]) -> Generator[Session, None, None]:
    """Yield a transaction, committing successful canonical changes."""
    session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
