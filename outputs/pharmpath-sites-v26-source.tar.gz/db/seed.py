"""Idempotent CSV-to-SQLite profile and demonstration-account import."""
from __future__ import annotations

import csv
from pathlib import Path

from sqlalchemy import Engine, delete, select, text, update
from sqlalchemy.orm import Session

from db.models import Person, PharmacistProfile, ReportingLine, Section, User
from services.security import hash_password

REQUIRED_COLUMNS = ["Pharmacist Name", "Pharmacist Job Grade", "Career Track", "RO", "Section", "team_view", "division_view", "Years in Job Grade"]
OPTIONAL_COLUMNS = ["team_view", "division_view", "Years in current job grade"]


def demo_password(name: str) -> str:
    """Deterministic demonstration password documented for local evaluation only."""
    return f"PharmPath-{name.strip().title()}!"


def seed_profiles_and_users(engine: Engine, csv_path: Path) -> None:
    """Upsert CSV source records and demo accounts without duplicating rows."""
    rows = _read_rows(csv_path)
    with Session(engine) as session:
        people: dict[str, Person] = {}

        def person_for(name: str) -> Person:
            key = name.casefold()
            if key not in people:
                person = session.scalar(select(Person).where(Person.full_name == name))
                if person is None:
                    person = Person(full_name=name)
                    session.add(person)
                    session.flush()
                people[key] = person
            return people[key]

        session.execute(delete(ReportingLine))
        # Avoid transient unique-key conflicts when CSV rows are reordered.
        session.execute(update(PharmacistProfile).values(source_row_number=PharmacistProfile.source_row_number + 100_000))
        for row_number, row in enumerate(rows, start=2):
            name = row["Pharmacist Name"].strip()
            section_name = row["Section"].strip()
            person = person_for(name)
            section = session.scalar(select(Section).where(Section.name == section_name))
            if section is None:
                section = Section(name=section_name)
                session.add(section)
                session.flush()
            profile = session.get(PharmacistProfile, person.id)
            if profile is None:
                profile = PharmacistProfile(person_id=person.id, job_grade=row["Pharmacist Job Grade"].strip(), career_track=row["Career Track"].strip(), years_in_job_grade=_years_in_job_grade(row), section_id=section.id, source_row_number=row_number)
                session.add(profile)
            else:
                profile.job_grade = row["Pharmacist Job Grade"].strip()
                profile.career_track = row["Career Track"].strip()
                profile.years_in_job_grade = _years_in_job_grade(row)
                profile.section_id = section.id
                profile.source_row_number = row_number

            ro_name = row["RO"].strip()
            if ro_name and ro_name.casefold() not in {"none", "n/a", "na", "-"}:
                supervisor = person_for(ro_name)
                session.add(ReportingLine(pharmacist_person_id=person.id, supervisor_person_id=supervisor.id))

            username = _username(name)
            user = session.scalar(select(User).where(User.username == username))
            role, team_view, division_view = _permissions(name, rows)
            if user is None:
                user = User(profile_id=person.id, username=username, password_hash=hash_password(demo_password(name)), role=role, team_view=team_view, division_view=division_view)
                session.add(user)
            else:
                user.profile_id = person.id
                user.role = role
                user.team_view = team_view
                user.division_view = division_view
                user.is_active = True
        session.commit()
    if engine.dialect.name == "sqlite":
        with engine.begin() as connection:
            connection.execute(text("PRAGMA optimize"))


def _read_rows(csv_path: Path) -> list[dict[str, str]]:
    path = csv_path.resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Profile CSV was not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        missing = [column for column in REQUIRED_COLUMNS if column not in fieldnames]
        unsupported = [column for column in fieldnames if column not in REQUIRED_COLUMNS + OPTIONAL_COLUMNS]
        if missing or unsupported:
            raise ValueError(f"Profile CSV must contain {REQUIRED_COLUMNS}; missing={missing}, unsupported={unsupported}")
        rows = list(reader)
    for row_number, row in enumerate(rows, start=2):
        if not all((row.get(column) or "").strip() for column in REQUIRED_COLUMNS if column != "RO"):
            raise ValueError(f"Profile CSV row {row_number} is missing a required value.")
    return rows


def _username(name: str) -> str:
    return "".join(character for character in name.casefold() if character.isalnum())


def _permissions(name: str, rows: list[dict[str, str]]) -> tuple[str, bool, bool]:
    managed_names = {
        row["RO"].strip().casefold()
        for row in rows
        if row["RO"].strip() and row["RO"].strip().casefold() not in {"none", "n/a", "na", "-"}
    }
    source_row = next(row for row in rows if row["Pharmacist Name"].strip().casefold() == name.strip().casefold())
    explicit_team = (source_row.get("team_view") or "").strip().casefold() in {"yes", "true", "1"}
    explicit_division = (source_row.get("division_view") or "").strip().casefold() in {"yes", "true", "1"}
    team_view = name.strip().casefold() in managed_names or explicit_team
    role = "division_lead" if explicit_division else "team_lead" if team_view else "pharmacist"
    return role, team_view, explicit_division


def _years_in_job_grade(row: dict[str, str]) -> float | None:
    """Parse optional tenure data without inventing a value when the source omits it."""
    raw = (row.get("Years in Job Grade") or row.get("Years in current job grade") or "").strip()
    if not raw:
        return None
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"Years in current job grade must be numeric; found {raw!r}") from exc
    if value < 0 or value > 60:
        raise ValueError("Years in current job grade must be between 0 and 60.")
    return value
