"""Canonical persistence for Pharmfolio records."""
