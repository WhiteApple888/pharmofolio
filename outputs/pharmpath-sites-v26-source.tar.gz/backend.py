"""Compatibility launcher for the modular Pharmfolio FastAPI/LangGraph backend."""
from __future__ import annotations

import uvicorn

from api.app import app
from core.config import get_settings


if __name__ == "__main__":
    settings = get_settings()
    uvicorn.run(app, host=settings.host, port=settings.port)
