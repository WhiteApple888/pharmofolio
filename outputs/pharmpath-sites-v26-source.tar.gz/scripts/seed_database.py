"""Recreate-safe SQLite schema and CSV seed entry point."""
from __future__ import annotations

from db.session import build_session_factory


if __name__ == "__main__":
    build_session_factory()
    print("SQLite schema and pharmacist demonstration accounts are ready.")
