# Pharmfolio backend, workflow architecture, and deployment

Pharmfolio keeps the existing `POST /api/map` browser contract while running the request through a LangGraph workflow. The browser uploads approved evidence to that route; it never receives the OpenAI API key.

## Architecture

The Python backend is organised into focused modules:

- `api/` keeps HTTP contracts and tenant/user actor resolution at the boundary.
- `workflows/` composes LangGraph nodes for capture, claim extraction, DFP mapping, deterministic assessment gates, human review, controlled GROW coaching, plan drafting, and dashboard updates.
- `db/` and `services/` hold canonical records, rules, document storage, audit, and metrics. Source bytes are saved beneath `data/documents`; graph state has IDs, filenames, summaries, and provenance only.
- SQLite is the local default for both canonical application records (`data/pharmfolio.db`) and resumable LangGraph checkpoints (`data/langgraph_checkpoints.db`). A production deployment can change `DATABASE_URL` and replace the local document store with object storage.

LLMs may extract evidence, propose mappings, and coach. They cannot finalise competency ratings, appraisals, or promotion decisions. Low-confidence (< 0.65) or sensitive proposals interrupt at a reviewer checkpoint. Development plans are stored only after the user calls the confirmation endpoint.

## Local development

1. Create `.env` from `.env.example` and supply `OPENAI_API_KEY`. Do not place it in `config.json` or source files.
2. Optionally set `OPENAI_MODEL`, `DATABASE_URL`, `CHECKPOINT_DATABASE_PATH`, and `DOCUMENT_STORAGE_PATH`.
3. Create a virtual environment, install dependencies, then run the compatibility launcher:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python backend.py
```

Open `http://127.0.0.1:8000`. `GET /health` returns `{"ok": true}`.

`POST /api/map` remains unchanged: it accepts `{ "profile": {...}, "files": [...] }` and returns `{ "model", "response_id", "result" }`, where `result` contains `activities`, `mappings`, `gaps`, and `coaching`.

New workflow APIs require `X-Tenant-ID`, `X-User-ID`, and `X-Role` (`pharmacist`, `reviewer`, or `admin`) when deployed behind an identity provider:

- `POST /api/workflows/{workflow_id}/review?decision=approved|rejected` resumes a reviewer checkpoint.
- `POST /api/plans/confirm` persists explicitly confirmed plan action IDs.

For compatibility with the standalone prototype, requests without identity headers use a constrained `local-development/local-user` identity. Replace this resolver with SSO middleware before a shared deployment.

## Hosted deployment

Sites now runs the authenticated application directly in the generated Worker. D1 stores users, sessions, reporting lines, assessments, coaching history, and saved content; R2 stores evidence-file bytes. The logical bindings are `DB` and `FILES` in `.openai/hosting.json`, and the checked-in Drizzle migration owns the hosted schema.

`PHARMFOLIO_API_BASE_URL` remains an optional proxy override for a separately hosted Python service. It is no longer required for Sites login or normal hosted operation.

Configure these runtime environment variables in Sites:

- `OPENAI_API_KEY` — secret value containing the OpenAI API key.
- `OPENAI_MODEL` — optional model override; the backend defaults to `gpt-5.4-mini`.

`DATABASE_URL`, `CHECKPOINT_DATABASE_PATH`, and `DOCUMENT_STORAGE_PATH` apply only to local Python or an optional external Python deployment; Sites provides D1/R2 bindings instead.

Set `OPENAI_API_KEY` as a **secret**, not as frontend JavaScript, `index.html`, `config.json`, or `hosting.json`. The frontend calls the same-origin authenticated Worker API.

Check `/health` after deployment; it should identify `sites-d1` and confirm database/object storage bindings. The API returns JSON error bodies for failed workflow calls, so the frontend can display an actionable status.

## Privacy

Only send evidence after the in-app privacy review is confirmed. Remove patient identifiers and confidential details whenever possible. This prototype provides developmental support and is not a formal competency assessment.
