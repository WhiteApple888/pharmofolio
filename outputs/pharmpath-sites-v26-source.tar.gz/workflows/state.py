"""Typed, checkpointed workflow state containing references and decisions, never source bytes."""
from __future__ import annotations

from typing import Literal, TypedDict


class WorkflowState(TypedDict, total=False):
    """Serializable state for one tenant/user-scoped workflow thread."""

    tenant_id: str
    user_id: str
    actor_role: Literal["pharmacist", "reviewer", "admin"]
    workflow_id: str
    profile: dict[str, str]
    evidence_refs: list[dict[str, str]]
    claims: list[dict]
    mappings: list[dict]
    gaps: list[dict]
    coaching_context: list[dict]
    coaching: list[dict]
    plan_draft: list[dict]
    dashboard_update: dict
    assessment_status: Literal["provisional", "human_review", "reviewed"]
    review_reason: str
    review_decision: Literal["approved", "rejected"] | None
    response_id: str | None
    workflow_status: Literal["running", "human_review", "awaiting_plan_confirmation", "complete"]
