"""Focused workflow nodes; all canonical writes occur through the repository boundary."""
from __future__ import annotations

from dataclasses import dataclass

from langgraph.types import interrupt

from db.models import Evidence
from schemas.api import ActivityResponse, CoachingResponse, MappingResponse
from schemas.llm import ExtractedClaim, ProposedMapping
from services.dfp_rules import confidence_label, derive_gaps, expected_level
from services.document_store import LocalDocumentStore
from services.repositories import PharmfolioRepository
from workflows.llm import PharmfolioLlm
from workflows.state import WorkflowState


@dataclass
class WorkflowDependencies:
    """Dependencies injected into a graph invocation rather than stored in state."""

    repository: PharmfolioRepository
    documents: LocalDocumentStore
    llm: PharmfolioLlm
    confidence_threshold: float


def capture_evidence(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Load tenant-authorised evidence metadata into source-reference-only graph state."""
    evidence = deps.repository.evidence_for(state["tenant_id"], state["user_id"], [item["id"] for item in state["evidence_refs"]])
    return {"evidence_refs": [{"id": item.id, "filename": item.filename, "summary": item.summary} for item in evidence], "workflow_status": "running"}


def extract_claims(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Interpret source evidence into provenance-rich claims and persist them canonically."""
    evidence = deps.repository.evidence_for(state["tenant_id"], state["user_id"], [item["id"] for item in state["evidence_refs"]])
    extraction = deps.llm.extract_claims([_model_document(item, deps.documents) for item in evidence])
    valid_document_ids = {item.id for item in evidence}
    claims = [claim for claim in extraction.claims if claim.source_document_id in valid_document_ids]
    deps.repository.save_claims(state["tenant_id"], state["user_id"], claims)
    deps.repository.audit(state["tenant_id"], state["user_id"], state["workflow_id"], "claims_extracted", {"count": len(claims)})
    return {"claims": [claim.model_dump() for claim in claims]}


def map_to_dfp(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Use the LLM only to propose controlled DFP mappings from extracted claims."""
    proposal = deps.llm.map_claims(state.get("claims", []), state["profile"])
    known_documents = {item["id"] for item in state["evidence_refs"]}
    mappings = [mapping for mapping in proposal.mappings if mapping.source_document_id in known_documents]
    return {"mappings": [mapping.model_dump() for mapping in mappings], "response_id": getattr(deps.llm, "last_response_id", None)}


def assess_competencies(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Apply deterministic confidence/sensitivity gates and save provisional assessments."""
    mappings = [ProposedMapping.model_validate(item) for item in state.get("mappings", [])]
    requires_review = any(item.confidence_score < deps.confidence_threshold or item.sensitivity_flags for item in mappings)
    status = "human_review" if requires_review else "provisional"
    deps.repository.save_assessments(state["tenant_id"], state["user_id"], state["workflow_id"], mappings, status)
    gaps = derive_gaps(mappings, state["profile"].get("grade", "P13"))
    reason = "Low confidence or sensitive assessment requires a qualified human reviewer." if requires_review else ""
    return {"gaps": [gap.model_dump() for gap in gaps], "assessment_status": status, "review_reason": reason, "workflow_status": "human_review" if requires_review else "running"}


def route_after_assessment(state: WorkflowState) -> str:
    """Route sensitive or uncertain outputs to the checkpointed human-review state."""
    return "human_review" if state["assessment_status"] == "human_review" else "coaching_context"


def human_review(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Pause at a human gate and resume only with a reviewer decision in checkpoints."""
    deps.repository.audit(state["tenant_id"], state["user_id"], state["workflow_id"], "human_review_requested", {"reason": state["review_reason"]})
    deps.repository.emit_dashboard(state["tenant_id"], state["user_id"], state["workflow_id"], {"workflow_id": state["workflow_id"], "assessment_status": "human_review", "evidence_count": len(state.get("evidence_refs", [])), "mapping_count": len(state.get("mappings", [])), "gap_count": len(state.get("gaps", [])), "coaching_count": 0, "plan_status": "human_review"})
    decision = interrupt({"kind": "competency_assessment_review", "workflow_id": state["workflow_id"], "reason": state["review_reason"]})
    if decision not in {"approved", "rejected"}:
        decision = "rejected"
    return {"review_decision": decision, "assessment_status": "reviewed", "workflow_status": "running"}


def route_after_review(state: WorkflowState) -> str:
    """Permit coaching only after an explicit human approval."""
    return "coaching_context" if state.get("review_decision") == "approved" else "dashboard"


def build_coaching_context(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Expose only deterministic, validated gap fields to the coaching model."""
    context = [{key: gap[key] for key in ("standard_id", "gap", "evidence_needed", "priority")} for gap in state.get("gaps", [])]
    return {"coaching_context": context}


def run_grow_coach(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Generate GROW coaching from controlled gap context, not raw appraisal information."""
    suggestions = deps.llm.coach(state.get("coaching_context", []), state["profile"])
    coaching = [CoachingResponse(gap=item.goal, recommendation_type=item.recommendation_type, recommendation=f"Reality: {item.reality} Options: {'; '.join(item.options)} Will: {item.will}", owner_type=item.owner_type, suggested_timeframe=item.suggested_timeframe).model_dump() for item in suggestions.suggestions]
    return {"coaching": coaching}


def draft_plan(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Create a draft only; a confirmation route is required before plan persistence."""
    draft = [{"id": f"action-{index}", **action} for index, action in enumerate(state.get("coaching", []), start=1)]
    deps.repository.audit(state["tenant_id"], state["user_id"], state["workflow_id"], "plan_drafted", {"count": len(draft)})
    return {"plan_draft": draft, "workflow_status": "awaiting_plan_confirmation"}


def emit_dashboard(state: WorkflowState, deps: WorkflowDependencies) -> dict:
    """Persist a compact dashboard metric projection in the canonical database."""
    metric = {"workflow_id": state["workflow_id"], "assessment_status": state["assessment_status"], "evidence_count": len(state.get("evidence_refs", [])), "claim_count": len(state.get("claims", [])), "mapping_count": len(state.get("mappings", [])), "gap_count": len(state.get("gaps", [])), "coaching_count": len(state.get("coaching", [])), "plan_status": state.get("workflow_status")}
    deps.repository.emit_dashboard(state["tenant_id"], state["user_id"], state["workflow_id"], metric)
    deps.repository.audit(state["tenant_id"], state["user_id"], state["workflow_id"], "dashboard_emitted", metric)
    return {"dashboard_update": metric}


def to_legacy_result(state: WorkflowState) -> dict:
    """Project graph output into the existing frontend response schema."""
    claims = [ExtractedClaim.model_validate(item) for item in state.get("claims", [])]
    activities = [ActivityResponse(title=item.activity_title, summary=item.statement, date_or_period=item.date_or_period, setting=item.setting, role=item.role, stakeholders=item.stakeholders, outcomes=item.outcomes, source_reference=item.source_reference).model_dump() for item in claims]
    expected = expected_level(state["profile"].get("grade", "P13"))
    mappings = [ProposedMapping.model_validate(item) for item in state.get("mappings", [])]
    legacy_mappings = [MappingResponse(activity_title=item.activity_title, standard_id=item.standard_id, standard_name=item.standard_name, evidence_excerpt=item.evidence_excerpt, source_reference=item.source_reference, rationale=item.rationale, confidence=confidence_label(item.confidence_score), confidence_score=item.confidence_score, current_level=item.suggested_level, expected_level=expected, gap=next((gap["gap"] for gap in state.get("gaps", []) if gap["standard_id"] == item.standard_id), "")).model_dump() for item in mappings]
    return {"activities": activities, "mappings": legacy_mappings, "gaps": state.get("gaps", []), "coaching": state.get("coaching", [])}


def _model_document(evidence: Evidence, documents: LocalDocumentStore) -> dict:
    """Build bounded model input without placing raw documents in graph state."""
    return {"document_id": evidence.id, "filename": evidence.filename, "content": documents.read_for_model(evidence.storage_uri)}
