"""Focused LangGraph nodes grouped by their workflow responsibility."""
