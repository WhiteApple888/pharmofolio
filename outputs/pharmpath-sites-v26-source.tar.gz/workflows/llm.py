"""Structured LLM gateway limited to evidence interpretation and coaching."""
from __future__ import annotations

from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from core.config import Settings
from core.errors import ConfigurationError
from schemas.llm import ClaimExtraction, CoachingProposalSet, CoachingSummaryOutput, MappingProposalSet
from workflows.prompts import COACHING_CHAT_PROMPT, COACHING_PROMPT, COACHING_SUMMARY_PROMPT, EXTRACTION_PROMPT, mapping_prompt


class PharmfolioLlm:
    """Calls the LLM with schema-bound outputs; never delegates business decisions to it."""

    def __init__(self, settings: Settings) -> None:
        if not settings.openai_api_key:
            raise ConfigurationError("OPENAI_API_KEY is not configured. Copy .env.example to .env and add your API key.")
        self.model_name = settings.openai_model
        self.model = ChatOpenAI(model=settings.openai_model, api_key=settings.openai_api_key, temperature=0)
        self.last_response_id: str | None = None

    def _invoke_structured(self, schema, messages):
        """Invoke a schema-bound response and retain its provider ID for API compatibility."""
        output = self.model.with_structured_output(schema, method="json_schema", include_raw=True).invoke(messages)
        if output.get("parsing_error"):
            raise output["parsing_error"]
        raw = output["raw"]
        self.last_response_id = raw.response_metadata.get("id") or getattr(raw, "id", None)
        return output["parsed"]

    def extract_claims(self, documents: list[dict]) -> ClaimExtraction:
        """Extract claims and provenance from bounded source content."""
        return self._invoke_structured(ClaimExtraction, [SystemMessage(EXTRACTION_PROMPT), HumanMessage(content=f"Documents:\n{documents}")])

    def map_claims(self, claims: list[dict], profile: dict[str, str]) -> MappingProposalSet:
        """Propose controlled DFP mappings from already-extracted claims."""
        return self._invoke_structured(MappingProposalSet, [SystemMessage(mapping_prompt()), HumanMessage(content=f"Profile: {profile}\nClaims: {claims}")])

    def coach(self, validated_gaps: list[dict], profile: dict[str, str]) -> CoachingProposalSet:
        """Produce GROW suggestions from validated gaps only."""
        return self._invoke_structured(CoachingProposalSet, [SystemMessage(COACHING_PROMPT), HumanMessage(content=f"Profile: {profile}\nValidated gaps: {validated_gaps}")])

    def coaching_message(self, history: list[dict[str, str]], profile: dict[str, str]) -> str:
        """Continue an existing GROW conversation using the central coaching policy."""
        messages = [SystemMessage(f"{COACHING_CHAT_PROMPT}\nPharmacist profile: {profile}")]
        for item in history[-20:]:
            messages.append(HumanMessage(item["content"]) if item["role"] == "user" else AIMessage(item["content"]))
        response = self.model.invoke(messages)
        self.last_response_id = response.response_metadata.get("id") or getattr(response, "id", None)
        return str(response.content).strip()

    def summarize_coaching(self, history: list[dict[str, str]]) -> CoachingSummaryOutput:
        """Create a schema-bound summary that remains explicitly AI-generated."""
        return self._invoke_structured(CoachingSummaryOutput, [SystemMessage(COACHING_SUMMARY_PROMPT), HumanMessage(content=f"Conversation:\n{history[-40:]}")])
