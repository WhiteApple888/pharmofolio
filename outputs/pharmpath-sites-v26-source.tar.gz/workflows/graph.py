"""Composition and checkpoint configuration for the Pharmfolio LangGraph workflow."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph

from workflows.nodes.workflow_nodes import WorkflowDependencies, assess_competencies, build_coaching_context, capture_evidence, draft_plan, emit_dashboard, extract_claims, human_review, map_to_dfp, route_after_assessment, route_after_review, run_grow_coach
from workflows.state import WorkflowState


def build_checkpointer(path: Path) -> SqliteSaver:
    """Create durable SQLite checkpoints for tenant/user-scoped workflow threads."""
    path.parent.mkdir(parents=True, exist_ok=True)
    return SqliteSaver(sqlite3.connect(str(path), check_same_thread=False))


def build_workflow(deps: WorkflowDependencies, checkpointer: SqliteSaver):
    """Compile focused nodes with a checkpointed human-review branch."""
    graph = StateGraph(WorkflowState)
    graph.add_node("capture", lambda state: capture_evidence(state, deps))
    graph.add_node("extract", lambda state: extract_claims(state, deps))
    graph.add_node("map", lambda state: map_to_dfp(state, deps))
    graph.add_node("assess", lambda state: assess_competencies(state, deps))
    graph.add_node("human_review", lambda state: human_review(state, deps))
    graph.add_node("coaching_context", lambda state: build_coaching_context(state, deps))
    graph.add_node("coach", lambda state: run_grow_coach(state, deps))
    graph.add_node("plan", lambda state: draft_plan(state, deps))
    graph.add_node("dashboard", lambda state: emit_dashboard(state, deps))
    graph.add_edge(START, "capture")
    graph.add_edge("capture", "extract")
    graph.add_edge("extract", "map")
    graph.add_edge("map", "assess")
    graph.add_conditional_edges("assess", route_after_assessment, {"human_review": "human_review", "coaching_context": "coaching_context"})
    graph.add_conditional_edges("human_review", route_after_review, {"coaching_context": "coaching_context", "dashboard": "dashboard"})
    graph.add_edge("coaching_context", "coach")
    graph.add_edge("coach", "plan")
    graph.add_edge("plan", "dashboard")
    graph.add_edge("dashboard", END)
    return graph.compile(checkpointer=checkpointer)
