"""Regression coverage for profile import, assessment ownership, and review precedence."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from api.app import create_app
from schemas.llm import ClaimExtraction, ExtractedClaim, MappingProposalSet


class FakeAssessmentLlm:
    model_name = "fake-model"

    def __init__(self, _settings) -> None:
        pass

    def extract_claims(self, documents):
        source = documents[0]
        return ClaimExtraction(claims=[ExtractedClaim(
            statement="Led a safe medicines reconciliation improvement.",
            source_document_id=source["document_id"],
            source_reference=source["filename"],
            excerpt="Led reconciliation improvement",
            activity_title="Medicines reconciliation",
            date_or_period="2026",
            setting="Hospital",
            role="Pharmacist",
            stakeholders=["ward team"],
            outcomes="Improved process",
        )])

    def map_claims(self, claims, _profile):
        from schemas.llm import ProposedMapping

        claim = claims[0]
        return MappingProposalSet(mappings=[ProposedMapping(
            activity_title=claim["activity_title"],
            standard_id="1.1",
            standard_name="Demonstrates expert skills and knowledge",
            source_document_id=claim["source_document_id"],
            source_reference=claim["source_reference"],
            evidence_excerpt=claim["excerpt"],
            rationale="AI rationale retained for audit.",
            suggested_level="Intermediate",
            confidence_score=0.9,
        )])

    def coach(self, _gaps, _profile):
        from schemas.llm import CoachingProposalSet

        return CoachingProposalSet(suggestions=[])


def login(client: TestClient, username: str) -> None:
    response = client.post("/api/auth/login", json={"username": username, "password": f"PharmPath-{username.title()}!"})
    assert response.status_code == 200


def create_alex_assessment(monkeypatch, settings) -> tuple[object, TestClient, dict]:
    monkeypatch.setattr("api.app.PharmfolioLlm", FakeAssessmentLlm)
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    mapped = alex.post("/api/map", json={
        "profile": {"name": "Sarah", "grade": "P17", "track": "Specialist"},
        "files": [{"name": "evidence.eml", "text": "Led reconciliation improvement."}],
    })
    assert mapped.status_code == 200
    assessment = alex.get("/api/assessment").json()["assessment"]
    return app, alex, assessment


def test_sarah_is_imported_as_a_real_user_and_has_relational_reportees(settings) -> None:
    app = create_app(settings)
    sarah = TestClient(app)
    login(sarah, "sarah")
    me = sarah.get("/api/auth/me").json()["user"]
    assert me["name"] == "Sarah"
    assert me["profile"]["grade"] == "P17"
    assert me["profile"]["track"] == "Specialist"
    assert me["profile"]["reporting_officer"] == "Tommy"
    assert me["capabilities"]["reportee_assessment"] is True
    assert [profile["name"] for profile in sarah.get("/api/profiles").json()["profiles"]] == ["Sarah"]
    assert {profile["name"] for profile in sarah.get("/api/reportees").json()["reportees"]} == {"Alex", "Jane", "Ben"}


def test_assessment_owner_and_direct_report_permissions_resist_modified_ids(monkeypatch, settings) -> None:
    app, alex, assessment = create_alex_assessment(monkeypatch, settings)
    item_id = assessment["items"][0]["id"]

    betty = TestClient(app)
    login(betty, "betty")
    assert betty.put(f"/api/assessment/items/{item_id}", json={"confidence_score": 0.5, "justification": "Tampered"}).status_code == 403
    assert betty.get(f"/api/reportee-assessments/{alex.get('/api/auth/me').json()['user']['id']}").status_code == 403

    saved = alex.put(f"/api/assessment/items/{item_id}", json={"confidence_score": 0.75, "justification": "My evidence-based final response."})
    assert saved.status_code == 200
    assert saved.json()["assessment"]["items"][0]["effective"]["source"] == "reportee_draft"
    assert alex.post("/api/assessment/submit", json={}).status_code == 200

    alex_id = alex.get("/api/auth/me").json()["user"]["id"]
    sarah = TestClient(app)
    login(sarah, "sarah")
    visible = sarah.get(f"/api/reportee-assessments/{alex_id}")
    assert visible.status_code == 200
    assert visible.json()["assessment"]["items"][0]["reportee"]["confidence_score"] == 0.75

    jane_id = next(row["user_id"] for row in sarah.get("/api/reportees").json()["reportees"] if row["name"] == "Jane")
    assert sarah.put(f"/api/reportee-assessments/{jane_id}/items/{item_id}", json={"confidence_score": 1, "justification": "Wrong reportee"}).status_code == 403


def test_reporting_officer_final_precedence_updates_team_chart_data(monkeypatch, settings) -> None:
    app, alex, assessment = create_alex_assessment(monkeypatch, settings)
    item_id = assessment["items"][0]["id"]
    alex.put(f"/api/assessment/items/{item_id}", json={"confidence_score": 0.25, "justification": "Submitted pharmacist response."})
    alex.post("/api/assessment/submit", json={})
    alex_id = alex.get("/api/auth/me").json()["user"]["id"]

    database_path = Path(settings.database_url.removeprefix("sqlite:///"))
    with sqlite3.connect(database_path) as connection:
        connection.execute("UPDATE pharmacist_profiles SET years_in_job_grade = 2.5 WHERE person_id = (SELECT id FROM people WHERE full_name = 'Alex')")

    sarah = TestClient(app)
    login(sarah, "sarah")
    final = sarah.put(f"/api/reportee-assessments/{alex_id}/items/{item_id}", json={"confidence_score": 1, "justification": "Reporting officer authoritative verdict."})
    assert final.status_code == 200
    layers = final.json()["assessment"]["items"][0]
    assert layers["ai"]["confidence_score"] == 0.9
    assert layers["reportee"]["confidence_score"] == 0.25
    assert layers["effective"] == {"confidence_score": 1.0, "justification": "Reporting officer authoritative verdict.", "source": "reporting_officer_final"}

    alex_row = next(row for row in sarah.get("/api/team-dashboard").json()["profiles"] if row["name"] == "Alex")
    assert alex_row["years_in_job_grade"] == 2.5
    assert alex_row["assessment"]["percentage_met"] == 4
    assert alex_row["assessment"]["domain_scores"][0] == 25


def test_coaching_context_uses_only_the_signed_in_users_assessment(monkeypatch, settings) -> None:
    app, alex, assessment = create_alex_assessment(monkeypatch, settings)
    item_id = assessment["items"][0]["id"]
    alex.put(f"/api/assessment/items/{item_id}", json={"confidence_score": 0.75, "justification": "Alex final response."})
    alex.post("/api/assessment/submit", json={})

    captured = {}

    class FakeCoach:
        def __init__(self, _settings) -> None:
            pass

        def coaching_message(self, _history, profile) -> str:
            captured.update(profile)
            return "What next step would help?"

    monkeypatch.setattr("api.app.PharmfolioLlm", FakeCoach)
    conversation = alex.post("/api/coaching/conversations", json={"title": "New coaching conversation"}).json()["conversation"]
    response = alex.post(f"/api/coaching/conversations/{conversation['id']}/messages", json={"content": "Help me reflect."})
    assert response.status_code == 200
    assert captured["name"] == "Alex"
    assert captured["assessment"]["items"][0]["pharmacist_value"]["justification"] == "Alex final response."
    assert captured["assessment"]["items"][0]["ai_generated"]["justification"] == "AI rationale retained for audit."


def test_division_ui_and_worker_route_are_permission_gated() -> None:
    root = Path(__file__).resolve().parents[1]
    assert 'id="division-dashboard-nav"' in (root / "index.html").read_text(encoding="utf-8")
    assert "capabilities.division_dashboard" in (root / "app.js").read_text(encoding="utf-8")
    assert "division-dashboard" in (root / "worker" / "index.js").read_text(encoding="utf-8")
    worker_backend = (root / "worker" / "hosted-backend.js").read_text(encoding="utf-8")
    assert "The authenticated PharmPath backend is not configured for this deployment." not in worker_backend
    assert "actor.divisionAccess" in worker_backend
    assert "directReportRows(db,actor)" in worker_backend


def test_chart_groups_sections_and_uses_average_grade_target() -> None:
    source = (Path(__file__).resolve().parents[1] / "app.js").read_text(encoding="utf-8")
    assert "row.section || row.track" in source
    assert "% average grade target" in source
    assert "Dotted lines show section trends" in source
