import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { DatabaseSync } from 'node:sqlite';

import { handleHostedRequest } from '../worker/hosted-backend.js';

class MockStatement {
  constructor(database, sql, values = []) { this.database = database; this.sql = sql; this.values = values; }
  bind(...values) { return new MockStatement(this.database, this.sql, values); }
  first() { return this.database.prepare(this.sql).get(...this.values) || null; }
  all() { return { results: this.database.prepare(this.sql).all(...this.values) }; }
  run() { return this.database.prepare(this.sql).run(...this.values); }
}

class MockD1 {
  constructor(database) { this.database = database; }
  prepare(sql) { return new MockStatement(this.database, sql); }
  async batch(statements) {
    this.database.exec('BEGIN');
    try {
      const results = statements.map(statement => statement.run());
      this.database.exec('COMMIT');
      return results;
    } catch (problem) {
      this.database.exec('ROLLBACK');
      throw problem;
    }
  }
}

async function environment() {
  const sqlite = new DatabaseSync(':memory:');
  sqlite.exec('PRAGMA foreign_keys = ON');
  for (const name of ['0000_blue_jean_grey.sql', '0001_stiff_klaw.sql', '0002_development_plan_responses.sql']) {
    const migration = await readFile(new URL(`../drizzle/${name}`, import.meta.url), 'utf8');
    for (const statement of migration.split('--> statement-breakpoint').map(value => value.trim()).filter(Boolean)) sqlite.exec(statement);
  }
  const objects = new Map();
  return { DB: new MockD1(sqlite), FILES: { put: async (key, value) => objects.set(key, value), get: async key => objects.has(key) ? { body: objects.get(key) } : null, delete: async key => objects.delete(key) } };
}

const dependencies = {
  mapEvidence: async () => ({ model: 'test', result: { activities: [], mappings: [], gaps: [], coaching: [] } }),
  embeddedAsset: () => new Response('<html></html>', { headers: { 'content-type': 'text/html' } }),
};

async function call(env, path, options = {}) {
  const request = new Request(`https://example.test${path}`, options);
  return handleHostedRequest(request, env, new URL(request.url), dependencies);
}

async function login(env, username) {
  const response = await call(env, '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ username, password: `PharmPath-${username[0].toUpperCase()}${username.slice(1)}!` }) });
  assert.equal(response.status, 200);
  return response.headers.get('set-cookie').split(';', 1)[0];
}

test('Sites-native authentication seeds Sarah from CSV and scopes team access', async () => {
  const env = await environment();
  const cookie = await login(env, 'sarah');
  const headers = { cookie };
  const me = await (await call(env, '/api/auth/me', { headers })).json();
  assert.equal(me.user.name, 'Sarah');
  assert.deepEqual(me.user.capabilities, { team_dashboard: true, reportee_assessment: true, division_dashboard: false });
  const team = await (await call(env, '/api/team-dashboard', { headers })).json();
  assert.deepEqual(team.profiles.map(row => row.name), ['Alex', 'Ben', 'Jane']);
  assert.equal((await call(env, '/api/division-dashboard', { headers })).status, 403);
  assert.equal((await call(env, '/api/reportee-assessments/user-benedict', { headers })).status, 403);
});

test('division_view sees the complete division while team data remains direct-only', async () => {
  const env = await environment();
  const cookie = await login(env, 'tommy');
  const headers = { cookie };
  const division = await (await call(env, '/api/division-dashboard', { headers })).json();
  assert.equal(division.profiles.length, 11);
  assert.ok(division.profiles.some(row => row.name === 'Sarah'));
  const team = await (await call(env, '/api/team-dashboard', { headers })).json();
  assert.deepEqual(team.profiles.map(row => row.name), ['Alice', 'Betty', 'Jack', 'Jamie', 'Sarah']);
  const health = await (await call(env, '/health')).json();
  assert.equal(health.backend, 'sites-d1');
});

test('evidence deletion is restricted to the uploading reportee and removes the stored object', async () => {
  const env = await environment();
  const alexCookie = await login(env, 'alex');
  const writeHeaders = { cookie: alexCookie, 'x-requested-with': 'PharmPath', 'content-type': 'application/json' };
  const created = await call(env, '/api/uploads', { method: 'POST', headers: writeHeaders, body: JSON.stringify({ context: 'evidence', name: 'reflection.txt', dataUrl: 'data:text/plain;base64,aGVsbG8=' }) });
  assert.equal(created.status, 200);
  const item = (await created.json()).item;
  assert.equal(item.can_delete, true);

  const sarahCookie = await login(env, 'sarah');
  const forbidden = await call(env, `/api/evidence/${item.id}`, { method: 'DELETE', headers: { cookie: sarahCookie, 'x-requested-with': 'PharmPath' } });
  assert.equal(forbidden.status, 404);

  const deleted = await call(env, `/api/evidence/${item.id}`, { method: 'DELETE', headers: { cookie: alexCookie, 'x-requested-with': 'PharmPath' } });
  assert.equal(deleted.status, 200);
  const remaining = await (await call(env, '/api/uploads?context=evidence', { headers: { cookie: alexCookie } })).json();
  assert.deepEqual(remaining.items, []);
});

test('reportee evidence metadata is visible to direct ROs and division viewers only', async () => {
  const env = await environment();
  const alexCookie = await login(env, 'alex');
  const writeHeaders = { cookie: alexCookie, 'x-requested-with': 'PharmPath', 'content-type': 'application/json' };
  const uploaded = await call(env, '/api/uploads', { method: 'POST', headers: writeHeaders, body: JSON.stringify({ context: 'evidence', name: 'reflection.txt', dataUrl: 'data:text/plain;base64,aGVsbG8=' }) });
  const item = (await uploaded.json()).item;

  const sarahCookie = await login(env, 'sarah');
  const direct = await call(env, '/api/reportees/user-alex/evidence', { headers: { cookie: sarahCookie } });
  assert.equal(direct.status, 200);
  const directPayload = await direct.json();
  assert.equal(directPayload.items.length, 1);
  assert.equal('can_delete' in directPayload.items[0], false);
  const directDownload = await call(env, `/api/reportees/user-alex/evidence/${item.id}/download`, { headers: { cookie: sarahCookie } });
  assert.equal(directDownload.status, 200);
  assert.equal(new TextDecoder().decode(await directDownload.arrayBuffer()), 'hello');

  const tommyCookie = await login(env, 'tommy');
  assert.equal((await call(env, '/api/reportees/user-alex/evidence', { headers: { cookie: tommyCookie } })).status, 200);
  assert.equal((await call(env, `/api/reportees/user-alex/evidence/${item.id}/download`, { headers: { cookie: tommyCookie } })).status, 200);
  assert.equal((await call(env, '/api/reportees/user-alex/evidence', { headers: { cookie: alexCookie } })).status, 403);
  assert.equal((await call(env, `/api/reportees/user-alex/evidence/${item.id}/download`, { headers: { cookie: alexCookie } })).status, 403);
});

test('division_view can open every Individual record but cannot edit a non-direct reportee', async () => {
  const env = await environment();
  const cookie = await login(env, 'tommy');
  const headers = { cookie };
  const reportees = await (await call(env, '/api/reportees', { headers })).json();
  assert.equal(reportees.reportees.length, 11);
  const assessment = await call(env, '/api/reportee-assessments/user-benedict', { headers });
  assert.equal(assessment.status, 200);
  const record = await (await call(env, '/api/reportees/user-benedict/coaching-development', { headers })).json();
  assert.equal(record.can_edit, false);
});

test('only a direct reporting officer can save a development-plan response and the reportee can read it', async () => {
  const env = await environment();
  const sarahCookie = await login(env, 'sarah');
  const sarahHeaders = { cookie: sarahCookie, 'x-requested-with': 'PharmPath', 'content-type': 'application/json' };
  const saved = await call(env, '/api/reportees/user-alex/development-plan-response', { method: 'PUT', headers: sarahHeaders, body: JSON.stringify({ action_items: [{ action_item: 'Lead the workshop', target_date: '15 Oct 2026', support_needed: 'Mentoring' }], discussion_notes: 'Discussed scope and support.' }) });
  assert.equal(saved.status, 200);
  const alexCookie = await login(env, 'alex');
  const own = await (await call(env, '/api/development-plan-response', { headers: { cookie: alexCookie } })).json();
  assert.equal(own.response.action_items[0].action_item, 'Lead the workshop');
  assert.equal(own.response.discussion_notes, 'Discussed scope and support.');
  const forbidden = await call(env, '/api/reportees/user-alex/development-plan-response', { method: 'PUT', headers: { cookie: alexCookie, 'x-requested-with': 'PharmPath', 'content-type': 'application/json' }, body: JSON.stringify({ action_items: [], discussion_notes: 'Attempted edit' }) });
  assert.equal(forbidden.status, 403);
});

test('the RO coaching-development record is direct-report-only and includes the submitted response', async () => {
  const env = await environment();
  const sarahCookie = await login(env, 'sarah');
  const headers = { cookie: sarahCookie, 'x-requested-with': 'PharmPath', 'content-type': 'application/json' };
  await call(env, '/api/reportees/user-alex/development-plan-response', { method: 'PUT', headers, body: JSON.stringify({ action_items: [{ action_item: 'Complete a peer review', target_date: 'Oct 2026', support_needed: 'Protected time' }], discussion_notes: 'Agreed at monthly check-in.' }) });
  const record = await (await call(env, '/api/reportees/user-alex/coaching-development', { headers: { cookie: sarahCookie } })).json();
  assert.equal(record.response.discussion_notes, 'Agreed at monthly check-in.');
  assert.equal(record.response.action_items[0].action_item, 'Complete a peer review');
  const alexCookie = await login(env, 'alex');
  assert.equal((await call(env, '/api/reportees/user-alex/coaching-development', { headers: { cookie: alexCookie } })).status, 403);
});
