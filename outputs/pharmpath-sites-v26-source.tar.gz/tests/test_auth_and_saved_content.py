"""Focused authentication, authorization, and ownership regression tests."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from api.app import create_app
from db.models import Person, PharmacistProfile, Section, User
from db.session import build_session_factory
from services.security import hash_password, verify_password
from schemas.llm import CoachingSummaryOutput


def login(client: TestClient, username: str) -> None:
    response = client.post("/api/auth/login", json={"username": username, "password": f"PharmPath-{username.title()}!"})
    assert response.status_code == 200


def test_password_hash_round_trip_and_plaintext_is_absent() -> None:
    encoded = hash_password("Memorable-passphrase!")
    assert verify_password("Memorable-passphrase!", encoded)
    assert not verify_password("wrong-password", encoded)
    assert "Memorable-passphrase!" not in encoded


def test_username_uniqueness_is_enforced_by_sqlite(settings) -> None:
    factory = build_session_factory(settings)
    with factory() as session:
        section = session.scalar(select(Section).limit(1))
        person = Person(full_name="Duplicate Username Test")
        session.add(person)
        session.flush()
        session.add(PharmacistProfile(person_id=person.id, job_grade="P12", career_track="Foundation", section_id=section.id, source_row_number=999))
        session.flush()
        session.add(User(profile_id=person.id, username="alex", password_hash=hash_password("Another-password!"), role="pharmacist"))
        with pytest.raises(IntegrityError):
            session.commit()


def test_team_and_division_permissions_cover_api_and_direct_routes(settings) -> None:
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    assert alex.get("/api/team-dashboard").status_code == 403
    assert alex.get("/team-dashboard").status_code == 403
    assert alex.get("/api/division-dashboard").status_code == 403
    assert alex.get("/division-dashboard").status_code == 403

    betty = TestClient(app)
    login(betty, "betty")
    betty_team = betty.get("/api/team-dashboard")
    assert betty_team.status_code == 200
    assert {row["name"] for row in betty_team.json()["profiles"]} == {"Benedict", "Jeremy"}
    assert betty.get("/team-dashboard").status_code == 200
    assert betty.get("/api/division-dashboard").status_code == 200
    assert betty.get("/division-dashboard").status_code == 200

    tommy = TestClient(app)
    login(tommy, "tommy")
    assert tommy.get("/api/team-dashboard").status_code == 200
    division = tommy.get("/api/division-dashboard")
    assert division.status_code == 200
    assert {row["name"] for row in division.json()["profiles"]} >= {"Alex", "Sarah", "Tommy"}
    assert tommy.get("/division-dashboard").status_code == 200
    assert tommy.get("/reportee-assessment").status_code == 200

    sarah = TestClient(app)
    login(sarah, "sarah")
    capabilities = sarah.get("/api/auth/me").json()["user"]["capabilities"]
    assert capabilities == {"team_dashboard": True, "reportee_assessment": True, "division_dashboard": False}
    assert {row["name"] for row in sarah.get("/api/team-dashboard").json()["profiles"]} == {"Alex", "Ben", "Jane"}
    assert sarah.get("/api/division-dashboard").status_code == 403


def test_logout_invalidates_server_session(settings) -> None:
    client = TestClient(create_app(settings))
    login(client, "alex")
    assert client.get("/api/auth/me").status_code == 200
    assert client.post("/api/auth/logout").status_code == 200
    assert client.get("/api/auth/me").status_code == 401


def test_saved_content_is_visible_only_to_its_owner(settings) -> None:
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    saved = alex.post("/api/saved-content", json={"context": "assessment", "content_type": "assessment_snapshot", "title": "Alex assessment", "body": "{\"mappings\": []}", "metadata": {}})
    assert saved.status_code == 200
    assert alex.get("/api/saved-content?context=assessment").json()["items"][0]["title"] == "Alex assessment"

    betty = TestClient(app)
    login(betty, "betty")
    assert betty.get("/api/saved-content?context=assessment").json()["items"] == []


def test_uploaded_file_metadata_and_download_are_owned(settings) -> None:
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    saved = alex.post("/api/uploads", json={"context": "evidence", "name": "reflection.txt", "dataUrl": "data:text/plain;base64,aGVsbG8="})
    assert saved.status_code == 200
    item = saved.json()["item"]
    assert item["filename"] == "reflection.txt"
    assert item["size_bytes"] == 5
    assert "storage_path" not in item
    assert alex.get(f"/api/uploads/{item['id']}/download").content == b"hello"

    betty = TestClient(app)
    login(betty, "betty")
    assert betty.get(f"/api/uploads/{item['id']}/download").status_code == 404
    assert betty.delete(f"/api/evidence/{item['id']}").status_code == 404

    assert alex.delete(f"/api/evidence/{item['id']}").json() == {"deleted": True, "id": item["id"]}
    assert alex.get(f"/api/uploads/{item['id']}/download").status_code == 404


def test_reportee_evidence_metadata_is_limited_to_direct_or_division_view(settings) -> None:
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    saved = alex.post("/api/uploads", json={"context": "evidence", "name": "reflection.txt", "dataUrl": "data:text/plain;base64,aGVsbG8="}).json()["item"]

    sarah = TestClient(app)
    login(sarah, "sarah")
    direct = sarah.get("/api/reportees/user-alex/evidence")
    assert direct.status_code == 200
    assert direct.json()["items"][0]["id"] == saved["id"]
    assert "can_delete" not in direct.json()["items"][0]
    assert sarah.get(f"/api/reportees/user-alex/evidence/{saved['id']}/download").content == b"hello"

    betty = TestClient(app)
    login(betty, "betty")
    assert betty.get("/api/reportees/user-alex/evidence").status_code == 200
    assert betty.get(f"/api/reportees/user-alex/evidence/{saved['id']}/download").status_code == 200
    assert alex.get("/api/reportees/user-alex/evidence").status_code == 403
    assert alex.get(f"/api/reportees/user-alex/evidence/{saved['id']}/download").status_code == 403


def test_invalid_login_is_non_revealing(settings) -> None:
    client = TestClient(create_app(settings))
    unknown = client.post("/api/auth/login", json={"username": "nobody", "password": "does-not-matter"})
    wrong = client.post("/api/auth/login", json={"username": "alex", "password": "does-not-matter"})
    assert unknown.status_code == wrong.status_code == 401
    assert unknown.json() == wrong.json()


def test_coaching_messages_summary_and_save_are_persistent_and_owned(monkeypatch, settings) -> None:
    class FakeCoach:
        def __init__(self, _settings) -> None:
            pass

        def coaching_message(self, history, profile) -> str:
            return f"What is one next step you could take in {profile['track']}?"

        def summarize_coaching(self, history) -> CoachingSummaryOutput:
            return CoachingSummaryOutput(summary="Alex identified a development goal.", action_items=["Book a discussion with the reporting officer."])

    monkeypatch.setattr("api.app.PharmfolioLlm", FakeCoach)
    app = create_app(settings)
    alex = TestClient(app)
    login(alex, "alex")
    conversation = alex.post("/api/coaching/conversations", json={"title": "New coaching conversation"}).json()["conversation"]
    sent = alex.post(f"/api/coaching/conversations/{conversation['id']}/messages", json={"content": "I want to strengthen my leadership evidence."})
    assert sent.status_code == 200
    reopened = alex.get(f"/api/coaching/conversations/{conversation['id']}").json()
    assert [message["role"] for message in reopened["messages"]] == ["user", "assistant"]
    assert reopened["messages"][1]["is_ai_generated"] is True

    summary = alex.post(f"/api/coaching/conversations/{conversation['id']}/summary").json()["summary"]
    assert summary["type"] == "summary"
    assert summary["metadata"]["action_items"] == ["Book a discussion with the reporting officer."]
    saved = alex.post(f"/api/coaching/conversations/{conversation['id']}/summaries/{summary['id']}/save")
    assert saved.status_code == 200
    assert alex.get("/api/saved-content?context=coaching").json()["items"][0]["is_ai_generated"] is True

    betty = TestClient(app)
    login(betty, "betty")
    assert betty.get(f"/api/coaching/conversations/{conversation['id']}").status_code == 404
