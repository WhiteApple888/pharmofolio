"""Tests that source bytes stay in document storage and graph state carries references only."""
from pathlib import Path

from schemas.api import FileInput
from services.document_store import LocalDocumentStore


def test_document_store_keeps_evidence_outside_state(settings) -> None:
    store = LocalDocumentStore(settings)
    source_text = "Sensitive workplace evidence " * 50
    uri, summary = store.save("tenant-a", "user-a", FileInput(name="evidence.eml", text=source_text))
    assert Path(uri).read_text(encoding="utf-8") == source_text
    graph_reference = {"id": "evidence-1", "filename": "evidence.eml", "summary": summary}
    assert "content" not in graph_reference
    assert len(graph_reference["summary"]) <= 300
    assert source_text not in repr(graph_reference)
    assert Path(uri).parts[-3:-1] == ("tenant-a", "user-a")
