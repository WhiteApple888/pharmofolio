"""Compatibility tests for the existing POST /api/map request and response contract."""
from fastapi.testclient import TestClient

from api.app import create_app
from schemas.llm import ClaimExtraction, ExtractedClaim, MappingProposalSet


class FakeLlm:
    """Schema-compatible deterministic test double; it never contacts OpenAI."""

    model_name = "fake-model"

    def __init__(self, _settings) -> None:
        pass

    def extract_claims(self, documents):
        document = documents[0]
        return ClaimExtraction(claims=[ExtractedClaim(statement="Led a medicines reconciliation improvement.", source_document_id=document["document_id"], source_reference=document["filename"], excerpt="Led reconciliation improvement", activity_title="Medicines reconciliation", date_or_period="2026", setting="Hospital", role="Pharmacist", stakeholders=["ward team"], outcomes="Improved process")])

    def map_claims(self, claims, _profile):
        from schemas.llm import ProposedMapping
        claim = claims[0]
        return MappingProposalSet(mappings=[ProposedMapping(activity_title=claim["activity_title"], standard_id="1.1", standard_name="Demonstrates expert skills and knowledge", source_document_id=claim["source_document_id"], source_reference=claim["source_reference"], evidence_excerpt=claim["excerpt"], rationale="The claim supports a developmental mapping.", suggested_level="Intermediate", confidence_score=0.9)])

    def coach(self, _gaps, _profile):
        from schemas.llm import CoachingProposalSet
        return CoachingProposalSet(suggestions=[])


def test_map_contract_is_preserved(monkeypatch, settings) -> None:
    monkeypatch.setattr("api.app.PharmfolioLlm", FakeLlm)
    client = TestClient(create_app(settings))
    assert client.post("/api/auth/login", json={"username": "alex", "password": "PharmPath-Alex!"}).status_code == 200
    response = client.post("/api/map", json={"profile": {"name": "Jamie", "grade": "P13", "track": "Clinical / Patient Care"}, "files": [{"name": "evidence.eml", "text": "Led a medicines reconciliation improvement."}]})
    assert response.status_code == 200
    body = response.json()
    assert set(body) == {"model", "response_id", "result"}
    assert set(body["result"]) == {"activities", "mappings", "gaps", "coaching"}
    assert body["result"]["mappings"][0]["standard_id"] == "1.1"
    assert body["result"]["mappings"][0]["confidence_score"] == 0.9


def test_map_requires_at_least_one_file(monkeypatch, settings) -> None:
    monkeypatch.setattr("api.app.PharmfolioLlm", FakeLlm)
    client = TestClient(create_app(settings))
    client.post("/api/auth/login", json={"username": "alex", "password": "PharmPath-Alex!"})
    response = client.post("/api/map", json={"files": []})
    assert response.status_code == 400
    assert response.json() == {"error": "Add at least one approved file or email thread."}


def test_configured_frontend_origin_can_call_api(monkeypatch, settings) -> None:
    monkeypatch.setattr("api.app.PharmfolioLlm", FakeLlm)
    settings.frontend_origins = "https://app.example.com"
    response = TestClient(create_app(settings)).options(
        "/api/map",
        headers={
            "Origin": "https://app.example.com",
            "Access-Control-Request-Method": "POST",
        },
    )
    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "https://app.example.com"
