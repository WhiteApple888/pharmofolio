"""Tests that centralized prompts retain the essential DFP policy guidance."""
from workflows.prompts import COACHING_PROMPT, EXTRACTION_PROMPT, mapping_prompt


def test_mapping_prompt_retains_grade_thresholds_and_level_definitions() -> None:
    prompt = mapping_prompt()
    assert "P12 80% Foundation+" in prompt
    assert "P18 50% Expert+" in prompt
    assert "Domain 7 professionalism" in prompt
    assert "Foundation = completes with help" in prompt
    assert "Controlled standards:" in prompt


def test_extraction_and_coaching_prompts_retain_workflow_essentials() -> None:
    assert "stakeholders" in EXTRACTION_PROMPT
    assert "short exact excerpt" in EXTRACTION_PROMPT
    assert "stretch assignments" in COACHING_PROMPT
    assert "owner and timeframe" in COACHING_PROMPT
