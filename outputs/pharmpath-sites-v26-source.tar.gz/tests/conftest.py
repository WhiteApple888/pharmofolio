"""Fixtures for isolated Pharmfolio workflow tests."""
from __future__ import annotations

from pathlib import Path

import pytest

from core.config import Settings


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    """Return isolated storage paths without a live model credential."""
    return Settings(
        database_url=f"sqlite:///{tmp_path / 'app.db'}",
        checkpoint_database_path=tmp_path / "checkpoints.db",
        document_storage_path=tmp_path / "documents",
        openai_api_key="test-key",
    )
