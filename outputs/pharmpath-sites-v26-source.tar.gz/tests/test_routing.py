"""Tests for deterministic LangGraph assessment routing."""
from workflows.nodes.workflow_nodes import route_after_assessment, route_after_review


def test_low_confidence_assessment_routes_to_human_review() -> None:
    assert route_after_assessment({"assessment_status": "human_review"}) == "human_review"


def test_provisional_assessment_routes_to_controlled_coaching() -> None:
    assert route_after_assessment({"assessment_status": "provisional"}) == "coaching_context"


def test_rejected_review_never_reaches_coaching() -> None:
    assert route_after_review({"review_decision": "rejected"}) == "dashboard"
