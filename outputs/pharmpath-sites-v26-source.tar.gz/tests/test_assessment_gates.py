"""Tests proving deterministic confidence and sensitivity gates control assessment routing."""
from schemas.llm import ProposedMapping
from services.dfp_rules import confidence_label, derive_gaps


def test_confidence_bands_are_deterministic() -> None:
    assert confidence_label(0.85) == "high"
    assert confidence_label(0.65) == "medium"
    assert confidence_label(0.64) == "low"


def test_low_confidence_mapping_creates_evidence_gap() -> None:
    mapping = ProposedMapping(activity_title="Medication review", standard_id="1.1", standard_name="Expert practice", source_document_id="e1", source_reference="note.txt", evidence_excerpt="Reviewed medicines", rationale="Evidence is sparse", suggested_level="Not enough evidence", confidence_score=0.4)
    gaps = derive_gaps([mapping], "P13")
    assert gaps[0].standard_id == "1.1"
    assert gaps[0].priority == "medium"
